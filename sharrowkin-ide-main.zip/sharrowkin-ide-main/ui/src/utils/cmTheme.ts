import { EditorView } from "@codemirror/view"
import { HighlightStyle, syntaxHighlighting } from "@codemirror/language"
import { tags as t } from "@lezer/highlight"

// Editor colors are driven by CSS variables so the editor follows the app's
// light/dark theme at runtime (CodeMirror's theme() emits real CSS, so var()
// resolves against the active [data-theme]).
const COLORS = {
  bg: "transparent",
  text: "var(--t-700)",
  gutter: "var(--t-300)",
  gutterActive: "var(--t-500)",
  cursor: "var(--t-900)",
  selection: "var(--cm-selection)",
  activeLine: "var(--cm-active-line)",
  keyword: "var(--cm-keyword)",
  string: "var(--cm-string)",
  comment: "var(--cm-comment)",
  func: "var(--cm-func)",
  number: "var(--cm-number)",
}

export const sharrowkinTheme = EditorView.theme(
  {
    "&": {
      color: COLORS.text,
      backgroundColor: COLORS.bg,
      fontSize: "12px",
      height: "100%",
    },
    ".cm-content": {
      fontFamily: '"JetBrains Mono","Cascadia Code","SF Mono",ui-monospace,monospace',
      padding: "4px 0 16px",
      caretColor: COLORS.cursor,
    },
    ".cm-scroller": {
      fontFamily: '"JetBrains Mono","Cascadia Code","SF Mono",ui-monospace,monospace',
      lineHeight: "20px",
      overflow: "auto",
    },
    "&.cm-focused": { outline: "none" },
    ".cm-cursor, .cm-dropCursor": { borderLeftColor: COLORS.cursor, borderLeftWidth: "2px" },
    "&.cm-focused .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection": {
      backgroundColor: COLORS.selection,
    },
    ".cm-activeLine": { backgroundColor: COLORS.activeLine },
    ".cm-gutters": {
      backgroundColor: "transparent",
      color: COLORS.gutter,
      border: "none",
    },
    ".cm-lineNumbers .cm-gutterElement": {
      color: COLORS.gutter,
      padding: "0 18px 0 8px",
      minWidth: "50px",
    },
    ".cm-activeLineGutter": { backgroundColor: "transparent", color: COLORS.gutterActive },

    // Agent-edit decorations: added lines get a green wash + left bar; removed
    // lines render as red struck-through ghost rows inserted inline.
    ".cm-diff-added": {
      backgroundColor: "rgba(22,163,74,0.10)",
      boxShadow: "inset 2px 0 0 #16a34a",
    },
    ".cm-diff-removed-block": {
      backgroundColor: "rgba(220,38,38,0.07)",
      boxShadow: "inset 2px 0 0 #dc2626",
    },
    ".cm-diff-removed-line": {
      fontFamily: '"JetBrains Mono","Cascadia Code","SF Mono",ui-monospace,monospace',
      fontSize: "12px",
      lineHeight: "20px",
      color: "rgba(185,28,28,0.85)",
      textDecoration: "line-through",
      textDecorationColor: "rgba(185,28,28,0.4)",
      whiteSpace: "pre",
      padding: "0 2px 0 6px",
      minHeight: "20px",
    },
  },
  { dark: false },
)

export const sharrowkinHighlight = HighlightStyle.define([
  { tag: [t.keyword, t.modifier, t.controlKeyword, t.operatorKeyword], color: COLORS.keyword },
  { tag: [t.string, t.special(t.string), t.regexp], color: COLORS.string },
  { tag: [t.comment, t.lineComment, t.blockComment, t.docComment], color: COLORS.comment, fontStyle: "italic" },
  { tag: [t.function(t.variableName), t.function(t.propertyName), t.definition(t.function(t.variableName))], color: COLORS.func },
  { tag: [t.number, t.bool, t.null, t.integer, t.float], color: COLORS.number },
  { tag: [t.className, t.typeName, t.namespace], color: COLORS.func },
])

export const sharrowkinSyntax = syntaxHighlighting(sharrowkinHighlight)
