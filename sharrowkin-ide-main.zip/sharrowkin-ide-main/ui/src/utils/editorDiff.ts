// Parses a standard unified diff (difflib / git style) into per-file marks the
// editor can paint: which lines in the NEW file were added, and where lines were
// deleted (anchored to the new-file line that follows the deletion). Used to show
// agent edits inline — added lines green, removed lines red — like a real IDE.

export type DeletedBlock = { line: number; text: string[] }
export type FileDiffMarks = {
  added: number[] // 1-based line numbers in the new file
  deleted: DeletedBlock[] // removed text anchored before `line`
}

function normalizePath(p: string): string {
  // Strip a/ b/ prefixes and normalize separators for matching against tabs.
  return p.replace(/^[ab]\//, "").replace(/\\/g, "/").trim()
}

export function parseUnifiedDiff(diff: string): Record<string, FileDiffMarks> {
  const out: Record<string, FileDiffMarks> = {}
  if (!diff) return out

  const lines = diff.split("\n")
  let current: FileDiffMarks | null = null
  let newLine = 0 // 1-based cursor into the new file
  let pendingDeleted: string[] = []

  const flushDeleted = () => {
    if (current && pendingDeleted.length) {
      current.deleted.push({ line: newLine, text: pendingDeleted })
      pendingDeleted = []
    }
  }

  for (const raw of lines) {
    // File header: "+++ b/path/to/file"
    if (raw.startsWith("+++ ")) {
      flushDeleted()
      const path = normalizePath(raw.slice(4))
      if (path && path !== "/dev/null") {
        current = out[path] ?? { added: [], deleted: [] }
        out[path] = current
      }
      continue
    }
    if (raw.startsWith("--- ")) continue // old-file header, ignore

    // Hunk header: "@@ -a,b +c,d @@"
    const hunk = raw.match(/^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@/)
    if (hunk) {
      flushDeleted()
      newLine = parseInt(hunk[1], 10)
      continue
    }

    if (!current) continue

    if (raw.startsWith("+")) {
      // An addition right after deletions is a REPLACEMENT — the green line
      // already conveys the change, so drop the pending red deletion marker.
      // Only deletions with no following addition stay as a pure-deletion anchor.
      pendingDeleted = []
      current.added.push(newLine)
      newLine++
    } else if (raw.startsWith("-")) {
      pendingDeleted.push(raw.slice(1))
    } else {
      // context line (starts with " ") or blank
      flushDeleted()
      newLine++
    }
  }
  flushDeleted()
  return out
}

// Match a diff path (posix) against an editor tab id (possibly backslashed,
// possibly workspace-relative). Returns the marks for that tab if present.
export function marksForTab(
  fileDiffs: Record<string, FileDiffMarks>,
  tab: string | null,
): FileDiffMarks | null {
  if (!tab) return null
  const norm = tab.replace(/\\/g, "/").replace(/^\.?\//, "")
  if (fileDiffs[norm]) return fileDiffs[norm]
  // Fall back to suffix match (diff may carry a longer or shorter prefix).
  for (const key of Object.keys(fileDiffs)) {
    if (key.endsWith(norm) || norm.endsWith(key)) return fileDiffs[key]
  }
  return null
}
