import type { FileKind } from "@/components/icons"

export const BASE = import.meta.env.VITE_BACKEND_URL || "http://127.0.0.1:8000"
export const WS_BASE = BASE.replace(/^http/, "ws")

// ─── Tree types (mirror api/routers/workspace.py build_tree) ───
export type TreeNode = {
  id: string
  name: string
  path: string
  type: "file" | "folder"
  size: number | null
  extension: string | null
  children: TreeNode[] | null
}

export type DetectResult = { path: string; source: string }
export type FileResult = { content: string; path: string; lines?: number; truncated?: boolean }

async function getJSON<T>(url: string): Promise<T> {
  const res = await fetch(url)
  if (!res.ok) {
    const detail = await res.text().catch(() => "")
    throw new Error(`${res.status} ${res.statusText}${detail ? `: ${detail}` : ""}`)
  }
  return res.json() as Promise<T>
}

export async function pickFolder(): Promise<string | null> {
  try {
    const res = await fetch(`${BASE}/api/workspace/pick-folder`)
    if (res.status === 204 || !res.ok) return null
    const d = await res.json()
    return d.path ?? null
  } catch {
    return null
  }
}

export function detectWorkspace(): Promise<DetectResult> {
  return getJSON<DetectResult>(`${BASE}/api/workspace/detect`)
}

export function getTree(path: string): Promise<{ tree: TreeNode | null }> {
  return getJSON<{ tree: TreeNode | null }>(`${BASE}/api/workspace/tree?path=${encodeURIComponent(path)}`)
}

export function getFile(workspace: string, path: string): Promise<FileResult> {
  return getJSON<FileResult>(
    `${BASE}/api/workspace/file?workspace=${encodeURIComponent(workspace)}&path=${encodeURIComponent(path)}`,
  )
}

export async function saveFile(workspace: string, path: string, content: string): Promise<void> {
  const res = await fetch(`${BASE}/api/workspace/file`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ workspace, path, content }),
  })
  if (!res.ok) throw new Error(`save failed: ${res.status}`)
}

export type StatsResult = { cpu: number; memory: number; ping: number }
export type AgentStatusResult = { active_sessions: number; phases: string[] }
export type SearchResult = { results: { path: string; line: number; text: string }[] }

export function getStats(): Promise<StatsResult> {
  return getJSON<StatsResult>(`${BASE}/api/stats`)
}

export function getAgentStatus(): Promise<AgentStatusResult> {
  return getJSON<AgentStatusResult>(`${BASE}/api/agent/status`)
}

export async function searchFiles(workspace: string, query: string): Promise<SearchResult> {
  const res = await fetch(`${BASE}/api/workspace/search`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ workspace, query }),
  })
  if (!res.ok) throw new Error(`search failed: ${res.status}`)
  return res.json() as Promise<SearchResult>
}

/** Alias for saveFile — PUT /api/workspace/file */
export const putFile = saveFile

export async function getHealth(): Promise<boolean> {
  try {
    const res = await fetch(`${BASE}/api/health`)
    return res.ok
  } catch {
    return false
  }
}

// ─── Helpers ───
export function extToKind(ext: string | null): FileKind {
  switch ((ext || "").toLowerCase()) {
    case ".py":
      return "py"
    case ".tsx":
    case ".jsx":
    case ".ts":
    case ".js":
      return "tsx"
    case ".md":
      return "md"
    default:
      return "py" // generic file glyph fallback (py glyph is the neutral default in this design)
  }
}

// CodeMirror language id from extension.
export function extToLanguage(ext: string | null): string {
  switch ((ext || "").toLowerCase()) {
    case ".py":
      return "python"
    case ".ts":
    case ".tsx":
    case ".js":
    case ".jsx":
      return "javascript"
    case ".json":
      return "json"
    case ".md":
      return "markdown"
    case ".html":
    case ".htm":
      return "html"
    default:
      return "text"
  }
}
