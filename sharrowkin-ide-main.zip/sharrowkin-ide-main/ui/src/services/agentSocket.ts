import { WS_BASE } from "@/services/api"

// ─── Agent WS event types (mirror agent/tool_loop.py + agent/core.py emitters) ───
export type PlanItem = {
  id: string
  title: string
  status: string
  estimatedTime?: string | null
  subtasks?: PlanItem[]
}

export type AgentEvent =
  | { type: "agent_start"; [k: string]: unknown }
  | { type: "phase_change"; phase: string; status: string }
  | { type: "thinking"; content: string }
  | { type: "log"; level: string; message: string }
  | { type: "task_plan"; plan: PlanItem[] }
  | { type: "task_update"; task_id: string; status: string }
  | {
      type: "tool_call"
      tool: string
      status: string
      target?: string
      detail?: string
      lines_changed?: number
      duration_ms?: number
      args?: Record<string, unknown>
      result?: string
    }
  | { type: "diff"; diff: string; files?: string[] }
  | { type: "content"; content: string }
  | { type: "status"; status?: string }
  | { type: "session_info"; [k: string]: unknown }
  | { type: "agent_complete"; session_id?: string }
  | { type: "error"; message: string }
  | { type: "heartbeat" }
  | { type: string; [k: string]: unknown }

export type AgentRunHandlers = {
  onEvent: (e: AgentEvent) => void
  onClose?: (clean: boolean) => void
  onError?: (msg: string) => void
}

export type AgentRunInput = {
  task: string
  workspace: string
  sessionId: string
  mode?: string
  systemPrompt?: string
  // IDE context — what the user sees right now
  ideContext?: {
    activeFile?: string       // currently open file path
    openFiles?: string[]      // all open tabs
    selectedText?: string     // text selected in editor
    cursorLine?: number       // cursor position
  }
}

// Opens a WS, sends the task, streams events to handlers.
// Returns a stop() that closes the socket.
export function runAgent(input: AgentRunInput, handlers: AgentRunHandlers): () => void {
  let socket: WebSocket
  try {
    socket = new WebSocket(`${WS_BASE}/api/agent/ws`)
  } catch (err) {
    handlers.onError?.(`Could not open WebSocket: ${String(err)}`)
    return () => {}
  }

  socket.onopen = () => {
    socket.send(
      JSON.stringify({
        task: input.task,
        workspace: input.workspace,
        session_id: input.sessionId,
        mode: input.mode,
        system_prompt: input.systemPrompt,
        ide_context: input.ideContext,
      }),
    )
  }

  socket.onmessage = (ev) => {
    let parsed: AgentEvent
    try {
      parsed = JSON.parse(ev.data) as AgentEvent
    } catch {
      return // ignore non-JSON frames
    }
    handlers.onEvent(parsed)
  }

  socket.onerror = () => {
    handlers.onError?.("WebSocket error — could not reach the agent backend.")
  }

  socket.onclose = (ev) => {
    handlers.onClose?.(ev.wasClean)
  }

  return () => {
    if (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING) {
      socket.close()
    }
  }
}

// Stable per-tab session id so the agent reuses disk-backed history.
export function makeSessionId(): string {
  return `session_${Math.floor(performance.now()).toString(36)}${Math.floor(performance.timeOrigin).toString(36)}`
}
