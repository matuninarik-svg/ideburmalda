import type { FileKind } from "@/components/icons"

// A token with a syntax-highlight class (matches the .k/.s/.cm/.f/.n CSS).
export type Tok = { t: string; c?: "k" | "s" | "cm" | "f" | "n" | "ghost" }
export type CodeLine = Tok[]

export type FileNode = {
  id: string // unique path key
  name: string
  kind: FileKind
  depth: 0 | 1 | 2
  isFolder?: boolean
  modified?: boolean
  // folder: which row toggles it; file: code body
  code?: CodeLine[]
}

// Editor code bodies, kept tiny but per-file so switching tabs shows something different.
const TOOL_LOOP: CodeLine[] = [
  [],
  [{ t: "# Showing visual results (Preview)", c: "cm" }],
  [{ t: "def", c: "k" }, { t: " " }, { t: "build_system_prompt", c: "f" }, { t: "(workspace: str) -> str:" }],
  [{ t: "    " }, { t: '"""Fill workspace root into the prompt."""', c: "s" }],
  [{ t: "    base = TOOL_LOOP_SYSTEM_PROMPT" }],
  [
    { t: "    " },
    { t: 'preview = "Start a server; its URL opens in Preview."', c: "ghost" },
  ],
  [{ t: "    " }, { t: "return", c: "k" }, { t: " base.replace(" }, { t: '"{workspace}"', c: "s" }, { t: ", workspace)" }],
  [],
  [{ t: "class", c: "k" }, { t: " " }, { t: "ToolLoop", c: "f" }, { t: ":" }],
  [{ t: "    " }, { t: "# Drives a single task to completion.", c: "cm" }],
  [{ t: "    " }, { t: "def", c: "k" }, { t: " " }, { t: "__init__", c: "f" }, { t: "(self, client, toolbox):" }],
  [{ t: "        self.max_iters = " }, { t: "40", c: "n" }],
]

const CORE: CodeLine[] = [
  [{ t: "# agent/core.py", c: "cm" }],
  [{ t: "from", c: "k" }, { t: " .tool_loop " }, { t: "import", c: "k" }, { t: " ToolLoop" }],
  [],
  [{ t: "class", c: "k" }, { t: " " }, { t: "Agent", c: "f" }, { t: ":" }],
  [{ t: "    " }, { t: "def", c: "k" }, { t: " " }, { t: "run", c: "f" }, { t: "(self, task: str):" }],
  [{ t: "        loop = ToolLoop(self.client, self.tools)" }],
  [{ t: "        " }, { t: "return", c: "k" }, { t: " loop.execute(task)" }],
]

const LAYOUT: CodeLine[] = [
  [{ t: "// ui/layout.tsx", c: "cm" }],
  [{ t: "export", c: "k" }, { t: " " }, { t: "default", c: "k" }, { t: " " }, { t: "function", c: "k" }, { t: " " }, { t: "Layout", c: "f" }, { t: "() {" }],
  [{ t: "  " }, { t: "return", c: "k" }, { t: " <Shell />" }],
  [{ t: "}" }],
]

// Flat tree (depth-encoded) — mirrors the mockup exactly.
export const TREE: FileNode[] = [
  { id: "agent", name: "agent", kind: "folder", depth: 0, isFolder: true },
  { id: "agent/phases", name: "phases", kind: "folder", depth: 1, isFolder: true },
  { id: "agent/phases/reason.py", name: "reason.py", kind: "py", depth: 2 },
  { id: "agent/phases/observe.py", name: "observe.py", kind: "py", depth: 2 },
  { id: "agent/core.py", name: "core.py", kind: "py", depth: 1, modified: true, code: CORE },
  { id: "agent/tool_loop.py", name: "tool_loop.py", kind: "py", depth: 1, modified: true, code: TOOL_LOOP },
  { id: "ui", name: "ui", kind: "folder", depth: 0, isFolder: true },
  { id: "ui/components", name: "components", kind: "folder", depth: 1, isFolder: true },
  { id: "ui/layout.tsx", name: "layout.tsx", kind: "tsx", depth: 1, code: LAYOUT },
  { id: "main.py", name: "main.py", kind: "py", depth: 0, code: CORE },
  { id: "README.md", name: "README.md", kind: "md", depth: 0, code: [[{ t: "# Sharrowkin", c: "cm" }]] },
]

export function findFile(id: string): FileNode | undefined {
  return TREE.find((n) => n.id === id && !n.isFolder)
}

// Folders that start collapsed in the mockup.
export const INITIAL_COLLAPSED = new Set<string>(["ui/components"])

export const FILE_CODE: Record<string, CodeLine[]> = Object.fromEntries(
  TREE.filter((n) => n.code).map((n) => [n.id, n.code as CodeLine[]]),
)
