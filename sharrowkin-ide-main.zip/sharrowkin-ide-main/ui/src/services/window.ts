// Window controls for the custom (frameless) titlebar. The app runs both as a
// Tauri desktop window (no native frame) and in a plain browser during dev, so
// every call is guarded: in the browser these are no-ops.

function inTauri(): boolean {
  return typeof window !== "undefined" && "__TAURI_INTERNALS__" in window
}

async function getAppWindow() {
  const { getCurrentWebviewWindow } = await import("@tauri-apps/api/webviewWindow")
  return getCurrentWebviewWindow()
}

export async function minimizeWindow(): Promise<void> {
  if (!inTauri()) return
  try {
    const w = await getAppWindow()
    await w.minimize()
  } catch (e) {
    console.error("Failed to minimize window:", e)
  }
}

export async function toggleMaximizeWindow(): Promise<void> {
  if (!inTauri()) {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen()
      } else {
        await document.exitFullscreen()
      }
    } catch (e) {
      console.warn("Fullscreen API not supported or blocked:", e)
    }
    return
  }
  try {
    const w = await getAppWindow()
    const maximized = await w.isMaximized()
    if (maximized) {
      await w.unmaximize()
    } else {
      await w.maximize()
    }
  } catch (e) {
    console.error("Failed to toggle maximize window:", e)
  }
}

export async function closeWindow(): Promise<void> {
  if (!inTauri()) {
    if (confirm("Close Sharrowkin IDE?")) {
      window.close()
      // Fallback if browser blocks script-initiated tab closing
      setTimeout(() => {
        window.location.href = "about:blank"
      }, 100)
    }
    return
  }
  try {
    const w = await getAppWindow()
    await w.close()
  } catch (e) {
    console.error("Failed to close window:", e)
  }
}
