import { StrictMode } from "react"
import { createRoot } from "react-dom/client"
import { SharrowkinIde } from "./SharrowkinIde"
import "./index.css"

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <SharrowkinIde />
  </StrictMode>,
)
