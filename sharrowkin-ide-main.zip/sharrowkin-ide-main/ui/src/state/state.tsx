import { createContext, useContext, useState, useRef, useEffect, type ReactNode } from "react"
import { INITIAL_COLLAPSED } from "@/services/files"
import { detectWorkspace } from "@/services/api"
import { runAgent, makeSessionId, type AgentEvent, type PlanItem } from "@/services/agentSocket"
import { parseUnifiedDiff, type FileDiffMarks } from "@/utils/editorDiff"

export type CtxPill = { id: string; label: string }
export type Mode = "Agent" | "Edit" | "Ask"

// ─── Chat turn model ───
export type ToolItem = {
  key: string
  tool: string
  label: string
  target?: string
  status: string // running | success | error | done
  detail?: string // short result summary, e.g. "4 matches", "saved", "12 passed"
  result?: string
  args?: Record<string, unknown> // raw tool arguments for click-to-action
}
export type DiffItem = { diff: string; files?: string[] }

export type AgentTurn = {
  thinking?: string
  // Mid-loop thoughts inserted between tool calls: afterTool = index of tool after which it appeared
  midThoughts: { afterTool: number; text: string }[]
  reasonings: string[]
  plan?: PlanItem[]
  tools: ToolItem[]
  diffs: DiffItem[]
  content: string
  status: "running" | "done" | "error"
  error?: string
}

export type Turn =
  | { kind: "user"; id: string; text: string }
  | { kind: "agent"; id: string; turn: AgentTurn }

const TOOL_LABELS: Record<string, string> = {
  scan_workspace: "Scan workspace",
  read_file: "Read",
  write_file: "Edited",
  str_replace: "Edited",
  list_files: "List files",
  search_files: "Search",
  search_code: "Search",
  find_symbol: "Find symbol",
  run_command: "Terminal",
  terminal: "Terminal",
  run_tests: "Run tests",
  verify: "Verify",
  git_diff: "Git diff",
  git: "Git",
  update_plan: "Plan",
  spawn_subagent: "Sub-agent",
  attempt_completion: "Completed",
  analyze_dependencies: "Analyze dependencies",
  memory_recall: "Memory recall",
  memory_store: "Memory store",
  llm_generate: "Thought",
}

// Web-agent "ceremony" tools that run before the real ToolLoop (workspace scan,
// dependency analysis, memory subsystems, internal LLM calls). They are
// implementation noise, not user-facing IDE actions, so we never render them as
// pills. attempt_completion is the loop's internal finish signal, not an action.
const HIDDEN_TOOLS = new Set([
  "scan_workspace",
  "analyze_dependencies",
  "memory_recall",
  "memory_store",
  "llm_generate",
  "attempt_completion",
])

export type SavedSession = {
  id: string
  createdAt: number
  preview: string   // first user message
  turns: Turn[]
}

type IdeState = {
  // workspace
  workspace: string | null
  setWorkspace: (p: string) => void

  // project
  currentProject: string | null
  openProject: (name: string) => void
  closeProject: () => void

  // settings
  showSettings: boolean
  openSettings: () => void
  closeSettings: () => void

  // session history overlay
  showHistory: boolean
  openHistory: () => void
  closeHistory: () => void
  savedSessions: SavedSession[]
  loadSession: (s: SavedSession) => void

  // editor tabs
  openTabs: string[]
  activeTab: string | null
  openFile: (id: string) => void
  closeTab: (id: string) => void
  setActiveTab: (id: string) => void

  // explorer
  collapsed: Set<string>
  toggleFolder: (id: string) => void
  sidebarHidden: boolean
  toggleSidebar: () => void

  // theme
  theme: "light" | "dark"
  toggleTheme: () => void

  // terminal
  termTab: string
  setTermTab: (t: string) => void

  // chat
  turns: Turn[]
  sendMessage: (text: string) => void
  isRunning: boolean
  stopAgent: () => void
  newSession: () => void
  mode: Mode
  setMode: (m: Mode) => void

  // context pills (from code selection / explorer)
  pills: CtxPill[]
  addPill: (label: string) => void
  removePill: (id: string) => void

  // agent edit decorations for the editor (path → added/deleted line marks)
  fileDiffs: Record<string, FileDiffMarks>
  diffVersion: number // bumps when an edit lands, so the editor refetches
  clearFileDiffs: () => void

  // active editor line (used when clicking a tool row to jump to the edited line)
  activeLine: number | null
  setActiveLine: (line: number | null) => void

  // custom system prompt injected into every agent request
  systemPrompt: string
  setSystemPrompt: (p: string) => void
}

const Ctx = createContext<IdeState | null>(null)

let pillSeq = 0
let turnSeq = 0

function emptyAgentTurn(): AgentTurn {
  return { reasonings: [], midThoughts: [], tools: [], diffs: [], content: "", status: "running" }
}

// ─── Session storage helpers ───
function sessionsKey(workspace: string) {
  return `ide.sessions.${workspace.replace(/[^a-zA-Z0-9]/g, "_")}`
}
function loadSessions(workspace: string): SavedSession[] {
  try { return JSON.parse(localStorage.getItem(sessionsKey(workspace)) ?? "[]") } catch { return [] }
}
function persistSessions(workspace: string, sessions: SavedSession[]) {
  localStorage.setItem(sessionsKey(workspace), JSON.stringify(sessions.slice(0, 50)))
}
function saveSessionToStorage(workspace: string, session: SavedSession) {
  const all = loadSessions(workspace).filter(s => s.id !== session.id)
  persistSessions(workspace, [session, ...all])
}

export function IdeProvider({ children }: { children: ReactNode }) {
  const [workspace, setWorkspaceState] = useState<string | null>(null)
  const [currentProject, setCurrentProject] = useState<string | null>(null)
  const [showSettings, setShowSettings] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [savedSessions, setSavedSessions] = useState<SavedSession[]>([])
  const [openTabs, setOpenTabs] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("ide.openTabs") ?? "[]") } catch { return [] }
  })
  const [activeTab, setActiveTabState] = useState<string | null>(() =>
    localStorage.getItem("ide.activeTab") ?? null
  )
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set(INITIAL_COLLAPSED))
  const [sidebarHidden, setSidebarHidden] = useState<boolean>(
    () => localStorage.getItem("ide.sidebarHidden") === "1",
  )
  const [theme, setTheme] = useState<"light" | "dark">(
    () => (localStorage.getItem("ide.theme") === "dark" ? "dark" : "light"),
  )
  const [termTab, setTermTab] = useState("Terminal")
  const [mode, setMode] = useState<Mode>("Agent")
  const [pills, setPills] = useState<CtxPill[]>([])
  const [turns, setTurns] = useState<Turn[]>([])
  const [isRunning, setIsRunning] = useState(false)
  const [systemPrompt, setSystemPromptState] = useState<string>(
    () => localStorage.getItem("ide.systemPrompt") ?? ""
  )
  function setSystemPrompt(p: string) {
    setSystemPromptState(p)
    localStorage.setItem("ide.systemPrompt", p)
  }
  const [fileDiffs, setFileDiffs] = useState<Record<string, FileDiffMarks>>({})
  const [diffVersion, setDiffVersion] = useState(0)
  const [activeLine, setActiveLine] = useState<number | null>(null)

  // Persist sessionId per-workspace so agent remembers across refreshes
  const sessionId = useRef<string>(makeSessionId())
  function getOrCreateSessionId(ws: string): string {
    const key = `ide.sessionId.${ws.replace(/[^a-zA-Z0-9]/g, "_")}`
    const existing = localStorage.getItem(key)
    if (existing) { sessionId.current = existing; return existing }
    const id = makeSessionId()
    localStorage.setItem(key, id)
    sessionId.current = id
    return id
  }
  const stopRef = useRef<(() => void) | null>(null)
  const workspaceRef = useRef<string | null>(null)
  workspaceRef.current = workspace

  function setWorkspace(p: string) {
    workspaceRef.current = p // sync so sendMessage right after open sees it
    setWorkspaceState(p)
    setSavedSessions(loadSessions(p))
  }

  // Apply the theme to the document root so CSS variable overrides take effect.
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme)
    localStorage.setItem("ide.theme", theme)
  }, [theme])

  function toggleSidebar() {
    setSidebarHidden((h) => {
      const next = !h
      localStorage.setItem("ide.sidebarHidden", next ? "1" : "0")
      return next
    })
  }
  function toggleTheme() {
    setTheme((t) => (t === "dark" ? "light" : "dark"))
  }

  // Auto-detect workspace on mount.
  useEffect(() => {
    let cancelled = false
    detectWorkspace()
      .then((r) => {
        if (!cancelled && r?.path) setWorkspace(r.path)
      })
      .catch(() => {
        /* backend down — user can set a path manually */
      })
    return () => {
      cancelled = true
      stopRef.current?.()
    }
  }, [])

  function persistTabs(tabs: string[], active: string | null) {
    localStorage.setItem("ide.openTabs", JSON.stringify(tabs))
    if (active !== null) localStorage.setItem("ide.activeTab", active)
    else localStorage.removeItem("ide.activeTab")
  }

  function openFile(id: string) {
    setOpenTabs((tabs) => {
      const next = tabs.includes(id) ? tabs : [...tabs, id]
      persistTabs(next, id)
      return next
    })
    setActiveTabState(id)
  }

  function closeTab(id: string) {
    setOpenTabs((tabs) => {
      const next = tabs.filter((t) => t !== id)
      setActiveTabState((cur) => {
        const newActive = cur !== id ? cur : (next[tabs.indexOf(id)] ?? next[tabs.indexOf(id) - 1] ?? next[0] ?? null)
        persistTabs(next, newActive)
        if (cur !== id) return cur
        const idx = tabs.indexOf(id)
        return next[idx] ?? next[idx - 1] ?? next[0] ?? null
      })
      return next
    })
  }

  function toggleFolder(id: string) {
    setCollapsed((set) => {
      const next = new Set(set)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function addPill(label: string) {
    setPills((p) => [...p, { id: `p-${++pillSeq}`, label }])
  }
  function removePill(id: string) {
    setPills((p) => p.filter((x) => x.id !== id))
  }
  function clearFileDiffs() {
    setFileDiffs({})
  }
  function openProject(name: string) {
    setCurrentProject(name)
  }
  function closeProject() {
    // Full reset — go back to Welcome with clean state
    stopRef.current?.()
    stopRef.current = null
    setIsRunning(false)
    setCurrentProject(null)
    setWorkspaceState(null)
    setOpenTabs([])
    setActiveTabState(null)
    localStorage.removeItem("ide.openTabs")
    localStorage.removeItem("ide.activeTab")
    setTurns([])
    setPills([])
    setSavedSessions([])
    setShowHistory(false)
    setShowSettings(false)
    const newSid = makeSessionId()
    sessionId.current = newSid
    if (workspaceRef.current) {
      const key = `ide.sessionId.${workspaceRef.current.replace(/[^a-zA-Z0-9]/g, "_")}`
      localStorage.setItem(key, newSid)
    }
  }
  function openSettings() {
    setShowSettings(true)
  }
  function closeSettings() {
    setShowSettings(false)
  }

  // Apply one streamed agent event to the latest agent turn.
  function applyEvent(agentId: string, e: AgentEvent) {
    // Side effect: agent edited files → parse the diff into editor decorations
    // and bump a version so the open editor refetches the changed content.
    if (e.type === "diff" && typeof e.diff === "string") {
      const marks = parseUnifiedDiff(e.diff)
      if (Object.keys(marks).length > 0) {
        setFileDiffs((prev) => ({ ...prev, ...marks }))
        setDiffVersion((v) => v + 1)
      }
    }

    setTurns((prev) =>
      prev.map((t) => {
        if (t.kind !== "agent" || t.id !== agentId) return t
        const turn = { ...t.turn }
        switch (e.type) {
          case "thinking": {
            const text = String(e.content ?? "")
            if (!turn.thinking) {
              // First thinking = intro block above tools
              turn.thinking = text
            } else {
              // Mid-loop thinking = insert after current tool count
              turn.midThoughts = [...(turn.midThoughts ?? []), { afterTool: turn.tools.length, text }]
            }
            break
          }
          case "task_plan":
            turn.plan = (e.plan as PlanItem[]) ?? turn.plan
            break
          case "task_update": {
            if (turn.plan) {
              turn.plan = turn.plan.map((p) =>
                p.id === e.task_id ? { ...p, status: String(e.status) } : p,
              )
            }
            break
          }
          case "tool_call": {
            const tool = String(e.tool)
            // Web-agent ceremony tools never appear in the IDE chat.
            if (HIDDEN_TOOLS.has(tool)) break
            const target = e.target ? String(e.target) : undefined
            const key = `${tool}|${target ?? ""}`
            const status = String(e.status ?? "done")
            // Backend sends a short human detail ("4 matches", "saved") and a
            // lines_changed count for edits. Prefer detail; fall back to "+N".
            const rawDetail = e.detail ? String(e.detail) : undefined
            const linesChanged = typeof e.lines_changed === "number" ? e.lines_changed : 0
            const detail = rawDetail || (linesChanged > 0 ? `+${linesChanged}` : undefined)
            const args = (e.args && typeof e.args === "object" ? e.args : undefined) as Record<string, unknown> | undefined
            const item: ToolItem = {
              key,
              tool,
              label: TOOL_LABELS[tool] ?? tool,
              target,
              status,
              detail,
              result: e.result ? String(e.result) : undefined,
              args,
            }
            const idx = turn.tools.findIndex((x) => x.key === key)
            if (idx >= 0) {
              const tools = turn.tools.slice()
              // Don't let a later event without detail erase an earlier one.
              const prevItem = tools[idx]
              tools[idx] = {
                ...item,
                detail: item.detail ?? prevItem.detail,
                result: item.result ?? prevItem.result,
                args: item.args ?? prevItem.args,
              }
              turn.tools = tools
            } else {
              turn.tools = [...turn.tools, item]
            }
            break
          }
          case "diff":
            turn.diffs = [...turn.diffs, { diff: String(e.diff), files: e.files as string[] | undefined }]
            break
          case "content":
            turn.content += String(e.content ?? "")
            break
          case "log": {
            // Operational logs (memory init, file scan counts, step markers) are
            // web-agent noise — keep them out of the IDE chat. Only a hard error
            // log is worth surfacing (the loop emits one before bailing on an
            // unreachable LLM without sending a separate "error" event).
            const lvl = String((e as { level?: string }).level ?? "")
            const msg = String((e as { message?: string }).message ?? "")
            if (lvl === "error" && msg) {
              turn.status = "error"
              turn.error = msg
            }
            break
          }
          case "error":
            turn.status = "error"
            turn.error = String((e as { message?: string }).message ?? "Unknown error")
            break
          case "agent_complete":
            if (turn.status === "running") turn.status = "done"
            break
        }
        return { ...t, turn }
      }),
    )
  }

  function sendMessage(text: string) {
    const trimmed = text.trim()
    if (!trimmed || isRunning) return

    const userId = `t-${++turnSeq}`
    const agentId = `t-${++turnSeq}`
    setTurns((prev) => [
      ...prev,
      { kind: "user", id: userId, text: trimmed },
      { kind: "agent", id: agentId, turn: emptyAgentTurn() },
    ])

    const ws = workspaceRef.current
    if (!ws) {
      setTurns((prev) =>
        prev.map((t) =>
          t.kind === "agent" && t.id === agentId
            ? {
                ...t,
                turn: {
                  ...t.turn,
                  status: "error",
                  error: "Рабочая папка не задана. Backend не отвечает на /api/workspace/detect — укажи путь вручную.",
                },
              }
            : t,
        ),
      )
      return
    }

    setIsRunning(true)
    const sid = getOrCreateSessionId(ws)

    const userName = localStorage.getItem("ide.userName")
    const userRole = localStorage.getItem("ide.userRole")
    const userContext = localStorage.getItem("ide.userContext")
    let fullSystemPrompt = systemPrompt
    if (userName || userRole || userContext) {
      const onboardBlock = `[User Profile]
- Name: ${userName ?? "Developer"}
- Role: ${userRole ?? "Developer"}
- Context/Task: ${userContext ?? "Developing software"}
Always tailor your assistance to this user's profile and preferences.`
      fullSystemPrompt = fullSystemPrompt ? `${fullSystemPrompt}\n\n${onboardBlock}` : onboardBlock
    }

    stopRef.current = runAgent(
      {
        task: trimmed,
        workspace: ws,
        sessionId: sid,
        mode,
        systemPrompt: fullSystemPrompt || undefined,
        ideContext: {
          activeFile: activeTab ?? undefined,
          openFiles: openTabs.length > 0 ? openTabs : undefined,
        },
      },
      {
        onEvent: (e) => applyEvent(agentId, e),
        onError: (msg) => {
          applyEvent(agentId, { type: "error", message: msg })
          setIsRunning(false)
        },
        onClose: () => {
          setIsRunning(false)
          stopRef.current = null
        },
      },
    )
  }

  function stopAgent() {
    stopRef.current?.()
    stopRef.current = null
    setIsRunning(false)
  }

  function _saveCurrentSession(currentTurns: Turn[]) {
    const ws = workspaceRef.current
    if (!ws || currentTurns.length === 0) return
    const firstUser = currentTurns.find(t => t.kind === "user")
    const preview = firstUser ? (firstUser as any).text?.slice(0, 80) ?? "Session" : "Session"
    const session: SavedSession = {
      id: sessionId.current,
      createdAt: Date.now(),
      preview,
      turns: currentTurns,
    }
    saveSessionToStorage(ws, session)
    setSavedSessions(loadSessions(ws))
  }

  function newSession() {
    stopRef.current?.()
    stopRef.current = null
    setIsRunning(false)
    setTurns(prev => { _saveCurrentSession(prev); return [] })
    setPills([])
    setShowHistory(false)
    const newSid = makeSessionId()
    sessionId.current = newSid
    if (workspaceRef.current) {
      const key = `ide.sessionId.${workspaceRef.current.replace(/[^a-zA-Z0-9]/g, "_")}`
      localStorage.setItem(key, newSid)
    }
  }

  function openHistory() {
    // save current before viewing
    setTurns(prev => { _saveCurrentSession(prev); return prev })
    setShowHistory(true)
  }
  function closeHistory() { setShowHistory(false) }

  function loadSession(s: SavedSession) {
    stopRef.current?.()
    stopRef.current = null
    setIsRunning(false)
    setTurns(s.turns)
    setPills([])
    sessionId.current = s.id
    setShowHistory(false)
  }

  const value: IdeState = {
    workspace,
    setWorkspace,
    currentProject,
    openProject,
    closeProject,
    showSettings,
    openSettings,
    closeSettings,
    showHistory,
    openHistory,
    closeHistory,
    savedSessions,
    loadSession,
    openTabs,
    activeTab,
    openFile,
    closeTab,
    setActiveTab: setActiveTabState,
    collapsed,
    toggleFolder,
    sidebarHidden,
    toggleSidebar,
    theme,
    toggleTheme,
    termTab,
    setTermTab,
    turns,
    sendMessage,
    isRunning,
    stopAgent,
    newSession,
    mode,
    setMode,
    pills,
    addPill,
    removePill,
    fileDiffs,
    diffVersion,
    clearFileDiffs,
    activeLine,
    setActiveLine,
    systemPrompt,
    setSystemPrompt,
  }

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useIde() {
  const v = useContext(Ctx)
  if (!v) throw new Error("useIde must be used within IdeProvider")
  return v
}
