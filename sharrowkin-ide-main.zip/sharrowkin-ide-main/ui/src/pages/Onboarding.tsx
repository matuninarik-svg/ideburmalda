import { useState } from 'react'
import { useIde } from "@/state/state"
import { BASE } from "@/services/api"
import { CustomDropdown } from "@/components/settings/CustomDropdown"
import { TitleBar } from "@/components/TitleBar"

interface Props { onComplete: () => void }

type Provider = 'gemini' | 'anthropic' | 'openai' | 'openrouter'

const PROVIDERS = [
  { id: 'gemini' as const, name: 'Google Gemini', placeholder: 'AIzaSy...', keyName: 'gemini_api_key', desc: 'Default provider for fast, low-latency reasoning' },
  { id: 'anthropic' as const, name: 'Anthropic Claude', placeholder: 'sk-ant-...', keyName: 'anthropic_api_key', desc: 'Powerful agent reasoning models (Claude Sonnet)' },
  { id: 'openai' as const, name: 'OpenAI GPT-4o', placeholder: 'sk-...', keyName: 'openai_api_key', desc: 'Industry benchmark models (GPT-4o)' },
  { id: 'openrouter' as const, name: 'OpenRouter API', placeholder: 'sk-or-...', keyName: 'openrouter_api_key', desc: 'Access to DeepSeek and open-source models' },
]

export function Onboarding({ onComplete }: Props) {
  const { theme, toggleTheme } = useIde()
  const [slide, setSlide] = useState(1)
  const [provider, setProvider] = useState<Provider>('gemini')
  const [apiKey, setApiKey] = useState('')
  const [saving, setSaving] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')

  const [userName, setUserName] = useState(() => localStorage.getItem('ide.userName') ?? '')
  const [userRole, setUserRole] = useState(() => localStorage.getItem('ide.userRole') ?? '')
  const [userContext, setUserContext] = useState(() => localStorage.getItem('ide.userContext') ?? '')

  const saveApiKey = async () => {
    if (!apiKey) return true
    setSaving(true); setErrorMsg('')
    try {
      const activeProvider = PROVIDERS.find(p => p.id === provider)!
      const res = await fetch(`${BASE}/api/settings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ [activeProvider.keyName]: apiKey }),
      })
      if (!res.ok) { setErrorMsg('Failed to save API key.'); return false }
      return true
    } catch { setErrorMsg('Network error — is the backend running?'); return false }
    finally { setSaving(false) }
  }

  const handleFinish = async () => {
    localStorage.setItem('ide.userName', userName.trim())
    localStorage.setItem('ide.userRole', userRole.trim())
    localStorage.setItem('ide.userContext', userContext.trim())
    const ok = await saveApiKey()
    if (ok) { localStorage.setItem('ide.onboarded', 'true'); onComplete() }
  }

  const handleSkip = () => {
    localStorage.setItem('ide.userName', userName.trim())
    localStorage.setItem('ide.userRole', userRole.trim())
    localStorage.setItem('ide.userContext', userContext.trim())
    localStorage.setItem('ide.onboarded', 'true');
    onComplete()
  }

  const card = { boxShadow: 'none', border: 'none', background: 'var(--surface)', borderRadius: '16px', overflow: 'visible' }
  const row  = { boxShadow: 'none', padding: '16px 20px' }

  return (
    <div className="settings-container" style={{ background: 'var(--app)', height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <TitleBar left={<span className="name">Sharrowkin</span>} />

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
        <div style={{ width: '100%', maxWidth: '540px', animation: 'fadeUp .35s var(--ease-out)' }}>

          {/* Step indicators */}
          <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginBottom: 28 }}>
            {[1,2,3,4].map(s => (
              <div key={s} style={{
                height: 4, borderRadius: 2, background: slide >= s ? 'var(--accent)' : 'var(--t-200)',
                width: slide === s ? 24 : 8, transition: 'all .25s var(--ease-out)',
              }} />
            ))}
          </div>

          {/* ── Slide 1: Welcome ── */}
          {slide === 1 && (
            <div>
              <div className="page-title" style={{ textAlign: 'center', marginBottom: 6 }}>Welcome to Sharrowkin</div>
              <p style={{ textAlign: 'center', color: 'var(--t-400)', fontSize: 13.5, marginBottom: 28 }}>
                An AI-first IDE. Let's get you set up.
              </p>

              <div className="section">
                <div className="section-title">What you get</div>
                <div className="card" style={card}>
                  {[
                    ['Autopilot Agent', 'Plans, edits, and self-corrects across your entire codebase'],
                    ['Persistent Memory', '4-layer memory — your project context never resets'],
                    ['Live Diff View', 'See every file change inline as the agent works'],
                  ].map(([title, desc]) => (
                    <div key={title} className="row" style={row}>
                      <span className="row-label">
                        <div className="row-title">{title}</div>
                        <div className="row-desc">{desc}</div>
                      </span>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{ color: 'var(--accent)', flexShrink: 0 }}>
                        <polyline points="20 6 9 17 4 12"/>
                      </svg>
                    </div>
                  ))}
                </div>
              </div>

              <div style={{ marginTop: 28, display: 'flex', justifyContent: 'flex-end' }}>
                <button className="btn btn-primary" onClick={() => setSlide(2)}>
                  Get Started
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
              </div>
            </div>
          )}

          {/* ── Slide 2: Theme ── */}
          {slide === 2 && (
            <div>
              <div className="page-title" style={{ textAlign: 'center', marginBottom: 6 }}>Choose your theme</div>
              <p style={{ textAlign: 'center', color: 'var(--t-400)', fontSize: 13.5, marginBottom: 28 }}>You can change this anytime.</p>

              <div style={{ display: 'flex', gap: 16, marginBottom: 28 }}>
                {(['dark', 'light'] as const).map(t => (
                  <button
                    key={t}
                    onClick={() => theme !== t && toggleTheme()}
                    style={{
                      flex: 1, borderRadius: 16, padding: 16, cursor: 'pointer',
                      fontFamily: 'inherit', transition: 'all .15s',
                      background: theme === t ? 'var(--surface)' : 'var(--soft)',
                      border: `1.5px solid ${theme === t ? 'var(--accent)' : 'transparent'}`,
                      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
                    }}
                  >
                    {/* Mini mockup */}
                    <div style={{
                      width: '100%', height: 90, borderRadius: 10, overflow: 'hidden',
                      background: t === 'dark' ? '#141417' : '#f6f6f8',
                      border: `1px solid ${t === 'dark' ? '#2a2a32' : '#e4e4e7'}`,
                    }}>
                      <div style={{ height: 14, background: t === 'dark' ? '#1c1c21' : '#fff', borderBottom: `1px solid ${t === 'dark' ? '#2a2a32' : '#e4e4e7'}`, display: 'flex', alignItems: 'center', gap: 4, padding: '0 8px' }}>
                        {[0,1,2].map(i => <span key={i} style={{ width: 5, height: 5, borderRadius: '50%', background: t === 'dark' ? '#333' : '#ddd' }} />)}
                      </div>
                      <div style={{ display: 'flex', height: 76 }}>
                        <div style={{ width: 24, background: t === 'dark' ? '#1c1c21' : '#fff', borderRight: `1px solid ${t === 'dark' ? '#2a2a32' : '#e4e4e7'}`, padding: '6px 4px', display: 'flex', flexDirection: 'column', gap: 5 }}>
                          {[70,50,80].map((w,i) => <div key={i} style={{ height: 3, borderRadius: 2, background: t === 'dark' ? '#2e2e38' : '#e4e4e7', width: `${w}%` }} />)}
                        </div>
                        <div style={{ flex: 1, padding: '8px 10px', display: 'flex', flexDirection: 'column', gap: 5 }}>
                          {['#9333ea','#2563eb','#059669','#6b6b78'].map((c,i) => (
                            <div key={i} style={{ height: 3, borderRadius: 2, background: c, opacity: t === 'dark' ? 0.55 : 0.3, width: `${[80,60,75,45][i]}%` }} />
                          ))}
                        </div>
                      </div>
                    </div>
                    <span style={{ fontSize: 12.5, fontWeight: theme === t ? 600 : 450, color: 'var(--t-700)' }}>
                      {t === 'dark' ? 'Dark' : 'Light'}{theme === t ? ' ✓' : ''}
                    </span>
                  </button>
                ))}
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <button className="btn btn-soft" onClick={() => setSlide(1)}>Back</button>
                <button className="btn btn-primary" onClick={() => setSlide(3)}>
                  Continue
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
              </div>
            </div>
          )}

          {/* ── Slide 3: Profile ── */}
          {slide === 3 && (
            <div>
              <div className="page-title" style={{ textAlign: 'center', marginBottom: 6 }}>Tell us about yourself</div>
              <p style={{ textAlign: 'center', color: 'var(--t-400)', fontSize: 13.5, marginBottom: 28 }}>
                Help Sharrowkin understand who you are and what you build.
              </p>

              <div className="section">
                <div className="section-title">Developer Profile</div>
                <div className="card" style={card}>
                  <div className="row" style={row}>
                    <span className="row-label">
                      <div className="row-title">Your name</div>
                      <div className="row-desc">What should Sharrowkin call you?</div>
                    </span>
                    <input
                      type="text"
                      className="field"
                      style={{ width: 220 }}
                      placeholder="e.g. Danil"
                      value={userName}
                      onChange={e => setUserName(e.target.value)}
                    />
                  </div>
                  <div className="row" style={row}>
                    <span className="row-label">
                      <div className="row-title">Your role</div>
                      <div className="row-desc">Your occupation or title</div>
                    </span>
                    <input
                      type="text"
                      className="field"
                      style={{ width: 220 }}
                      placeholder="e.g. Senior Frontend Dev"
                      value={userRole}
                      onChange={e => setUserRole(e.target.value)}
                    />
                  </div>
                  <div className="row" style={row}>
                    <span className="row-label">
                      <div className="row-title">Current context</div>
                      <div className="row-desc">What are you working on or building?</div>
                    </span>
                    <textarea
                      className="field"
                      style={{ width: 220, height: 60, resize: 'none', padding: '8px 10px', fontSize: 12.5 }}
                      placeholder="e.g. building a high-perf IDE frontend in React"
                      value={userContext}
                      onChange={e => setUserContext(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <div style={{ marginTop: 24, display: 'flex', justifyContent: 'space-between' }}>
                <button className="btn btn-soft" onClick={() => setSlide(2)}>Back</button>
                <button className="btn btn-primary" onClick={() => setSlide(4)}>
                  Continue
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
              </div>
            </div>
          )}

          {/* ── Slide 4: API Key ── */}
          {slide === 4 && (
            <div>
              <div className="page-title" style={{ textAlign: 'center', marginBottom: 6 }}>Connect an AI model</div>
              <p style={{ textAlign: 'center', color: 'var(--t-400)', fontSize: 13.5, marginBottom: 28 }}>Bring your own key — all providers supported.</p>

              <div className="section">
                <div className="section-title">API Configuration</div>
                <div className="card" style={card}>
                  <div className="row" style={row}>
                    <span className="row-label">
                      <div className="row-title">Provider</div>
                      <div className="row-desc">Choose your AI provider</div>
                    </span>
                    <CustomDropdown
                      value={PROVIDERS.find(p => p.id === provider)?.name ?? ''}
                      options={PROVIDERS.map(p => p.name)}
                      onChange={val => {
                        const p = PROVIDERS.find(x => x.name === val)
                        if (p) { setProvider(p.id); setApiKey(''); setErrorMsg('') }
                      }}
                    />
                  </div>
                  <div className="row" style={row}>
                    <span className="row-label">
                      <div className="row-title">API Key</div>
                      <div className="row-desc">{PROVIDERS.find(p => p.id === provider)?.desc}</div>
                    </span>
                    <input
                      type="password"
                      className="field"
                      style={{ width: 200 }}
                      placeholder={PROVIDERS.find(p => p.id === provider)?.placeholder}
                      value={apiKey}
                      onChange={e => setApiKey(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleFinish()}
                      autoFocus
                    />
                  </div>
                </div>
              </div>

              {errorMsg && <div style={{ color: '#dc2626', fontSize: 12, fontWeight: 500, marginTop: 8 }}>{errorMsg}</div>}

              <div style={{ marginTop: 24, display: 'flex', alignItems: 'center', gap: 8 }}>
                <button className="btn btn-soft" onClick={() => setSlide(3)}>Back</button>
                <button className="btn btn-soft" onClick={handleSkip} style={{ marginRight: 'auto' }}>Skip</button>
                <button className="btn btn-primary" onClick={handleFinish} disabled={saving}>
                  {saving ? 'Saving…' : 'Finish Setup'}
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  )
}
