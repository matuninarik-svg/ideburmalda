import { useState, useEffect } from 'react'
import { useIde } from "@/state/state"
import { BASE, pickFolder as pickFolderApi } from "@/services/api"
import { TitleBar } from "@/components/TitleBar"

type RecentProject = { path: string; name: string; time: number }

function timeAgo(ts: number) {
  const diff = (Date.now() - ts) / 1000
  if (diff < 60) return 'just now'
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  if (diff < 86400 * 7) return `${Math.floor(diff / 86400)}d ago`
  return new Date(ts).toLocaleDateString()
}

function getRecents(): RecentProject[] {
  try { return JSON.parse(localStorage.getItem('ide.recents') ?? '[]') } catch { return [] }
}

function addRecent(path: string) {
  const name = path.split(/[\\/]/).filter(Boolean).pop() ?? path
  const list = getRecents().filter(r => r.path !== path)
  list.unshift({ path, name, time: Date.now() })
  localStorage.setItem('ide.recents', JSON.stringify(list.slice(0, 8)))
}

function greeting() {
  const h = new Date().getHours()
  if (h < 5) return 'Good night'
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  return 'Good evening'
}

export function Welcome() {
  const [input, setInput] = useState('')
  const [recents, setRecents] = useState<RecentProject[]>([])
  const [detectedPath, setDetectedPath] = useState<string | null>(null)
  const [userName, setUserName] = useState('there')
  const { openProject, sendMessage, setWorkspace } = useIde()

  useEffect(() => {
    setRecents(getRecents())
    
    const savedName = localStorage.getItem('ide.userName')
    if (savedName) setUserName(savedName)

    fetch(`${BASE}/api/workspace/detect`)
      .then(r => r.ok ? r.json() : null)
      .then(d => { if (d?.path) setDetectedPath(d.path) })
      .catch(() => {})
  }, [])

  function openPath(path: string) {
    addRecent(path)
    setWorkspace(path)
    openProject(path.split(/[\\/]/).filter(Boolean).pop() ?? path)
  }

  function handleSend() {
    const text = input.trim()
    if (!text) return
    if (!detectedPath) { pickFolder(text); return }
    openPath(detectedPath)
    sendMessage(text)
    setInput('')
  }

  async function pickFolder(pendingTask?: string) {
    const path = await pickFolderApi()
    if (!path) return
    openPath(path)
    const task = (pendingTask ?? '').trim()
    if (task) { sendMessage(task); setInput('') }
  }

  return (
    <div className="welcome-container">
      <TitleBar left={<span className="name">Sharrowkin</span>} />

      <div className="w-center">
        <div className="greeting">{greeting()}, {userName}</div>
        <div className="greeting-sub">What are we building today?</div>

        {/* Main input */}
        <div className="main-input-wrap">
          <div className="main-input-top">
            <svg className="main-input-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
              <circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            <input
              type="text"
              placeholder="Ask agent or open project…"
              autoFocus
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
            />
          </div>
          <div className="main-input-actions">
            <button className="ia-btn" onClick={() => pickFolder()}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
              </svg>
              Open folder
            </button>
            <div className="ia-sep" />
            <button
              className="ia-btn"
              disabled={!detectedPath && recents.length === 0}
              onClick={() => {
                const last = detectedPath ?? recents[0]?.path
                if (last) openPath(last)
              }}
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5A10 10 0 0 1 3.2 16.7"/>
              </svg>
              Continue last
            </button>
          </div>
        </div>

        {/* Recents — only project name, no raw path */}
        {recents.length > 0 && (
          <div className="recents">
            <div className="recents-head">Recent</div>
            {recents.map(r => (
              <button key={r.path} className="ri" onClick={() => openPath(r.path)} title={r.path}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" style={{ color: 'var(--t-300)', flexShrink: 0 }}>
                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
                </svg>
                <span className="ri-name">{r.name}</span>
                <span className="ri-time">{timeAgo(r.time)}</span>
              </button>
            ))}
          </div>
        )}

        {recents.length === 0 && !detectedPath && (
          <div style={{ color: 'var(--t-400)', fontSize: 12, marginTop: 8 }}>
            No recent projects — open a folder to get started
          </div>
        )}
      </div>

      <div className="footer">
        <button className="fl">GitHub</button>
        <span className="fsep">·</span>
        <button className="fl">Docs</button>
        <span className="fsep">·</span>
        <span className="fl" style={{ color: 'var(--t-300)' }}>v0.1.0</span>
      </div>
    </div>
  )
}
