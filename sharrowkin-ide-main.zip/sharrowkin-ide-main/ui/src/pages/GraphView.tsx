import { useEffect, useRef, useState, useCallback } from "react"
import * as d3 from "d3"
import { useIde } from "@/state/state"
import { BASE } from "@/services/api"

interface GraphNode extends d3.SimulationNodeDatum {
  id: string; label: string; group: string; color: string; path: string; ext: string
}
interface GraphEdge extends d3.SimulationLinkDatum<GraphNode> {
  source: string | GraphNode; target: string | GraphNode; type: string
}
interface GraphData {
  nodes: GraphNode[]; edges: GraphEdge[]
  stats: { files: number; memory: number; connections: number }
}

const GROUP_COLORS: Record<string, string> = {
  python: "#3b82f6", typescript: "#6366f1", javascript: "#d97706",
  config: "#059669", docs: "#9333ea", style: "#0891b2", html: "#ea580c",
  memory: "#8b5cf6", other: "#a1a1aa",
}
const GROUP_LABELS: Record<string, string> = {
  python: "Python", typescript: "TypeScript", javascript: "JavaScript",
  config: "Config", docs: "Docs", style: "Style", html: "HTML",
  memory: "Memory", other: "Other",
}

export function GraphView({ onClose }: { onClose: () => void }) {
  const { workspace } = useIde()
  const svgRef = useRef<SVGSVGElement>(null)
  const [data, setData] = useState<GraphData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selected, setSelected] = useState<GraphNode | null>(null)
  const [filter, setFilter] = useState("all")
  const simRef = useRef<d3.Simulation<GraphNode, GraphEdge> | null>(null)

  useEffect(() => {
    if (!workspace) return
    setLoading(true)
    fetch(`${BASE}/api/workspace/graph?path=${encodeURIComponent(workspace)}`)
      .then(r => r.ok ? r.json() : Promise.reject(r.status))
      .then(d => { setData(d); setLoading(false) })
      .catch(e => { setError(`${e}`); setLoading(false) })
  }, [workspace])

  const renderGraph = useCallback(() => {
    if (!data || !svgRef.current) return
    const el = svgRef.current
    const svg = d3.select(el)
    svg.selectAll("*").remove()

    const W = el.clientWidth || 900
    const H = el.clientHeight || 600

    const nodes = (filter === "all" ? data.nodes : data.nodes.filter(n => n.group === filter)) as GraphNode[]
    const ids = new Set(nodes.map(n => n.id))
    const edges = data.edges.filter(e => ids.has(e.source as string) && ids.has(e.target as string)) as GraphEdge[]

    // Background
    svg.style("background", "var(--app)")

    const g = svg.append("g")
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.08, 5])
      .on("zoom", ev => g.attr("transform", ev.transform))
    svg.call(zoom)
    svg.on("click", () => {
      setSelected(null)
      nodeG.selectAll("circle").attr("opacity", 1).attr("r", (d: any) => d.group === "memory" ? 9 : 6)
      linkG.selectAll("line").attr("opacity", 0.35)
    })

    // Defs
    const defs = svg.append("defs")
    defs.append("marker").attr("id", "arr").attr("viewBox", "0 -3 7 7")
      .attr("refX", 13).attr("refY", 0).attr("markerWidth", 5).attr("markerHeight", 5).attr("orient", "auto")
      .append("path").attr("d", "M0,-3L7,0L0,3").attr("fill", "var(--t-300)")

    const sim = d3.forceSimulation<GraphNode>(nodes)
      .force("link", d3.forceLink<GraphNode, GraphEdge>(edges).id(d => d.id).distance(70).strength(0.25))
      .force("charge", d3.forceManyBody().strength(-180))
      .force("center", d3.forceCenter(W / 2, H / 2))
      .force("collision", d3.forceCollide(18))
    simRef.current = sim

    const linkG = g.append("g")
    const link = linkG.selectAll("line").data(edges).join("line")
      .attr("stroke", "var(--t-200)").attr("stroke-width", 1)
      .attr("marker-end", "url(#arr)").attr("opacity", 0.35)

    const nodeG = g.append("g")
    const node = nodeG.selectAll("g").data(nodes).join("g")
      .attr("cursor", "pointer")
      .call(d3.drag<SVGGElement, GraphNode>()
        .on("start", (ev, d) => { if (!ev.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y })
        .on("drag",  (ev, d) => { d.fx = ev.x; d.fy = ev.y })
        .on("end",   (ev, d) => { if (!ev.active) sim.alphaTarget(0); d.fx = null; d.fy = null })
      )
      .on("click", (ev, d) => {
        ev.stopPropagation()
        setSelected(d)
        const conn = new Set<string>()
        edges.forEach(e => {
          if ((e.source as GraphNode).id === d.id) conn.add((e.target as GraphNode).id)
          if ((e.target as GraphNode).id === d.id) conn.add((e.source as GraphNode).id)
        })
        nodeG.selectAll<SVGCircleElement, GraphNode>("circle")
          .attr("opacity", n => n.id === d.id || conn.has(n.id) ? 1 : 0.15)
          .attr("r", n => n.id === d.id ? (n.group === "memory" ? 13 : 10) : n.group === "memory" ? 9 : 6)
        linkG.selectAll<SVGLineElement, GraphEdge>("line")
          .attr("opacity", l => {
            const s = (l.source as GraphNode).id; const t = (l.target as GraphNode).id
            return s === d.id || t === d.id ? 0.9 : 0.05
          })
      })

    // Glow for selected / hover
    node.append("circle")
      .attr("r", d => d.group === "memory" ? 9 : 6)
      .attr("fill", d => d.color)
      .attr("fill-opacity", 0.12)
      .attr("stroke", d => d.color)
      .attr("stroke-width", 1.5)

    // Inner dot
    node.append("circle")
      .attr("r", d => d.group === "memory" ? 4 : 3)
      .attr("fill", d => d.color)
      .attr("opacity", 0.8)

    // Label
    node.append("text")
      .attr("dy", d => d.group === "memory" ? 20 : 17)
      .attr("text-anchor", "middle")
      .attr("font-size", 9).attr("font-family", "Inter, sans-serif")
      .attr("fill", "var(--t-500)").attr("pointer-events", "none")
      .text(d => d.label.length > 14 ? d.label.slice(0, 12) + "…" : d.label)

    sim.on("tick", () => {
      link.attr("x1", d => (d.source as any).x ?? 0).attr("y1", d => (d.source as any).y ?? 0)
          .attr("x2", d => (d.target as any).x ?? 0).attr("y2", d => (d.target as any).y ?? 0)
      node.attr("transform", d => `translate(${(d as any).x ?? 0},${(d as any).y ?? 0})`)
    })

    setTimeout(() => {
      const b = (g.node() as SVGGElement)?.getBBox?.()
      if (b && b.width > 0) {
        const scale = Math.min(0.85, Math.min(W / b.width, H / b.height) * 0.85)
        const tx = W / 2 - scale * (b.x + b.width / 2)
        const ty = H / 2 - scale * (b.y + b.height / 2)
        svg.transition().duration(700).call(zoom.transform, d3.zoomIdentity.translate(tx, ty).scale(scale))
      }
    }, 1000)
    return () => sim.stop()
  }, [data, filter])

  useEffect(() => { const c = renderGraph(); return () => { c?.(); simRef.current?.stop() } }, [renderGraph])

  const groups = data ? [...new Set(data.nodes.map(n => n.group))].sort() : []
  const projName = workspace?.split(/[\\/]/).filter(Boolean).pop() ?? "project"

  return (
    <div className="gv-root">

      {/* ── Header — same style as workspace titlebar ── */}
      <div className="gv-header">
        <button className="ic" onClick={onClose} title="Back to editor">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>

        <div className="gv-header-title">
          <span className="gv-proj-name">{projName}</span>
          <span className="gv-header-sep">·</span>
          <span className="gv-page-name">Graph</span>
          {data && (
            <span className="gv-stats">
              {data.stats.files} files · {data.stats.connections} edges
              {data.stats.memory > 0 && ` · ${data.stats.memory} memory`}
            </span>
          )}
        </div>

        {/* Filter chips */}
        {!loading && data && groups.length > 0 && (
          <div className="gv-filters">
            <button className={`gv-chip${filter === "all" ? " on" : ""}`} onClick={() => setFilter("all")}>
              All
            </button>
            {groups.map(gr => (
              <button
                key={gr}
                className={`gv-chip${filter === gr ? " on" : ""}`}
                onClick={() => setFilter(gr)}
              >
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: GROUP_COLORS[gr] ?? "#a1a1aa", display: "inline-block", flexShrink: 0 }} />
                {GROUP_LABELS[gr] ?? gr}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ── Canvas ── */}
      <div className="gv-canvas">
        {loading && (
          <div className="gv-state">
            <svg className="spin" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: "var(--accent)" }}>
              <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
            </svg>
            <span>Building graph…</span>
          </div>
        )}
        {error && (
          <div className="gv-state" style={{ color: "#dc2626" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            Failed to load — restart backend
          </div>
        )}
        {!loading && !error && <svg ref={svgRef} style={{ width: "100%", height: "100%" }} />}

        {/* Node detail card — same card style as workspace */}
        {selected && (
          <div className="gv-card">
            <div className="gv-card-head">
              <span style={{ width: 10, height: 10, borderRadius: "50%", background: selected.color, display: "inline-block", flexShrink: 0 }} />
              <span className="gv-card-name">{selected.label}</span>
              <button className="ic" style={{ marginLeft: "auto" }} onClick={e => { e.stopPropagation(); setSelected(null) }}>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>
              </button>
            </div>

            {selected.path && (
              <div className="gv-card-path">{selected.path}</div>
            )}

            <div style={{ display: "flex", gap: 5, marginBottom: 10 }}>
              <span className="gv-tag" style={{ background: `${selected.color}18`, color: selected.color }}>
                {GROUP_LABELS[selected.group] ?? selected.group}
              </span>
              {selected.ext && <span className="gv-tag">{selected.ext}</span>}
            </div>

            {data && (() => {
              const out = data.edges.filter(e => (e.source as GraphNode).id === selected.id)
              const inn = data.edges.filter(e => (e.target as GraphNode).id === selected.id)
              return (
                <div className="gv-card-conns">
                  {out.length > 0 && <>
                    <div className="gv-conn-label">Imports ({out.length})</div>
                    {out.slice(0, 4).map((e, i) => <div key={i} className="gv-conn-row">→ {(e.target as GraphNode).label}</div>)}
                  </>}
                  {inn.length > 0 && <>
                    <div className="gv-conn-label" style={{ marginTop: 8 }}>Used by ({inn.length})</div>
                    {inn.slice(0, 4).map((e, i) => <div key={i} className="gv-conn-row">← {(e.source as GraphNode).label}</div>)}
                  </>}
                </div>
              )
            })()}
          </div>
        )}
      </div>

      {/* ── Footer ── */}
      <div className="gv-footer">
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          {groups.slice(0, 6).map(gr => (
            <span key={gr} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: "var(--t-400)" }}>
              <span style={{ width: 7, height: 7, borderRadius: "50%", background: GROUP_COLORS[gr] ?? "#a1a1aa", display: "inline-block" }} />
              {GROUP_LABELS[gr] ?? gr}
            </span>
          ))}
        </div>
        <span style={{ marginLeft: "auto", fontSize: 10.5, color: "var(--t-300)" }}>
          Scroll to zoom · Drag nodes · Click to inspect
        </span>
      </div>
    </div>
  )
}
