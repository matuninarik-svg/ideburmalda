import { useState } from 'react'
import { useIde } from "@/state/state"
import { TitleBar } from "@/components/TitleBar"
import { SettingsSidebar } from "@/components/settings/SettingsSidebar"
import { AgentSettings } from "@/components/settings/AgentSettings"
import { AppearanceSettings } from "@/components/settings/AppearanceSettings"
import { TerminalSettings } from "@/components/settings/TerminalSettings"
import { GitSettings } from "@/components/settings/GitSettings"
import { PrivacySettings } from "@/components/settings/PrivacySettings"

type SettingsPage = 'Agent' | 'Appearance' | 'Terminal' | 'Git' | 'Privacy'

export function Settings() {
  const [currentPage, setCurrentPage] = useState<SettingsPage>('Agent')
  const { closeSettings } = useIde()

  const renderContent = () => {
    switch (currentPage) {
      case 'Agent':
        return <AgentSettings />
      case 'Appearance':
        return <AppearanceSettings />
      case 'Terminal':
        return <TerminalSettings />
      case 'Git':
        return <GitSettings />
      case 'Privacy':
        return <PrivacySettings />
      default:
        return <AgentSettings />
    }
  }

  return (
    <div className="settings-container">
      <TitleBar
        left={
          <>
            <button className="qbtn" onClick={closeSettings} title="Back to IDE">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <polyline points="15 18 9 12 15 6"/>
              </svg>
            </button>
            <span className="name">Settings</span>
          </>
        }
      />

      <div className="settings-body">
        <SettingsSidebar currentPage={currentPage} onPageChange={setCurrentPage} />
        <div className="settings-content">
          <div className="page-title">{currentPage}</div>
          {renderContent()}
        </div>
      </div>
    </div>
  )
}
