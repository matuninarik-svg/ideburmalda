import { useState, useRef, useEffect } from "react"
import { WorkspaceTitleBar } from "@/components/TitleBar"
import { Explorer } from "@/components/Explorer"
import { Editor } from "@/components/Editor"
import { Terminal } from "@/components/Terminal"
import { ChatPanel } from "@/components/ChatPanel"
import { SessionHistory } from "@/components/SessionHistory"
import { Welcome } from "@/pages/Welcome"
import { Settings } from "@/pages/Settings"
import { Onboarding } from "@/pages/Onboarding"
import { IdeProvider, useIde } from "@/state/state"
import { ContextMenu } from "@/components/ContextMenu"
import { CommandPalette } from "@/components/CommandPalette"
import { StatusBar } from "@/components/StatusBar"
import { GitPanel } from "@/components/GitPanel"
import { GraphView } from "@/pages/GraphView"

function Divider({ dir, onDrag }: { dir: "h" | "v"; onDrag: (d: number) => void }) {
  const ref = useRef<HTMLDivElement>(null)

  function onMouseDown(e: React.MouseEvent) {
    e.preventDefault()
    let prev = dir === "h" ? e.clientX : e.clientY

    const move = (ev: MouseEvent) => {
      const cur = dir === "h" ? ev.clientX : ev.clientY
      onDrag(cur - prev)
      prev = cur
    }
    const up = () => {
      window.removeEventListener("mousemove", move)
      window.removeEventListener("mouseup", up)
    }
    window.addEventListener("mousemove", move)
    window.addEventListener("mouseup", up)
  }

  const isH = dir === "h"
  return (
    <div
      ref={ref}
      onMouseDown={onMouseDown}
      style={{
        flexShrink: 0,
        cursor: isH ? "col-resize" : "row-resize",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 20,
        userSelect: "none",
        ...(isH ? { width: 6, alignSelf: "stretch" } : { height: 6, alignSelf: "stretch" }),
      }}
      className="divider-handle"
    >
      <div className="divider-bar" style={isH ? { width: 2, height: 32, borderRadius: 9 } : { height: 2, width: 32, borderRadius: 9 }} />
    </div>
  )
}

function usePersist(key: string, def: number) {
  const stored = parseFloat(localStorage.getItem(key) ?? "")
  const [val, setVal] = useState(isNaN(stored) ? def : stored)
  const set = (v: number | ((p: number) => number)) => {
    setVal(prev => {
      const next = typeof v === "function" ? v(prev) : v
      localStorage.setItem(key, String(next))
      return next
    })
  }
  return [val, set] as const
}

function IdeContent() {
  const { currentProject, showSettings, showHistory, sidebarHidden } = useIde()
  const [showGit, setShowGit] = useState(false)
  const [showGraph, setShowGraph] = useState(false)
  const [explorerW, setExplorerW] = usePersist("ide.explorerW", 228)
  const [chatW, setChatW] = usePersist("ide.chatW", 360)
  const [termH, setTermH] = usePersist("ide.termH", 200)

  const [ctxMenu, setCtxMenu] = useState<{
    visible: boolean
    x: number
    y: number
    targetType: "explorer" | "editor" | "general"
    targetPath?: string
    targetKind?: "file" | "folder"
  }>({ visible: false, x: 0, y: 0, targetType: "general" })

  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault()
      
      let target = e.target as HTMLElement | null
      let targetPath: string | undefined
      let targetKind: "file" | "folder" | undefined
      let isExplorer = false
      let isEditor = false

      while (target) {
        if (target.getAttribute) {
          if (target.getAttribute("data-fs-path")) {
            targetPath = target.getAttribute("data-fs-path") || undefined
            targetKind = (target.getAttribute("data-fs-kind") as "file" | "folder") || undefined
            isExplorer = true
            break
          }
          if (target.getAttribute("data-explorer-root")) {
            isExplorer = true
            // no targetPath — user clicked empty explorer space
            break
          }
        }
        if (target.classList && (target.classList.contains("cm-content") || target.classList.contains("cm-editor") || target.classList.contains("code-view"))) {
          isEditor = true
        }
        target = target.parentElement
      }

      setCtxMenu({
        visible: true,
        x: e.clientX,
        y: e.clientY,
        targetType: isExplorer ? "explorer" : isEditor ? "editor" : "general",
        targetPath,
        targetKind,
      })
    }

    window.addEventListener("contextmenu", handleContextMenu)
    return () => {
      window.removeEventListener("contextmenu", handleContextMenu)
    }
  }, [])

  function onExplorerDrag(d: number) { setExplorerW(w => Math.max(140, Math.min(500, w + d))) }
  function onChatDrag(d: number) { setChatW(w => Math.max(240, Math.min(640, w - d))) }
  function onTermDrag(d: number) { setTermH(h => Math.max(80, Math.min(560, h - d))) }

  if (!currentProject) return <Welcome />
  if (showSettings) return <Settings />

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", overflow: "hidden", background: "var(--app)" }}>
      <WorkspaceTitleBar />

      {/* Main body */}
      <div style={{ flex: 1, minHeight: 0, display: "flex", padding: "0 8px 4px", gap: 0 }}>

        {/* Explorer */}
        {!sidebarHidden && (
          <>
            <div data-explorer-root="true" style={{ width: explorerW, flexShrink: 0, display: "flex", flexDirection: "column", minWidth: 0 }}>
              <Explorer />
            </div>

            <Divider dir="h" onDrag={onExplorerDrag} />
          </>
        )}

        {/* Center column */}
        <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>

          {/* Editor / Session History / Git / Graph */}
          <div style={{ flex: 1, minHeight: 0 }}>
            {showHistory ? <SessionHistory /> :
             showGit    ? <GitPanel /> :
             showGraph  ? <GraphView onClose={() => setShowGraph(false)} /> :
             <Editor />}
          </div>

          <Divider dir="v" onDrag={onTermDrag} />

          {/* Terminal */}
          <div style={{ height: termH, flexShrink: 0, minHeight: 0 }}>
            <Terminal />
          </div>

        </div>

        <Divider dir="h" onDrag={onChatDrag} />

        {/* Chat */}
        <div style={{ width: chatW, flexShrink: 0, display: "flex", flexDirection: "column", minWidth: 0 }}>
          <ChatPanel />
        </div>

      </div>

      <ContextMenu
        {...ctxMenu}
        onClose={() => setCtxMenu(prev => ({ ...prev, visible: false }))}
      />

      <StatusBar
        onGitClick={() => { setShowGit(g => !g); setShowGraph(false) }}
        gitActive={showGit}
        onGraphClick={() => { setShowGraph(g => !g); setShowGit(false) }}
        graphActive={showGraph}
      />
      <CommandPalette />
    </div>
  )
}

export function SharrowkinIde() {
  const [onboarded, setOnboarded] = useState(
    () => localStorage.getItem("ide.onboarded") === "true"
  )

  useEffect(() => {
    const size = localStorage.getItem("ide.fontSize") || "13px"
    document.documentElement.style.setProperty("--app-font-size", size)
  }, [])

  // Auto-spawn backend sidecar in Tauri
  useEffect(() => {
    let sidecarChild: any = null
    if (typeof window !== "undefined" && (window as any).__TAURI_INTERNALS__) {
      console.log("[Tauri Sidecar] Initializing backend sidecar...")
      import("@tauri-apps/plugin-shell")
        .then(({ Command }) => {
          const command = Command.sidecar("binaries/sharrowkin-backend")
          command.spawn()
            .then((child) => {
              console.log("[Tauri Sidecar] Spawned python backend", child)
              sidecarChild = child
            })
            .catch(err => {
              console.error("[Tauri Sidecar] Failed to spawn backend sidecar:", err)
            })
        })
        .catch(err => {
          console.error("[Tauri Sidecar] Failed to import shell plugin:", err)
        })
    }
    return () => {
      if (sidecarChild) {
        console.log("[Tauri Sidecar] Stopping sidecar backend...")
        sidecarChild.kill().catch(() => {})
      }
    }
  }, [])

  const handleOnboardingComplete = () => {
    setOnboarded(true)
  }

  return (
    <IdeProvider>
      {!onboarded
        ? <Onboarding onComplete={handleOnboardingComplete} />
        : <IdeContent />
      }
    </IdeProvider>
  )
}
