import { useState } from "react"

// The scripted "first turn" — static demo content (thinking, plan, tools, diff).
// Kept verbatim from the mockup. Only the thinking toggle is interactive.
export function DemoThread() {
  const [thinkOpen, setThinkOpen] = useState(false)

  return (
    <>
      {/* User message */}
      <div className="msg-u">
        <div className="bbl">
          Сделай так, чтобы агент знал про Preview и не открывал сырой <code>.html</code> файл
        </div>
      </div>

      <div className="msg-a">
        {/* Thinking — collapsible */}
        <div className="think-wrap">
          <button
            className={`think-toggle${thinkOpen ? " open" : ""}`}
            onClick={() => setThinkOpen((v) => !v)}
          >
            <svg className="spin" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <path d="M21 12a9 9 0 1 1-6.219-8.56" />
            </svg>
            Thinking · 3s
            <svg className="tchev" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>
          <div className={`think-body${thinkOpen ? " show" : ""}`}>
            Нужно найти где агент решает что делать с HTML файлами. Скорее всего в{" "}
            <code>build_system_prompt</code> или в обработчике <code>open_file</code>. Проверю оба места и пойму
            где лучше добавить инструкцию про Preview.
          </div>
        </div>

        {/* Plan */}
        <div className="plan-block">
          <div className="plan-head">
            <span className="plan-title">Plan</span>
            <span className="plan-count">2 / 5</span>
          </div>
          <div className="plan-list">
            <div className="plan-item done"><span className="plan-dot" /><span className="plan-text">Find where agent decides to open files</span></div>
            <div className="plan-item done"><span className="plan-dot" /><span className="plan-text">Read <code>build_system_prompt</code></span></div>
            <div className="plan-item active"><span className="plan-dot" /><span className="plan-text">Add Preview block to system prompt</span></div>
            <div className="plan-item todo"><span className="plan-dot" /><span className="plan-text">Replace <code>open_file</code> with server launch</span></div>
            <div className="plan-item todo"><span className="plan-dot" /><span className="plan-text">Run tests and verify</span></div>
          </div>
        </div>

        {/* Tool 1 */}
        <button className="tool-pill">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /></svg>
          <span className="tname">read_file</span>
          <span className="targ">agent/tool_loop.py</span>
          <span className="tok">✓</span>
        </button>

        <div className="reasoning">
          Вижу <code>build_system_prompt</code> на строке 36. Нет блока про Preview. Ищу все вызовы <code>open_file</code>.
        </div>

        {/* Tool 2 */}
        <button className="tool-pill">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
          <span className="tname">search_workspace</span>
          <span className="targ">open_file</span>
          <span className="tok">✓ 4 matches</span>
        </button>

        <div className="reasoning">
          Основной вызов на строке 44. Заменяю на <code>run_terminal_command</code> и добавляю Preview-инструкцию в промпт.
        </div>

        {/* Tool 3 */}
        <button className="tool-pill">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M12 20h9" /><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" /></svg>
          <span className="tname">write_file</span>
          <span className="targ">agent/tool_loop.py</span>
          <span className="tok">✓ saved</span>
        </button>

        <div className="reasoning">Сохранил. Проверяю тесты.</div>

        {/* Tool 4 */}
        <button className="tool-pill">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><polyline points="4 17 10 11 4 5" /><line x1="12" y1="19" x2="20" y2="19" /></svg>
          <span className="tname">run_tests</span>
          <span className="targ">tests/test_tool_loop.py</span>
          <span className="tok">✓ 12 passed</span>
        </button>

        {/* Final prose */}
        <div className="prose">
          Готово. Добавил Preview-блок в системный промпт, заменил <code>open_file</code> на{" "}
          <code>run_terminal_command</code>. Все 12 тестов прошли.<span className="scursor" />
        </div>

        {/* Diff */}
        <div className="diff">
          <div className="diff-head">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /></svg>
            agent/tool_loop.py
            <div className="diff-stat"><span className="a">+4</span><span className="d">−1</span></div>
          </div>
          <div className="diff-body">
            <div className="dl hunk"><span className="dl-n" />@@ -36,7 +36,11 @@</div>
            <div className="dl ctx"><span className="dl-n">36</span>  base = TOOL_LOOP_SYSTEM_PROMPT</div>
            <div className="dl del"><span className="dl-n">37</span>- tool_call("open_file", path=html_path)</div>
            <div className="dl add"><span className="dl-n">37</span>+ preview = "Start a server; URL → Preview."</div>
            <div className="dl add"><span className="dl-n">38</span>+ base += f"\n\nPREVIEW: {'{preview}'}"</div>
            <div className="dl add"><span className="dl-n">39</span>+ tool_call("run_terminal_command",</div>
            <div className="dl add"><span className="dl-n">40</span>+           cmd="python -m http.server 5500")</div>
            <div className="dl ctx"><span className="dl-n">41</span>  return base.replace("{'{workspace}'}", workspace)</div>
          </div>
          <div className="diff-foot">
            <button className="btn btn-primary"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12" /></svg>Apply</button>
            <button className="btn btn-soft">Reject</button>
            <button className="btn btn-soft ml-auto">Apply all</button>
          </div>
        </div>
      </div>
    </>
  )
}
