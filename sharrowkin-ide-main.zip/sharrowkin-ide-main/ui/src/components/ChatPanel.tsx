import { useState, useRef, useEffect } from "react"
import { useIde, type Mode } from "@/state/state"
import { Transcript } from "./LiveAgentTurn"

function EmptyChat() {
  return (
    <div style={{
      flex: 1, display: "flex", flexDirection: "column", alignItems: "center",
      justifyContent: "center", gap: 8, padding: "0 24px",
      color: "var(--t-400)", fontSize: 12.5, textAlign: "center",
    }}>
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.3" style={{ color: "var(--t-300)" }}>
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
      <span style={{ color: "var(--t-500)", fontWeight: 500 }}>New session</span>
      <span style={{ color: "var(--t-400)", lineHeight: 1.5 }}>Ask the agent anything or describe a task to get started</span>
    </div>
  )
}

const MODES: { mode: Mode; icon: React.ReactNode }[] = [
  {
    mode: "Agent",
    icon: (
      <svg className="mdopt-i" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="11" width="18" height="10" rx="3" /><circle cx="12" cy="5" r="2" /><path d="M12 7v4" /></svg>
    ),
  },
  {
    mode: "Edit",
    icon: (
      <svg className="mdopt-i" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M12 20h9" /><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" /></svg>
    ),
  },
  {
    mode: "Ask",
    icon: (
      <svg className="mdopt-i" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" /></svg>
    ),
  },
]

function ModelIcon({ id, size = 14 }: { id: string; size?: number }) {
  const s = { width: size, height: size, flexShrink: 0 as const, display: "block" as const }
  if (id.startsWith("claude"))
    return <img src="https://cdn.simpleicons.org/anthropic/d97706" {...s} alt="Claude" />
  if (id.startsWith("gpt") || id.startsWith("o"))
    return <img src="https://cdn.simpleicons.org/openai/059669" {...s} alt="OpenAI" />
  if (id.startsWith("gemini"))
    return <img src="https://cdn.simpleicons.org/googlegemini/4285F4" {...s} alt="Gemini" />
  return <img src="https://cdn.simpleicons.org/openrouter/7c3aed" {...s} alt="OpenRouter" />
}

const MODELS = [
  { id: "claude-opus-4-5",   label: "Claude Opus 4.5",   tier: "pro" },
  { id: "claude-sonnet-4-5", label: "Sonnet 4.5",        tier: "free" },
  { id: "claude-haiku-4-5",  label: "Haiku 4.5",         tier: "free" },
  { id: "gpt-4o",            label: "GPT-4o",            tier: "pro" },
  { id: "gemini-2-pro",      label: "Gemini 2 Pro",      tier: "pro" },
]

export function ChatPanel() {
  const { turns, sendMessage, isRunning, stopAgent, newSession, openHistory, mode, setMode, pills, removePill, systemPrompt, setSystemPrompt } = useIde()
  const [draft, setDraft] = useState("")
  const [dropOpen, setDropOpen] = useState(false)
  const [modelOpen, setModelOpen] = useState(false)
  const [model, setModel] = useState(MODELS[1])
  const [sysOpen, setSysOpen] = useState(false)
  const [selectedImage, setSelectedImage] = useState<{ name: string; url: string } | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const bodyRef = useRef<HTMLDivElement>(null)
  const stickRef = useRef(true)

  function scrollToBottom(force = false) {
    const el = bodyRef.current
    if (!el) return
    if (force || stickRef.current) {
      el.scrollTop = el.scrollHeight
    }
  }

  useEffect(() => {
    const el = bodyRef.current
    if (!el) return

    // Release sticky when user scrolls up more than 80px from bottom
    const onScroll = () => {
      const dist = el.scrollHeight - el.scrollTop - el.clientHeight
      stickRef.current = dist < 80
    }
    el.addEventListener("scroll", onScroll, { passive: true })

    // ResizeObserver — fires when content grows (text streaming, new tool pills)
    const ro = new ResizeObserver(() => scrollToBottom())
    ro.observe(el)

    // MutationObserver — fires when new DOM nodes are added (new turns, tool rows)
    const mo = new MutationObserver(() => scrollToBottom())
    mo.observe(el, { childList: true, subtree: true })

    return () => {
      el.removeEventListener("scroll", onScroll)
      ro.disconnect()
      mo.disconnect()
    }
  }, [])

  // New turn → always snap to bottom and re-arm
  useEffect(() => {
    stickRef.current = true
    scrollToBottom(true)
  }, [turns.length])

  // While agent is running → force scroll every 300ms as fallback
  useEffect(() => {
    if (!isRunning) return
    const id = setInterval(() => scrollToBottom(), 300)
    return () => clearInterval(id)
  }, [isRunning])

  function closeDrops() { setDropOpen(false); setModelOpen(false); setSysOpen(false) }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    const url = URL.createObjectURL(file)
    setSelectedImage({ name: file.name, url })
  }

  function triggerUpload() {
    fileInputRef.current?.click()
  }

  function submit() {
    if (isRunning) { stopAgent(); return }
    let msg = draft
    if (selectedImage) {
      msg += `\n\n[Attached Image: ${selectedImage.name}]`
    }
    sendMessage(msg)
    setDraft("")
    setSelectedImage(null)
  }

  return (
    <aside className="card ai" onClick={closeDrops}>
      <div className="ai-head">
        <span className="ai-name">Sharrowkin</span>
        <div className="ai-head-acts">
          <button
            className="ic"
            title="System prompt"
            onClick={(e) => { e.stopPropagation(); setSysOpen(v => !v); setDropOpen(false); setModelOpen(false) }}
            style={{ background: systemPrompt ? "var(--soft)" : undefined, color: systemPrompt ? "var(--accent)" : undefined }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
              <path d="M12 2a10 10 0 1 0 0 20A10 10 0 0 0 12 2z"/>
              <path d="M12 8v4M12 16h.01"/>
            </svg>
          </button>
          <button className="ic" title="New session" onClick={(e) => { e.stopPropagation(); newSession() }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
              <path d="M12 5v14M5 12h14"/>
            </svg>
          </button>
          <button className="ic" title="Session history" onClick={(e) => { e.stopPropagation(); openHistory() }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" /><path d="M12 7v5l4 2" /></svg>
          </button>
        </div>
      </div>

      {/* System Prompt modal — onboarding style */}
      {sysOpen && (
        <div className="sys-overlay" onClick={() => setSysOpen(false)}>
          <div className="sys-modal" onClick={e => e.stopPropagation()}>
            {/* Header with icon */}
            <div className="sys-modal-head">
              <div className="sys-modal-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                  <path d="M12 2a10 10 0 1 0 0 20A10 10 0 0 0 12 2z"/>
                  <path d="M12 8v4M12 16h.01"/>
                </svg>
              </div>
              <div style={{ flex: 1 }}>
                <div className="sys-modal-title">System Prompt</div>
                <div className="sys-modal-sub">Injected into every agent request in this session</div>
              </div>
              <button className="ic" onClick={() => setSysOpen(false)}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/>
                </svg>
              </button>
            </div>

            <div className="sys-modal-body">
              <textarea
                className="sys-textarea"
                placeholder={"Examples:\n• Always respond in Russian\n• Prefer functional programming style\n• Focus on performance and type safety\n• Never add comments to code"}
                value={systemPrompt}
                onChange={e => setSystemPrompt(e.target.value)}
                rows={6}
                autoFocus
              />
              {systemPrompt && (
                <div className="sys-char-hint">{systemPrompt.length} characters</div>
              )}
            </div>

            <div className="sys-modal-foot">
              {systemPrompt && (
                <button className="sys-clear-btn" onClick={() => setSystemPrompt("")}>
                  Clear
                </button>
              )}
              <button className="ob-btn-primary" style={{ marginLeft: "auto", padding: "8px 18px", fontSize: 13 }} onClick={() => setSysOpen(false)}>
                Apply
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="ai-body" ref={bodyRef}>
        <div className="ai-body-inner">
          {turns.length === 0 ? <EmptyChat /> : <Transcript />}
        </div>
      </div>

      <div className="ai-foot">
        <div className="composer">
          <div className="ctx-pills">
            {pills.map((p) => (
              <span className="cpill" key={p.id}>
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /></svg>
                {p.label}
                <span className="rm" onClick={() => removePill(p.id)}>×</span>
              </span>
            ))}
            {selectedImage && (
              <span className="cpill" style={{ gap: 6, paddingRight: 6 }}>
                <img src={selectedImage.url} style={{ width: 14, height: 14, borderRadius: 3, objectFit: "cover" }} />
                <span>{selectedImage.name}</span>
                <span className="rm" onClick={() => setSelectedImage(null)}>×</span>
              </span>
            )}
          </div>
          <textarea
            rows={2}
            placeholder="Ask anything…"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit() }
            }}
          />
          <div className="composer-bar">
            <div className="mode-chip-wrap">
              <button
                className={`mode-chip${dropOpen ? " open" : ""}`}
                onClick={(e) => { e.stopPropagation(); setDropOpen((v) => !v) }}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="11" width="18" height="10" rx="3" /><circle cx="12" cy="5" r="2" /><path d="M12 7v4" /></svg>
                <span>{mode}</span>
                <svg className="chevd" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2"><polyline points="6 9 12 15 18 9" /></svg>
              </button>
              <div className={`mode-drop${dropOpen ? " show" : ""}`}>
                {MODES.map(({ mode: m, icon }) => (
                  <div key={m} className={`mdopt${m === mode ? " on" : ""}`} onClick={() => { setMode(m); setDropOpen(false) }}>
                    {icon}
                    {m}
                    <svg className="mdcheck" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12" /></svg>
                  </div>
                ))}
              </div>
            </div>

            <div className="mode-chip-wrap" style={{ marginLeft: 4 }}>
              <button
                className={`mode-chip${modelOpen ? " open" : ""}`}
                onClick={(e) => { e.stopPropagation(); setModelOpen(v => !v); setDropOpen(false) }}
                style={{ gap: 5 }}
              >
                <ModelIcon id={model.id} size={13} />
                <span style={{ maxWidth: 100, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {model.label}
                </span>
                <svg className="chevd" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2"><polyline points="6 9 12 15 18 9" /></svg>
              </button>
              <div className={`mode-drop${modelOpen ? " show" : ""}`} style={{ minWidth: 200, left: "auto", right: 0 }}>
                {MODELS.map(m => (
                  <div key={m.id} className={`mdopt${m.id === model.id ? " on" : ""}`} onClick={() => { setModel(m); setModelOpen(false) }}>
                    <ModelIcon id={m.id} size={13} />
                    <span style={{ flex: 1, fontSize: 12.5 }}>{m.label}</span>
                    <span style={{ fontSize: 9.5, fontWeight: 600, padding: "1px 5px", borderRadius: 4, background: m.tier === "pro" ? "rgba(37,99,235,0.08)" : "rgba(5,150,105,0.08)", color: m.tier === "pro" ? "#2563eb" : "#059669" }}>{m.tier}</span>
                    <svg className="mdcheck" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12" /></svg>
                  </div>
                ))}
              </div>
            </div>

            <div className="c-right">
              <span className="ctx-hint">4.2k</span>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                style={{ display: "none" }}
                onChange={handleFileChange}
              />
              <button className="attach-btn" title="Add context" onClick={triggerUpload}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
              </button>
              <button className="send" onClick={submit}>
                {isRunning ? "Stop" : "Send"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </aside>
  )
}
