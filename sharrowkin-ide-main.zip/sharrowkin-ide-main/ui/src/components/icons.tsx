// Inline file-type glyphs reused by Explorer, tabs, diff headers, context pills.
// Verbatim from the mockup so visuals stay 1:1.

export function FolderGlyph() {
  return (
    <svg viewBox="0 0 24 24" fill="none">
      <path
        d="M3 7.5A1.5 1.5 0 0 1 4.5 6h4l1.8 1.8H19.5A1.5 1.5 0 0 1 21 9.3v8.2a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 17.5z"
        fill="#dddde3"
      />
    </svg>
  )
}

export function PyGlyph() {
  return (
    <svg viewBox="0 0 24 24">
      <path
        d="M11.9 2c-2.5 0-2.3 1.1-2.3 1.1V5h2.4v.6H7.4S5.5 5.4 5.5 8.5s1.7 2.9 1.7 2.9h1.3v-1.4s-.1-1.7 1.6-1.7h2.7s1.6 0 1.6-1.6V3.6S16 2 11.9 2z"
        fill="#60a5fa"
      />
      <path
        d="M12.1 22c2.5 0 2.3-1.1 2.3-1.1V19h-2.4v-.6h4.6s1.9.2 1.9-2.9-1.7-2.9-1.7-2.9h-1.3v1.4s.1 1.7-1.6 1.7H10.2s-1.6 0-1.6 1.6v2.7S8 22 12.1 22z"
        fill="#fcd34d"
      />
    </svg>
  )
}

export function TsxGlyph() {
  return (
    <svg viewBox="0 0 24 24" fill="none">
      <ellipse cx="12" cy="12" rx="10" ry="3.8" stroke="#22d3ee" strokeWidth="1.1" />
      <ellipse cx="12" cy="12" rx="10" ry="3.8" stroke="#22d3ee" strokeWidth="1.1" transform="rotate(60 12 12)" />
      <ellipse cx="12" cy="12" rx="10" ry="3.8" stroke="#22d3ee" strokeWidth="1.1" transform="rotate(120 12 12)" />
      <circle cx="12" cy="12" r="1.6" fill="#22d3ee" />
    </svg>
  )
}

export function MdGlyph() {
  return (
    <svg viewBox="0 0 24 24" fill="none">
      <rect x="2.5" y="6" width="19" height="12" rx="2" stroke="#60a5fa" strokeWidth="1.4" />
      <path
        d="M6 15v-6l2.4 2.6L10.8 9v6M14 9v4m0 0 1.7-1.8M14 13l-1.7-1.8"
        stroke="#60a5fa"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export type FileKind = "py" | "tsx" | "md" | "folder"

export function FileGlyph({ kind }: { kind: FileKind }) {
  if (kind === "py") return <PyGlyph />
  if (kind === "tsx") return <TsxGlyph />
  if (kind === "md") return <MdGlyph />
  return <FolderGlyph />
}
