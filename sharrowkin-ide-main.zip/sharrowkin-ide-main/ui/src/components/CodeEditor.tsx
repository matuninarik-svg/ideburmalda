import { useEffect, useRef } from 'react'
import { EditorState, StateEffect, StateField, RangeSetBuilder } from '@codemirror/state'
import { EditorView, keymap, lineNumbers, highlightActiveLine, drawSelection, Decoration, type DecorationSet, WidgetType } from '@codemirror/view'
import { indentWithTab, defaultKeymap, historyKeymap, history } from '@codemirror/commands'
import { bracketMatching, indentOnInput } from '@codemirror/language'
import { closeBrackets, closeBracketsKeymap } from '@codemirror/autocomplete'
import { python } from '@codemirror/lang-python'
import { javascript } from '@codemirror/lang-javascript'
import { html } from '@codemirror/lang-html'
import { json } from '@codemirror/lang-json'
import { markdown } from '@codemirror/lang-markdown'
import { autocompletion, completionKeymap, Completion } from '@codemirror/autocomplete'
import { sharrowkinTheme, sharrowkinSyntax } from "@/utils/cmTheme"
import type { FileDiffMarks } from "@/utils/editorDiff"

interface CodeEditorProps {
  language?: 'python' | 'javascript' | 'html' | 'json' | 'markdown'
  initialCode?: string
  onChange?: (code: string) => void
  onAskAI?: (selectedText: string) => void
  onReady?: () => void
  diffMarks?: FileDiffMarks | null
  jumpToLine?: number
}

// ─── Agent-edit diff decorations ────────────────────────────────────────────
// Added lines get a green background + left bar. Removed lines render as red
// "ghost" rows (the actual deleted text, struck through) inserted above the line
// where the deletion occurred — the way Cursor / VS Code inline diffs read.
const setDiffMarks = StateEffect.define<FileDiffMarks | null>()

const addedLineDeco = Decoration.line({ class: "cm-diff-added" })

// A block widget that paints one or more removed lines as red ghost text.
class DeletedLinesWidget extends WidgetType {
  constructor(readonly text: string[]) {
    super()
  }
  eq(other: DeletedLinesWidget) {
    return other.text.length === this.text.length && other.text.every((l, i) => l === this.text[i])
  }
  toDOM() {
    const wrap = document.createElement("div")
    wrap.className = "cm-diff-removed-block"
    for (const line of this.text) {
      const row = document.createElement("div")
      row.className = "cm-diff-removed-line"
      // Render whitespace-only / empty removed lines with a visible height.
      row.textContent = line.length ? line : " "
      wrap.appendChild(row)
    }
    return wrap
  }
  ignoreEvent() {
    return true
  }
}

function buildDiffDecos(doc: EditorState["doc"], marks: FileDiffMarks | null): DecorationSet {
  const builder = new RangeSetBuilder<Decoration>()
  if (!marks) return builder.finish()
  const total = doc.lines
  const added = new Set(marks.added.filter((n) => n >= 1 && n <= total))

  // Group deletions by their anchor line so widgets insert in document order.
  const delByLine = new Map<number, string[]>()
  for (const d of marks.deleted) {
    const anchor = Math.min(Math.max(d.line, 1), total + 1)
    const prev = delByLine.get(anchor) ?? []
    delByLine.set(anchor, [...prev, ...d.text])
  }

  // Walk lines in order. At each line, first emit any deletion widget anchored
  // there (it sits ABOVE the line via side:-1), then the added-line background.
  for (let line = 1; line <= total; line++) {
    const pos = doc.line(line).from
    const removed = delByLine.get(line)
    if (removed && removed.length) {
      builder.add(pos, pos, Decoration.widget({ widget: new DeletedLinesWidget(removed), side: -1, block: true }))
    }
    if (added.has(line)) builder.add(pos, pos, addedLineDeco)
  }
  // Deletions at end-of-file are anchored past the last line — render them
  // as a ghost block after the final line (side:1).
  const tail = delByLine.get(total + 1)
  if (tail && tail.length) {
    const end = doc.line(total).to
    builder.add(end, end, Decoration.widget({ widget: new DeletedLinesWidget(tail), side: 1, block: true }))
  }
  return builder.finish()
}

const diffField = StateField.define<{ marks: FileDiffMarks | null; decos: DecorationSet }>({
  create: () => ({ marks: null, decos: Decoration.none }),
  update(value, tr) {
    for (const e of tr.effects) {
      if (e.is(setDiffMarks)) {
        return { marks: e.value, decos: buildDiffDecos(tr.state.doc, e.value) }
      }
    }
    if (tr.docChanged && value.marks) {
      return { marks: value.marks, decos: value.decos.map(tr.changes) }
    }
    return value
  },
  provide: (f) => EditorView.decorations.from(f, (v) => v.decos),
})

const languageSupport = {
  python: python(),
  javascript: javascript(),
  html: html(),
  json: json(),
  markdown: markdown(),
}

const pythonCompletions: Completion[] = [
  { label: 'def', type: 'keyword' }, { label: 'class', type: 'keyword' },
  { label: 'return', type: 'keyword' }, { label: 'import', type: 'keyword' },
  { label: 'from', type: 'keyword' }, { label: 'if', type: 'keyword' },
  { label: 'else', type: 'keyword' }, { label: 'elif', type: 'keyword' },
  { label: 'for', type: 'keyword' }, { label: 'while', type: 'keyword' },
  { label: 'try', type: 'keyword' }, { label: 'except', type: 'keyword' },
  { label: 'finally', type: 'keyword' }, { label: 'with', type: 'keyword' },
  { label: 'lambda', type: 'keyword' }, { label: 'pass', type: 'keyword' },
  { label: 'break', type: 'keyword' }, { label: 'continue', type: 'keyword' },
  { label: 'async', type: 'keyword' }, { label: 'await', type: 'keyword' },
  { label: 'yield', type: 'keyword' }, { label: 'assert', type: 'keyword' },
  { label: 'del', type: 'keyword' }, { label: 'raise', type: 'keyword' },
  { label: 'global', type: 'keyword' }, { label: 'nonlocal', type: 'keyword' },
  { label: 'True', type: 'constant' }, { label: 'False', type: 'constant' }, { label: 'None', type: 'constant' },
  { label: 'print', type: 'function', detail: 'built-in' },
  { label: 'len', type: 'function', detail: 'built-in' },
  { label: 'range', type: 'function', detail: 'built-in' },
  { label: 'enumerate', type: 'function', detail: 'built-in' },
  { label: 'zip', type: 'function', detail: 'built-in' },
  { label: 'map', type: 'function', detail: 'built-in' },
  { label: 'filter', type: 'function', detail: 'built-in' },
  { label: 'sorted', type: 'function', detail: 'built-in' },
  { label: 'reversed', type: 'function', detail: 'built-in' },
  { label: 'list', type: 'function', detail: 'built-in' },
  { label: 'dict', type: 'function', detail: 'built-in' },
  { label: 'set', type: 'function', detail: 'built-in' },
  { label: 'tuple', type: 'function', detail: 'built-in' },
  { label: 'str', type: 'function', detail: 'built-in' },
  { label: 'int', type: 'function', detail: 'built-in' },
  { label: 'float', type: 'function', detail: 'built-in' },
  { label: 'bool', type: 'function', detail: 'built-in' },
  { label: 'open', type: 'function', detail: 'built-in' },
  { label: 'input', type: 'function', detail: 'built-in' },
  { label: 'super', type: 'function', detail: 'built-in' },
  { label: 'hasattr', type: 'function', detail: 'built-in' },
  { label: 'getattr', type: 'function', detail: 'built-in' },
  { label: 'setattr', type: 'function', detail: 'built-in' },
  { label: 'isinstance', type: 'function', detail: 'built-in' },
  { label: 'self', type: 'variable' },
  { label: 'cls', type: 'variable' },
]

export function CodeEditor({ language = 'python', initialCode = '', onChange, onAskAI, onReady, diffMarks, jumpToLine }: CodeEditorProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const editorRef = useRef<EditorView | null>(null)
  const popupRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!containerRef.current) return

    const completeCompletions = (context: any) => {
      const word = context.matchBefore(/\w+/)
      if (!word || (word.from === word.to && !context.explicit)) return null
      const options = pythonCompletions.filter(c =>
        c.label.toLowerCase().startsWith(word.text.toLowerCase())
      )
      return options.length > 0 ? { from: word.from, options } : null
    }

    const state = EditorState.create({
      doc: initialCode,
      extensions: [
        lineNumbers(),
        diffField,
        history(),
        highlightActiveLine(),
        drawSelection(),
        bracketMatching(),
        closeBrackets(),
        indentOnInput(),
        keymap.of([
          ...closeBracketsKeymap,
          ...defaultKeymap,
          ...historyKeymap,
          indentWithTab,
          ...completionKeymap,
        ]),
        EditorView.updateListener.of((update) => {
          if (update.docChanged && onChange) {
            onChange(update.state.doc.toString())
          }
          // Show/hide Ask AI popup on selection
          if (update.selectionSet || update.docChanged) {
            const sel = update.state.selection.main
            const popup = popupRef.current
            if (!popup) return
            if (!sel.empty) {
              const coords = update.view.coordsAtPos(sel.head)
              if (coords) {
                const parent = containerRef.current!.getBoundingClientRect()
                const left = Math.min(coords.left - parent.left, parent.width - 220)
                const top = coords.top - parent.top - 52
                popup.style.left = `${Math.max(8, left)}px`
                popup.style.top = `${Math.max(8, top)}px`
                popup.style.display = 'flex'
              }
            } else {
              popup.style.display = 'none'
            }
          }
        }),
        ...(languageSupport[language] ? [languageSupport[language]] : []),
        autocompletion({
          override: [completeCompletions],
          defaultKeymap: true,
          activateOnTyping: true,
          maxRenderedOptions: 10,
        }),
        sharrowkinTheme,
        sharrowkinSyntax,
      ],
    })

    const view = new EditorView({ state, parent: containerRef.current })
    editorRef.current = view
    // Apply any diff marks present at mount (file opened after an agent edit).
    if (diffMarks) view.dispatch({ effects: setDiffMarks.of(diffMarks) })
    onReady?.()

    return () => { view.destroy(); editorRef.current = null }
  }, [])

  // Jump to a specific line when requested (e.g. after clicking a tool call).
  useEffect(() => {
    if (!jumpToLine || jumpToLine < 1) return
    const view = editorRef.current
    if (!view) return
    const lineCount = view.state.doc.lines
    const target = Math.min(jumpToLine, lineCount)
    const line = view.state.doc.line(target)
    view.dispatch({
      selection: { anchor: line.from },
      effects: EditorView.scrollIntoView(line.from, { y: 'center' }),
    })
  }, [jumpToLine])

  // Push diff marks into the live editor whenever they change.
  useEffect(() => {
    const view = editorRef.current
    if (!view) return
    view.dispatch({ effects: setDiffMarks.of(diffMarks ?? null) })
  }, [diffMarks])

  function handleAskAI() {
    const view = editorRef.current
    if (!view) return
    const sel = view.state.selection.main
    const text = view.state.sliceDoc(sel.from, sel.to)
    if (popupRef.current) popupRef.current.style.display = 'none'
    view.dispatch({ selection: { anchor: sel.to } })
    onAskAI?.(text)
  }

  function handleAddContext() {
    if (popupRef.current) popupRef.current.style.display = 'none'
  }

  return (
    <div ref={containerRef} style={{ width: '100%', height: '100%', position: 'relative', overflow: 'hidden' }}>
      <div ref={popupRef} className="code-sel-popup" style={{ display: 'none' }}>
        <button className="code-sel-btn" onClick={handleAskAI}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          Ask AI
        </button>
        <div className="code-sel-sep" />
        <button className="code-sel-btn" onClick={handleAddContext}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 5v14M5 12h14"/>
          </svg>
          Add to context
        </button>
      </div>
    </div>
  )
}
