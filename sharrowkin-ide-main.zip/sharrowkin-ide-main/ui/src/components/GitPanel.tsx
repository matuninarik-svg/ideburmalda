import { useEffect, useState, useCallback } from "react"
import { useIde } from "@/state/state"
import { BASE } from "@/services/api"

type GitStatus = { modified: string[]; added: string[]; deleted: string[]; untracked: string[] }
type GitInfo   = { branch: string; commits: {hash:string;message:string}[]; remote: string; ahead: number; behind: number }
type LoadState = "idle" | "loading" | "error" | "ok"

// ── GitHub connect modal ──────────────────────────────────────────────────────
function GitHubModal({ onClose }: { onClose: () => void }) {
  const [token, setToken] = useState("")
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  async function save() {
    if (!token.trim()) return
    setSaving(true)
    try {
      await fetch(`${BASE}/api/settings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ github_token: token.trim() }),
      })
      setSaved(true)
      setTimeout(onClose, 1200)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="gh-overlay" onClick={onClose}>
      <div className="gh-modal" onClick={e => e.stopPropagation()}>
        <div className="gh-modal-head">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style={{ color: "var(--t-700)" }}>
            <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12z"/>
          </svg>
          <div>
            <div className="gh-modal-title">Connect GitHub</div>
            <div className="gh-modal-sub">Use a Personal Access Token to push &amp; pull</div>
          </div>
          <button className="ic" onClick={onClose} style={{ marginLeft: "auto" }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/>
            </svg>
          </button>
        </div>

        <div className="gh-modal-body">
          <div className="gh-step">
            <span className="gh-step-num">1</span>
            <div>
              Go to{" "}
              <button className="git-link" onClick={() => window.open("https://github.com/settings/tokens/new?scopes=repo,workflow&description=Sharrowkin+IDE", "_blank")}>
                GitHub → Settings → Tokens ↗
              </button>
              {" "}and generate a token with <code>repo</code> scope.
            </div>
          </div>
          <div className="gh-step">
            <span className="gh-step-num">2</span>
            <div style={{ flex: 1 }}>
              Paste your token:
              <input
                className="gh-token-input"
                type="password"
                placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                value={token}
                onChange={e => setToken(e.target.value)}
                onKeyDown={e => e.key === "Enter" && save()}
                autoFocus
              />
            </div>
          </div>
        </div>

        <div className="gh-modal-foot">
          <button className="git-btn-commit" style={{ flex: "none", padding: "7px 20px" }} onClick={onClose}>Cancel</button>
          <button
            className="git-btn-push"
            style={{ flex: "none", padding: "7px 20px" }}
            onClick={save}
            disabled={!token.trim() || saving}
          >
            {saved ? "Saved ✓" : saving ? "Saving…" : "Save token"}
          </button>
        </div>
      </div>
    </div>
  )
}

// ── File list ─────────────────────────────────────────────────────────────────
function FileList({ label, char, color, files }: { label: string; char: string; color: string; files: string[] }) {
  if (!files?.length) return null
  return (
    <div className="git-file-group">
      <div className="git-group-label">{label} <span className="git-count">{files.length}</span></div>
      {files.map(f => (
        <div key={f} className="git-file-row">
          <span style={{ fontSize: 10, fontWeight: 700, color, width: 14, textAlign: "center", flexShrink: 0 }}>{char}</span>
          <span className="git-file-name">{f.split(/[/\\]/).pop()}</span>
          <span className="git-file-path">{f}</span>
        </div>
      ))}
    </div>
  )
}

// ── Main panel ────────────────────────────────────────────────────────────────
export function GitPanel() {
  const { workspace } = useIde()
  const [status, setStatus]     = useState<GitStatus | null>(null)
  const [info, setInfo]         = useState<GitInfo | null>(null)
  const [loadState, setLoadState] = useState<LoadState>("idle")
  const [msg, setMsg]           = useState("")
  const [generating, setGenerating] = useState(false)
  const [committing, setCommitting] = useState(false)
  const [pushing, setPushing]   = useState(false)
  const [showGH, setShowGH]     = useState(false)
  const [toast, setToast]       = useState<{ text: string; ok: boolean } | null>(null)

  const showToast = (text: string, ok: boolean) => {
    setToast({ text, ok })
    setTimeout(() => setToast(null), 3500)
  }

  const refresh = useCallback(async () => {
    if (!workspace) return
    setLoadState("loading")
    try {
      const [s, i] = await Promise.all([
        fetch(`${BASE}/api/workspace/git-status?path=${encodeURIComponent(workspace)}`).then(r => r.ok ? r.json() : null),
        fetch(`${BASE}/api/workspace/git-info?path=${encodeURIComponent(workspace)}`).then(r => r.ok ? r.json() : null),
      ])
      setStatus(s ?? { modified: [], added: [], deleted: [], untracked: [] })
      setInfo(i ?? null)
      setLoadState("ok")
    } catch {
      setLoadState("error")
    }
  }, [workspace])

  useEffect(() => { refresh() }, [refresh])

  const total = (status?.modified?.length ?? 0) + (status?.added?.length ?? 0)
    + (status?.deleted?.length ?? 0) + (status?.untracked?.length ?? 0)

  const hasRemote = Boolean(info?.remote)
  const remoteShort = info?.remote
    ? info.remote.replace(/^https?:\/\//, "").replace(/\.git$/, "")
    : null

  async function generateMsg() {
    if (!workspace || generating) return
    setGenerating(true)
    try {
      const res = await fetch(`${BASE}/api/workspace/git-generate-message`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: workspace }),
      })
      if (res.ok) {
        const d = await res.json()
        setMsg(d.message ?? "")
      }
    } finally {
      setGenerating(false)
    }
  }

  async function commit() {
    if (!workspace || !msg.trim() || committing) return
    setCommitting(true)
    try {
      const res = await fetch(`${BASE}/api/workspace/git-commit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: workspace, message: msg.trim(), stage_all: true }),
      })
      if (!res.ok) {
        const e = await res.json().catch(() => ({}))
        showToast(e.detail ?? "Commit failed", false)
      } else {
        setMsg("")
        showToast("Committed ✓", true)
        await refresh()
      }
    } finally {
      setCommitting(false)
    }
  }

  async function push() {
    if (!workspace || pushing) return
    setPushing(true)
    try {
      const res = await fetch(`${BASE}/api/workspace/git-push`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: workspace, branch: info?.branch ?? "main" }),
      })
      if (!res.ok) {
        const e = await res.json().catch(() => ({}))
        showToast(e.detail ?? "Push failed", false)
      } else {
        showToast("Pushed to origin ✓", true)
        await refresh()
      }
    } finally {
      setPushing(false)
    }
  }

  return (
    <div className="git-panel">

      {/* Header */}
      <div className="git-header">
        <div style={{ flex: 1 }}>
          <div className="git-branch-row">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
              <path d="M18 9a9 9 0 0 1-9 9"/>
            </svg>
            <span className="git-branch-name">{info?.branch ?? "—"}</span>
            {(info?.ahead ?? 0) > 0 && <span className="git-pill git-ahead">↑ {info!.ahead}</span>}
            {(info?.behind ?? 0) > 0 && <span className="git-pill git-behind">↓ {info!.behind}</span>}
          </div>

          {hasRemote ? (
            <div className="git-remote-row">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor" style={{ color: "var(--t-400)" }}>
                <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12z"/>
              </svg>
              <span title={info?.remote} style={{ fontSize: 11.5, color: "var(--t-400)" }}>{remoteShort}</span>
            </div>
          ) : loadState === "ok" ? (
            <div className="git-no-remote">
              No remote —{" "}
              <button className="git-link" onClick={() => setShowGH(true)}>Connect GitHub</button>
            </div>
          ) : null}
        </div>

        <div style={{ display: "flex", gap: 2 }}>
          <button className="ic" title="Connect GitHub" onClick={() => setShowGH(true)}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" style={{ color: "var(--t-400)" }}>
              <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12z"/>
            </svg>
          </button>
          <button className="ic" title="Refresh" onClick={refresh}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5A10 10 0 0 1 3.2 16.7"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Commit */}
      <div className="git-commit-area">
        <div style={{ position: "relative" }}>
          <textarea
            className="git-msg-input"
            placeholder={total > 0 ? "Commit message…" : "Nothing to commit"}
            value={msg}
            rows={2}
            disabled={total === 0}
            onChange={e => setMsg(e.target.value)}
            onKeyDown={e => { if ((e.metaKey || e.ctrlKey) && e.key === "Enter") commit() }}
            style={{ paddingRight: 36 }}
          />
          {total > 0 && (
            <button
              className="git-ai-btn"
              title="Generate with AI"
              onClick={generateMsg}
              disabled={generating}
            >
              {generating
                ? <span className="git-ai-spin">⟳</span>
                : <span style={{ fontSize: 13 }}>✦</span>}
            </button>
          )}
        </div>
        <div className="git-btns">
          <button className="git-btn-commit" onClick={commit} disabled={committing || !msg.trim() || total === 0}>
            {committing ? "Committing…" : `Commit${total > 0 ? ` (${total})` : ""}`}
          </button>
          {hasRemote && (
            <button className="git-btn-push" onClick={push} disabled={pushing || (info?.ahead ?? 0) === 0}>
              {pushing ? "Pushing…" : (info?.ahead ?? 0) > 0 ? `Push ↑${info!.ahead}` : "Push"}
            </button>
          )}
          {!hasRemote && loadState === "ok" && (
            <button className="git-btn-push" onClick={() => setShowGH(true)}>
              Connect GitHub
            </button>
          )}
        </div>
      </div>

      {/* Changes */}
      <div className="git-scroll">
        {loadState === "loading" && <div className="git-state-msg">Loading…</div>}
        {loadState === "error" && <div className="git-state-msg" style={{ color: "#dc2626" }}>Could not read git status</div>}
        {loadState === "ok" && total === 0 && (
          <div className="git-state-msg">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" style={{ color: "var(--t-300)" }}>
              <polyline points="20 6 9 17 4 12"/>
            </svg>
            Working tree clean
          </div>
        )}
        {loadState === "ok" && total > 0 && (
          <>
            <FileList label="Modified"  char="M" color="#d97706" files={status?.modified  ?? []} />
            <FileList label="Added"     char="A" color="#16a34a" files={status?.added     ?? []} />
            <FileList label="Deleted"   char="D" color="#dc2626" files={status?.deleted   ?? []} />
            <FileList label="Untracked" char="U" color="#6366f1" files={status?.untracked ?? []} />
          </>
        )}
        {(info?.commits?.length ?? 0) > 0 && (
          <div className="git-log-section">
            <div className="git-group-label">Recent commits</div>
            {(info!.commits ?? []).map(c => (
              <div key={c.hash} className="git-log-row">
                <span className="git-log-hash">{c.hash}</span>
                <span className="git-log-msg">{c.message}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {toast && <div className={`git-toast ${toast.ok ? "ok" : "err"}`}>{toast.text}</div>}
      {showGH && <GitHubModal onClose={() => setShowGH(false)} />}
    </div>
  )
}
