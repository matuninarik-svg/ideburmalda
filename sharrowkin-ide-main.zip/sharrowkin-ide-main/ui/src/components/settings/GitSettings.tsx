import { useState, useEffect } from 'react'
import { CustomDropdown } from './CustomDropdown'
import { Toggle } from './Toggle'
import { BASE } from '@/services/api'

export function GitSettings() {
  const [username, setUsername] = useState('')
  const [token, setToken] = useState('')
  const [email, setEmail] = useState(() => localStorage.getItem('ide.git.email') || '')
  const [defaultBranch, setDefaultBranch] = useState(() => localStorage.getItem('ide.git.defaultBranch') || 'main')
  const [autoCommit, setAutoCommit] = useState(() => localStorage.getItem('ide.git.autoCommit') === 'true')
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    async function loadSettings() {
      setLoading(true)
      try {
        const res = await fetch(`${BASE}/api/settings`)
        if (res.ok) {
          const data = await res.json()
          setUsername(data.github_username || '')
          setToken(data.github_token ? '********' : '') // mask if exists
        }
      } catch (e) {
        console.error("Failed to load settings:", e)
      } finally {
        setLoading(false)
      }
    }
    loadSettings()
  }, [])

  async function saveBackendSettings(updates: any) {
    setSaving(true)
    try {
      const res = await fetch(`${BASE}/api/settings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      })
      if (!res.ok) {
        console.error("Failed to save settings")
      }
    } catch (e) {
      console.error("Failed to save settings:", e)
    } finally {
      setSaving(false)
    }
  }

  const handleEmailChange = (val: string) => {
    setEmail(val)
    localStorage.setItem('ide.git.email', val)
  }

  const handleBranchChange = (val: string) => {
    setDefaultBranch(val)
    localStorage.setItem('ide.git.defaultBranch', val)
  }

  const handleAutoCommitChange = (checked: boolean) => {
    setAutoCommit(checked)
    localStorage.setItem('ide.git.autoCommit', String(checked))
  }

  return (
    <>
      <div className="section">
        <div className="section-title" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>Identity</span>
          {saving && <span style={{ fontSize: '10px', color: 'var(--t-400)', textTransform: 'none' }}>Saving...</span>}
          {loading && <span style={{ fontSize: '10px', color: 'var(--t-400)', textTransform: 'none' }}>Loading...</span>}
        </div>
        <div className="card">
          <div className="row">
            <span className="row-label">
              <div className="row-title">GitHub Username</div>
              <div className="row-desc">Used for git operations identity</div>
            </span>
            <input
              className="field"
              value={username}
              placeholder="Username"
              onChange={(e) => setUsername(e.target.value)}
              onBlur={() => saveBackendSettings({ github_username: username })}
            />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">GitHub Token</div>
              <div className="row-desc">OAuth / Personal Access Token</div>
            </span>
            <input
              className="field"
              type="password"
              value={token}
              placeholder={token ? "********" : "ghp_..."}
              onChange={(e) => setToken(e.target.value)}
              onBlur={() => {
                if (token !== '********' && token !== '') {
                  saveBackendSettings({ github_token: token })
                }
              }}
            />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Git Email</div>
              <div className="row-desc">Author email for commits</div>
            </span>
            <input
              className="field"
              value={email}
              placeholder="email@example.com"
              onChange={(e) => handleEmailChange(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="section">
        <div className="section-title">Repository Settings</div>
        <div className="card">
          <div className="row">
            <span className="row-label">
              <div className="row-title">Default branch</div>
              <div className="row-desc">Branch used for new repositories</div>
            </span>
            <CustomDropdown
              value={defaultBranch}
              options={['main', 'master']}
              onChange={handleBranchChange}
            />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Auto-commit agent changes</div>
              <div className="row-desc">Commit changes automatically after the agent finishes a task</div>
            </span>
            <Toggle checked={autoCommit} onChange={handleAutoCommitChange} />
          </div>
        </div>
      </div>
    </>
  )
}
