import { useState, useRef, useEffect } from 'react'

interface Model {
  name: string
  desc: string
  tier: 'free' | 'pro'
}

const MODELS = {
  free: [
    { name: 'Gemini Flash', desc: 'Fast, lightweight', tier: 'free' as const },
    { name: 'Deepseek V3', desc: 'Smart, affordable', tier: 'free' as const },
  ],
  pro: [
    { name: 'Claude Sonnet', desc: 'Balanced, capable', tier: 'pro' as const },
    { name: 'Claude Opus', desc: 'Most powerful', tier: 'pro' as const },
    { name: 'GPT-4o', desc: 'OpenAI flagship', tier: 'pro' as const },
  ],
}

export function ModelDropdown() {
  const [isOpen, setIsOpen] = useState(false)
  const [selected, setSelected] = useState('Claude Sonnet')
  const [selectedTier, setSelectedTier] = useState<'free' | 'pro'>('pro')
  const dropRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropRef.current && !dropRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener('click', handleClickOutside)
    return () => document.removeEventListener('click', handleClickOutside)
  }, [])

  const handleSelect = (model: Model) => {
    setSelected(model.name)
    setSelectedTier(model.tier)
    setIsOpen(false)
  }

  return (
    <div className="model-drop-wrap" ref={dropRef}>
      <button
        className="model-chip"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="mc-dot"></span>
        <span>{selected}</span>
        <span className={`mc-badge ${selectedTier}`}>{selectedTier === 'pro' ? 'Pro' : 'Free'}</span>
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>

      {isOpen && (
        <div className="model-drop show">
          <div className="md-group-label">Free</div>
          {MODELS.free.map((model) => (
            <button
              key={model.name}
              className={`md-opt ${selected === model.name ? 'active' : ''}`}
              onClick={() => handleSelect(model)}
            >
              <span className="md-name">{model.name}</span>
              <span className={`mc-badge ${model.tier}`}>Free</span>
            </button>
          ))}

          <div className="md-group-label">Pro</div>
          {MODELS.pro.map((model) => (
            <button
              key={model.name}
              className={`md-opt ${selected === model.name ? 'active' : ''}`}
              onClick={() => handleSelect(model)}
            >
              <span className="md-name">{model.name}</span>
              <span className={`mc-badge ${model.tier}`}>Pro</span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
