import { useState } from 'react'
import { Toggle } from './Toggle'

export function PrivacySettings() {
  const [telemetry, setTelemetry] = useState(() => localStorage.getItem('ide.privacy.telemetry') === 'true')
  const [crashReports, setCrashReports] = useState(() => {
    const val = localStorage.getItem('ide.privacy.crashReports')
    return val === null ? true : val === 'true'
  })
  const [localOnly, setLocalOnly] = useState(() => {
    const val = localStorage.getItem('ide.privacy.localOnly')
    return val === null ? true : val === 'true'
  })

  const handleTelemetryChange = (checked: boolean) => {
    setTelemetry(checked)
    localStorage.setItem('ide.privacy.telemetry', String(checked))
  }

  const handleCrashReportsChange = (checked: boolean) => {
    setCrashReports(checked)
    localStorage.setItem('ide.privacy.crashReports', String(checked))
  }

  const handleLocalOnlyChange = (checked: boolean) => {
    setLocalOnly(checked)
    localStorage.setItem('ide.privacy.localOnly', String(checked))
  }

  return (
    <div className="section">
      <div className="section-title">Data</div>
      <div className="card">
        <div className="row">
          <span className="row-label">
            <div className="row-title">Send telemetry</div>
            <div className="row-desc">Anonymous usage stats to improve Sharrowkin</div>
          </span>
          <Toggle checked={telemetry} onChange={handleTelemetryChange} />
        </div>
        <div className="row">
          <span className="row-label">
            <div className="row-title">Send crash reports</div>
            <div className="row-desc">Help us fix bugs faster</div>
          </span>
          <Toggle checked={crashReports} onChange={handleCrashReportsChange} />
        </div>
        <div className="row">
          <span className="row-label">
            <div className="row-title">Local-only mode</div>
            <div className="row-desc">No sensitive code data leaves your machine; LLM calls only</div>
          </span>
          <Toggle checked={localOnly} onChange={handleLocalOnlyChange} />
        </div>
      </div>
    </div>
  )
}
