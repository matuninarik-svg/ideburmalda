import { useState } from 'react'
import { CustomDropdown } from './CustomDropdown'

export function TerminalSettings() {
  const [shell, setShell] = useState(() => localStorage.getItem('ide.terminal.shell') || 'PowerShell')
  const [fontFamily, setFontFamily] = useState(() => localStorage.getItem('ide.terminal.fontFamily') || 'Cascadia Code')
  const [scrollback, setScrollback] = useState(() => localStorage.getItem('ide.terminal.scrollback') || '1000')

  const handleShellChange = (val: string) => {
    setShell(val)
    localStorage.setItem('ide.terminal.shell', val)
  }

  const handleFontFamilyChange = (val: string) => {
    setFontFamily(val)
    localStorage.setItem('ide.terminal.fontFamily', val)
  }

  const handleScrollbackChange = (val: string) => {
    setScrollback(val)
    localStorage.setItem('ide.terminal.scrollback', val)
  }

  return (
    <div className="section">
      <div className="section-title">Shell</div>
      <div className="card">
        <div className="row">
          <span className="row-label">
            <div className="row-title">Default shell</div>
            <div className="row-desc">Shell used in terminal panel</div>
          </span>
          <CustomDropdown
            value={shell}
            options={['bash', 'zsh', 'PowerShell', 'fish']}
            onChange={handleShellChange}
          />
        </div>
        <div className="row">
          <span className="row-label">
            <div className="row-title">Font family</div>
            <div className="row-desc">Monospace font for terminal</div>
          </span>
          <input
            className="field"
            value={fontFamily}
            onChange={(e) => handleFontFamilyChange(e.target.value)}
            placeholder="Font family"
          />
        </div>
        <div className="row">
          <span className="row-label">
            <div className="row-title">Scrollback lines</div>
          </span>
          <CustomDropdown
            value={scrollback}
            options={['500', '1000', '5000']}
            onChange={handleScrollbackChange}
          />
        </div>
      </div>
    </div>
  )
}
