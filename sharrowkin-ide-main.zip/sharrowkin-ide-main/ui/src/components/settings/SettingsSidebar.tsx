interface Props {
  currentPage: string
  onPageChange: (page: any) => void
}

const AgentIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <rect x="3" y="11" width="18" height="10" rx="3"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/>
  </svg>
)

const AppearanceIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
  </svg>
)

const TerminalIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/>
  </svg>
)

const GitIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"/>
  </svg>
)

const PrivacyIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
  </svg>
)

export function SettingsSidebar({ currentPage, onPageChange }: Props) {
  const items = [
    { id: 'Agent', Icon: AgentIcon, label: 'Agent' },
    { id: 'Appearance', Icon: AppearanceIcon, label: 'Appearance' },
    { id: 'Terminal', Icon: TerminalIcon, label: 'Terminal' },
    { id: 'Git', Icon: GitIcon, label: 'Git' },
  ]

  const accountItems = [
    { id: 'Privacy', Icon: PrivacyIcon, label: 'Privacy' },
  ]

  return (
    <div className="sidebar">
      {items.map((item) => (
        <button
          key={item.id}
          className={`s-item ${currentPage === item.id ? 'active' : ''}`}
          onClick={() => onPageChange(item.id)}
        >
          <item.Icon />
          {item.label}
        </button>
      ))}

      <div className="s-section-label">Account</div>

      {accountItems.map((item) => (
        <button
          key={item.id}
          className={`s-item ${currentPage === item.id ? 'active' : ''}`}
          onClick={() => onPageChange(item.id)}
        >
          <item.Icon />
          {item.label}
        </button>
      ))}
    </div>
  )
}
