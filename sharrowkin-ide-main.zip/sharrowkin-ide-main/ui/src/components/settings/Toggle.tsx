interface Props {
  checked: boolean
  onChange: (checked: boolean) => void
}

export function Toggle({ checked, onChange }: Props) {
  return (
    <button
      className={`toggle ${checked ? 'on' : ''}`}
      onClick={() => onChange(!checked)}
    />
  )
}
