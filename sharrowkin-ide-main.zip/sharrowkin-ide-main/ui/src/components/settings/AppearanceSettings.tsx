import { useState } from 'react'
import { CustomDropdown } from './CustomDropdown'
import { Toggle } from './Toggle'
import { useIde } from '@/state/state'

export function AppearanceSettings() {
  const { theme, toggleTheme } = useIde()
  const [fontSize, setFontSize] = useState(() => localStorage.getItem('ide.fontSize') || '13px')
  const [compactMode, setCompactMode] = useState(() => localStorage.getItem('ide.compactMode') === 'true')

  const handleFontSizeChange = (size: string) => {
    setFontSize(size)
    localStorage.setItem('ide.fontSize', size)
    document.documentElement.style.setProperty('--app-font-size', size)
  }

  const handleCompactModeChange = (checked: boolean) => {
    setCompactMode(checked)
    localStorage.setItem('ide.compactMode', String(checked))
    if (checked) {
      document.documentElement.setAttribute('data-compact', 'true')
    } else {
      document.documentElement.removeAttribute('data-compact')
    }
  }

  return (
    <>
      <div className="section">
        <div className="section-title">Theme</div>
        <div className="card">
          <div className="row">
            <span className="row-label">
              <div className="row-title">Theme</div>
              <div className="row-desc">Choose your preferred look</div>
            </span>
            <CustomDropdown
              value={theme === 'dark' ? 'Dark' : 'Light'}
              options={['Light', 'Dark']}
              onChange={(val) => {
                const nextTheme = val.toLowerCase() as 'light' | 'dark'
                if (nextTheme !== theme) {
                  toggleTheme()
                }
              }}
            />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Font size</div>
              <div className="row-desc">Editor and UI font size</div>
            </span>
            <CustomDropdown
              value={fontSize}
              options={['12px', '13px', '14px', '16px']}
              onChange={handleFontSizeChange}
            />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Compact mode</div>
              <div className="row-desc">Reduce padding and spacing across the interface</div>
            </span>
            <Toggle checked={compactMode} onChange={handleCompactModeChange} />
          </div>
        </div>
      </div>
    </>
  )
}
