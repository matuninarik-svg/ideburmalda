import { useState, useEffect } from 'react'
import { ModelDropdown } from './ModelDropdown'
import { CustomDropdown } from './CustomDropdown'
import { Toggle } from './Toggle'
import { BASE } from '@/services/api'

export function AgentSettings() {
  const [autoApply, setAutoApply] = useState(false)
  const [runTests, setRunTests] = useState(true)
  const [showReasoning, setShowReasoning] = useState(true)
  const [maxIterations, setMaxIterations] = useState('40')

  // API Keys state
  const [anthropicKey, setAnthropicKey] = useState('')
  const [openaiKey, setOpenaiKey] = useState('')
  const [geminiKey, setGeminiKey] = useState('')
  const [openrouterKey, setOpenrouterKey] = useState('')
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)

  // Fetch settings on mount
  useEffect(() => {
    async function loadSettings() {
      setLoading(true)
      try {
        const res = await fetch(`${BASE}/api/settings`)
        if (res.ok) {
          const data = await res.json()
          setAnthropicKey(data.anthropic_api_key || '')
          setOpenaiKey(data.openai_api_key || '')
          setGeminiKey(data.gemini_api_key || '')
          setOpenrouterKey(data.openrouter_api_key || '')
        }
      } catch (e) {
        console.error("Failed to load settings:", e)
      } finally {
        setLoading(false)
      }
    }
    loadSettings()
  }, [])

  // Save settings helper
  async function saveSettings(updates: any) {
    setSaving(true)
    try {
      const res = await fetch(`${BASE}/api/settings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      })
      if (!res.ok) {
        console.error("Failed to save settings")
      }
    } catch (e) {
      console.error("Failed to save settings:", e)
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      {/* Model */}
      <div className="section">
        <div className="section-title" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>Model</span>
          {saving && <span style={{ fontSize: '10px', color: 'var(--t-400)', textTransform: 'none' }}>Saving keys...</span>}
          {loading && <span style={{ fontSize: '10px', color: 'var(--t-400)', textTransform: 'none' }}>Loading...</span>}
        </div>
        <div className="card">
          <div className="row">
            <span className="row-label">
              <div className="row-title">Active model</div>
              <div className="row-desc">Used for all agent tasks</div>
            </span>
            <ModelDropdown />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Fallback model</div>
              <div className="row-desc">Used when primary is unavailable</div>
            </span>
            <CustomDropdown
              value={maxIterations}
              options={['Gemini Flash', 'Deepseek V3', 'Claude Haiku']}
              onChange={setMaxIterations}
            />
          </div>
        </div>
      </div>

      {/* Behaviour */}
      <div className="section">
        <div className="section-title">Behaviour</div>
        <div className="card">
          <div className="row">
            <span className="row-label">
              <div className="row-title">Auto-apply changes</div>
              <div className="row-desc">Apply diffs without confirmation</div>
            </span>
            <Toggle checked={autoApply} onChange={setAutoApply} />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Run tests after edit</div>
              <div className="row-desc">Automatically run tests when agent saves</div>
            </span>
            <Toggle checked={runTests} onChange={setRunTests} />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Show reasoning</div>
              <div className="row-desc">Display agent thinking between tool calls</div>
            </span>
            <Toggle checked={showReasoning} onChange={setShowReasoning} />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Max iterations</div>
              <div className="row-desc">Agent loop limit per task</div>
            </span>
            <CustomDropdown
              value={maxIterations}
              options={['20', '40', '80', 'Unlimited']}
              onChange={setMaxIterations}
            />
          </div>
        </div>
      </div>

      {/* Memory */}
      <div className="section">
        <div className="section-title">Memory</div>
        <div className="card">
          <div className="row">
            <span className="row-label">
              <div className="row-title">Persistent memory</div>
              <div className="row-desc">Remember context across sessions</div>
            </span>
            <Toggle checked={true} onChange={() => {}} />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Memory retention</div>
              <div className="row-desc">How long to keep session memory</div>
            </span>
            <CustomDropdown
              value="30 days"
              options={['7 days', '30 days', '90 days', 'Forever']}
              onChange={() => {}}
            />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Clear memory</div>
              <div className="row-desc">Delete all stored context for this project</div>
            </span>
            <button className="danger-btn">Clear</button>
          </div>
        </div>
      </div>

      {/* API Keys */}
      <div className="section">
        <div className="section-title">API Keys</div>
        <div className="card">
          <div className="row">
            <span className="row-label">
              <div className="row-title">Anthropic Key</div>
              <div className="row-desc">Required for Claude models</div>
            </span>
            <input
              className="field"
              type="password"
              placeholder="sk-ant-..."
              value={anthropicKey}
              onChange={e => setAnthropicKey(e.target.value)}
              onBlur={() => saveSettings({ anthropic_api_key: anthropicKey })}
            />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">OpenAI Key</div>
              <div className="row-desc">Required for GPT models</div>
            </span>
            <input
              className="field"
              type="password"
              placeholder="sk-..."
              value={openaiKey}
              onChange={e => setOpenaiKey(e.target.value)}
              onBlur={() => saveSettings({ openai_api_key: openaiKey })}
            />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">Google Gemini Key</div>
              <div className="row-desc">Required for Gemini models</div>
            </span>
            <input
              className="field"
              type="password"
              placeholder="AIza..."
              value={geminiKey}
              onChange={e => setGeminiKey(e.target.value)}
              onBlur={() => saveSettings({ gemini_api_key: geminiKey })}
            />
          </div>
          <div className="row">
            <span className="row-label">
              <div className="row-title">OpenRouter Key</div>
              <div className="row-desc">Required for fallback router models</div>
            </span>
            <input
              className="field"
              type="password"
              placeholder="sk-or-..."
              value={openrouterKey}
              onChange={e => setOpenrouterKey(e.target.value)}
              onBlur={() => saveSettings({ openrouter_api_key: openrouterKey })}
            />
          </div>
        </div>
      </div>
    </>
  )
}
