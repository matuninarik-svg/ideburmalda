import { useState, useRef, useEffect } from 'react'

interface Props {
  value: string
  options: string[]
  onChange: (value: string) => void
}

export function CustomDropdown({ value, options, onChange }: Props) {
  const [isOpen, setIsOpen] = useState(false)
  const dropRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropRef.current && !dropRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener('click', handleClickOutside)
    return () => document.removeEventListener('click', handleClickOutside)
  }, [])

  return (
    <div className="drop-wrap" ref={dropRef}>
      <button
        className="drop-btn"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span>{value}</span>
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>
      {isOpen && (
        <div className="drop-list show">
          {options.map((option) => (
            <button
              key={option}
              className={`drop-opt ${option === value ? 'on' : ''}`}
              onClick={() => {
                onChange(option)
                setIsOpen(false)
              }}
            >
              {option}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
