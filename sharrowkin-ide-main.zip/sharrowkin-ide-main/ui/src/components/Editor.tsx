import { useEffect, useState, useRef, useCallback } from "react"
import { useIde } from "@/state/state"
import { BASE, extToLanguage, saveFile } from "@/services/api"
import { CodeEditor } from "./CodeEditor"
import { marksForTab } from "@/utils/editorDiff"

type FileCache = Record<string, string>

function getExt(path: string) {
  const m = path.match(/(\.[^.]+)$/)
  return m ? m[1] : null
}

function tabLabel(path: string) {
  return path.split(/[\\/]/).pop() ?? path
}

export function Editor() {
  const { openTabs, activeTab, setActiveTab, closeTab, addPill, workspace, fileDiffs, diffVersion, activeLine, setActiveLine } = useIde()
  const [cache, setCache] = useState<FileCache>({})
  const [loading, setLoading] = useState(false)
  const [savedIndicator, setSavedIndicator] = useState(false)
  const [reloadNonce, setReloadNonce] = useState<Record<string, number>>({})
  const prevTab = useRef<string | null>(null)
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const doSave = useCallback((tab: string, content: string, ws: string) => {
    saveFile(ws, tab, content)
      .then(() => {
        setSavedIndicator(true)
        setTimeout(() => setSavedIndicator(false), 2000)
      })
      .catch(() => {})
  }, [])

  // Ctrl+S handler
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault()
        if (activeTab && workspace && cache[activeTab] !== undefined) {
          if (saveTimer.current) clearTimeout(saveTimer.current)
          doSave(activeTab, cache[activeTab], workspace)
        }
      }
    }
    window.addEventListener("keydown", onKeyDown)
    return () => window.removeEventListener("keydown", onKeyDown)
  }, [activeTab, workspace, cache, doSave])

  // Load file content when activeTab changes
  useEffect(() => {
    if (!activeTab || !workspace) return
    if (cache[activeTab] !== undefined) return // already loaded
    if (prevTab.current === activeTab) return
    prevTab.current = activeTab

    setLoading(true)
    fetch(`${BASE}/api/workspace/file?workspace=${encodeURIComponent(workspace)}&path=${encodeURIComponent(activeTab)}`)
      .then(r => r.ok ? r.json() : Promise.reject(r.status))
      .then(data => {
        setCache(c => ({ ...c, [activeTab]: data.content ?? "" }))
      })
      .catch(() => {
        setCache(c => ({ ...c, [activeTab]: `# Could not load file: ${activeTab}` }))
      })
      .finally(() => setLoading(false))
  }, [activeTab, workspace])

  // When the agent edits files, refetch any open tab it touched and bump that
  // tab's reload nonce so the editor remounts with fresh content + diff marks.
  useEffect(() => {
    if (diffVersion === 0 || !workspace) return
    for (const tab of openTabs) {
      if (!marksForTab(fileDiffs, tab)) continue
      fetch(`${BASE}/api/workspace/file?workspace=${encodeURIComponent(workspace)}&path=${encodeURIComponent(tab)}`)
        .then(r => r.ok ? r.json() : Promise.reject(r.status))
        .then(data => {
          setCache(c => ({ ...c, [tab]: data.content ?? "" }))
          setReloadNonce(n => ({ ...n, [tab]: (n[tab] ?? 0) + 1 }))
        })
        .catch(() => {})
    }
  }, [diffVersion]) // eslint-disable-line react-hooks/exhaustive-deps

  const content = activeTab ? (cache[activeTab] ?? "") : ""
  const lang = activeTab ? extToLanguage(getExt(activeTab)) as any : "python"
  const activeMarks = marksForTab(fileDiffs, activeTab)

  const parts = activeTab?.split(/[\\/]/) ?? []
  const breadcrumb = parts.length > 1
    ? <>{parts.slice(0, -1).join(" › ")} <span>›</span> <b>{parts[parts.length - 1]}</b></>
    : <b>{activeTab ?? "—"}</b>

  return (
    <main className="card editor">
      {/* Tab bar */}
      <div className="ed-head">
        {openTabs.map((id) => (
          <div
            key={id}
            className={`tab${id === activeTab ? " active" : ""}`}
            onClick={() => setActiveTab(id)}
          >
            {tabLabel(id)}
            <span className="tx" onClick={(e) => { e.stopPropagation(); closeTab(id) }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/>
              </svg>
            </span>
          </div>
        ))}
        <div className="ed-sp" />
      </div>

      {/* Breadcrumb */}
      <div className="breadcrumb">
        {breadcrumb}
        {savedIndicator && (
          <span style={{ marginLeft: 8, fontSize: 11, color: "var(--t-400)", fontWeight: 400, opacity: 0.8 }}>Saved</span>
        )}
      </div>

      {/* Editor body */}
      <div style={{ flex: 1, minHeight: 0, position: "relative", overflow: "hidden" }}>
        {!activeTab && (
          <div style={{
            position: "absolute", inset: 0, display: "flex", alignItems: "center",
            justifyContent: "center", flexDirection: "column", gap: 8,
            color: "var(--t-400)", fontSize: 13,
          }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" style={{ color: "var(--t-300)" }}>
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
            </svg>
            Open a file from the Explorer
          </div>
        )}

        {loading && (
          <div style={{
            position: "absolute", inset: 0, display: "flex", alignItems: "center",
            justifyContent: "center", color: "var(--t-400)", fontSize: 12,
          }}>
            Loading…
          </div>
        )}

        {activeTab && !loading && (
          <CodeEditor
            key={`${activeTab}#${reloadNonce[activeTab] ?? 0}`}
            language={lang}
            initialCode={content}
            diffMarks={activeMarks}
            jumpToLine={activeLine ?? undefined}
            onChange={(newCode) => {
              setCache(c => ({ ...c, [activeTab]: newCode }))
              if (workspace) {
                if (saveTimer.current) clearTimeout(saveTimer.current)
                saveTimer.current = setTimeout(() => doSave(activeTab, newCode, workspace), 1500)
              }
            }}
            onAskAI={(text) => addPill(text.trim() ? `${tabLabel(activeTab)} selection` : "selection")}
            onReady={() => setActiveLine(null)}
          />
        )}
      </div>
    </main>
  )
}
