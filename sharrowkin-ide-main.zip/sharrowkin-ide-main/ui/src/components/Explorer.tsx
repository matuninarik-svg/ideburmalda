import { useState, useEffect, useCallback, useRef, useMemo, type ReactNode } from "react"
import { useIde } from "@/state/state"
import { BASE, pickFolder as pickFolderApi } from "@/services/api"

type FsNode = {
  name: string
  path: string
  type: "file" | "folder"
  children?: FsNode[]
  extension?: string | null
}

type GitStatus = { modified: string[]; added: string[]; deleted: string[] }

type InlineNew = { parent: string; kind: "file" | "folder" } | null

// ── icons ─────────────────────────────────────────────────────────────────────
function fileIcon(name: string, ext: string | null) {
  const e = (ext || "").toLowerCase()
  if (e === ".py")  return { color: "#3b82f6", char: "py" }
  if (e === ".ts" || e === ".tsx") return { color: "#2563eb", char: "ts" }
  if (e === ".js" || e === ".jsx") return { color: "#d97706", char: "js" }
  if (e === ".json") return { color: "#059669", char: "{}" }
  if (e === ".md")  return { color: "#9333ea", char: "md" }
  if (e === ".css") return { color: "#0891b2", char: "cs" }
  if (e === ".html") return { color: "#ea580c", char: "ht" }
  if (e === ".env" || name.startsWith(".env")) return { color: "#d97706", char: "ev" }
  if (name === "package.json") return { color: "#dc2626", char: "pk" }
  return { color: "#a1a1aa", char: "f" }
}

function FileIconBadge({ name, ext }: { name: string; ext: string | null }) {
  const { color, char } = fileIcon(name, ext)
  if (char === "f") {
    return (
      <span style={{ display: "flex", alignItems: "center", color: "var(--t-400)", flexShrink: 0, width: 14, height: 14 }}>
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
        </svg>
      </span>
    )
  }
  return (
    <span style={{
      fontSize: 8, fontWeight: 700, color,
      fontFamily: "JetBrains Mono,ui-monospace,monospace",
      letterSpacing: -0.5, minWidth: 14, textAlign: "center", flexShrink: 0,
    }}>
      {char}
    </span>
  )
}

function FolderIcon({ open }: { open: boolean }) {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      {open
        ? <><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/><line x1="2" y1="13" x2="22" y2="13"/></>
        : <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
      }
    </svg>
  )
}

// ── inline tree input ─────────────────────────────────────────────────────────
function InlineTreeInput({
  depth, kind, onConfirm, onCancel,
}: {
  depth: number
  kind: "file" | "folder"
  onConfirm: (name: string) => void
  onCancel: () => void
}) {
  const [val, setVal] = useState("")
  const ref = useRef<HTMLInputElement>(null)
  const submitted = useRef(false)

  useEffect(() => {
    const t = setTimeout(() => ref.current?.focus(), 40)
    return () => clearTimeout(t)
  }, [])

  function submit() {
    if (submitted.current) return
    const v = val.trim()
    if (!v) { onCancel(); return }
    submitted.current = true
    onConfirm(v)
  }

  // left-padding: match folder row indent, then add chevron+gap space
  const pl = 10 + depth * 14

  return (
    <div className="tree-new-row" style={{ paddingLeft: pl }}>
      {/* spacer to align with chevron column */}
      <span style={{ width: 10, flexShrink: 0 }} />
      {kind === "folder"
        ? <span style={{ color: "var(--t-400)", flexShrink: 0, display: "flex" }}><FolderIcon open={false} /></span>
        : <FileIconBadge name="" ext={null} />
      }
      <input
        ref={ref}
        className="tree-inline-input"
        value={val}
        placeholder={kind === "folder" ? "folder-name" : "filename.ext"}
        onChange={e => setVal(e.target.value)}
        onKeyDown={e => {
          if (e.key === "Enter")  { e.preventDefault(); submit() }
          if (e.key === "Escape") { e.preventDefault(); onCancel() }
        }}
        onBlur={submit}
        onClick={e => e.stopPropagation()}
        onMouseDown={e => e.stopPropagation()}
      />
    </div>
  )
}

// ── tree node ─────────────────────────────────────────────────────────────────
function TreeNode({
  node, depth, openFile, activeFile,
  inlineNew, forceOpenPaths,
  onInlineConfirm, onInlineCancel,
  gitStatus,
}: {
  node: FsNode
  depth: number
  openFile: (path: string, name: string) => void
  activeFile: string | null
  inlineNew: InlineNew
  forceOpenPaths: Set<string>  // all paths that must be expanded
  onInlineConfirm: (name: string) => void
  onInlineCancel: () => void
  gitStatus: GitStatus | null
}) {
  const isInlineParent = inlineNew !== null && inlineNew.parent === node.path
  const mustOpen = forceOpenPaths.has(node.path) || isInlineParent
  const [open, setOpen] = useState(depth === 0)

  useEffect(() => {
    if (mustOpen) setOpen(true)
  }, [mustOpen])

  const pl = 10 + depth * 14

  if (node.type === "folder") {
    return (
      <div>
        <div
          className="trow"
          style={{ paddingLeft: pl }}
          onClick={() => setOpen(o => !o)}
          data-fs-path={node.path}
          data-fs-kind="folder"
        >
          <svg
            width="10" height="10" viewBox="0 0 24 24"
            fill="none" stroke="currentColor" strokeWidth="2.5"
            style={{
              flexShrink: 0, color: "var(--t-300)",
              transform: open ? "rotate(0)" : "rotate(-90deg)",
              transition: "transform .15s",
            }}
          >
            <polyline points="6 9 12 15 18 9"/>
          </svg>
          <span style={{ color: "var(--t-400)", flexShrink: 0 }}>
            <FolderIcon open={open} />
          </span>
          <span style={{ fontSize: 12.5, color: "var(--t-700)", fontWeight: 450 }}>{node.name}</span>
        </div>

        {open && (
          <div>
            {/* inline input appears as first child of this folder */}
            {isInlineParent && (
              <InlineTreeInput
                depth={depth + 1}
                kind={inlineNew!.kind}
                onConfirm={onInlineConfirm}
                onCancel={onInlineCancel}
              />
            )}
            {node.children?.map(child => (
              <TreeNode
                key={child.path}
                node={child}
                depth={depth + 1}
                openFile={openFile}
                activeFile={activeFile}
                inlineNew={inlineNew}
                forceOpenPaths={forceOpenPaths}
                onInlineConfirm={onInlineConfirm}
                onInlineCancel={onInlineCancel}
                gitStatus={gitStatus}
              />
            ))}
          </div>
        )}
      </div>
    )
  }

  const active = activeFile === node.path

  // Determine git badge for this file
  let gsBadge: ReactNode = null
  if (gitStatus) {
    const p = node.path
    if (gitStatus.modified.some(f => f === p || f.endsWith("/" + p) || p.endsWith(f))) {
      gsBadge = <span className="gs m">M</span>
    } else if (gitStatus.added.some(f => f === p || f.endsWith("/" + p) || p.endsWith(f))) {
      gsBadge = <span className="gs a">A</span>
    } else if (gitStatus.deleted.some(f => f === p || f.endsWith("/" + p) || p.endsWith(f))) {
      gsBadge = <span className="gs" style={{ color: "#dc2626" }}>D</span>
    }
  }

  return (
    <div
      className={`trow${active ? " active" : ""}`}
      style={{ paddingLeft: pl + 14 }}
      onClick={() => openFile(node.path, node.name)}
      data-fs-path={node.path}
      data-fs-kind="file"
    >
      <FileIconBadge name={node.name} ext={node.extension ?? null} />
      <span style={{ fontSize: 12.5, color: active ? "var(--t-900)" : "var(--t-600)", fontWeight: active ? 500 : 450 }}>
        {node.name}
      </span>
      {gsBadge}
    </div>
  )
}

// ── Explorer ──────────────────────────────────────────────────────────────────
export function Explorer() {
  const { workspace, setWorkspace, openFile: openTab, openProject, diffVersion, isRunning } = useIde()
  const [tree, setTree]         = useState<FsNode | null>(null)
  const [loading, setLoading]   = useState(false)
  const [error, setError]       = useState<string | null>(null)
  const [activeFile, setActiveFile] = useState<string | null>(null)
  const [_branch]               = useState("main")
  const [inlineNew, setInlineNew] = useState<InlineNew>(null)
  const [gitStatus, setGitStatus] = useState<GitStatus | null>(null)

  // All ancestor paths of inlineNew.parent that must be forced open
  const forceOpenPaths = useMemo<Set<string>>(() => {
    if (!inlineNew?.parent) return new Set()
    const parts = inlineNew.parent.split("/")
    const s = new Set<string>()
    for (let i = 1; i < parts.length; i++) {
      s.add(parts.slice(0, i).join("/"))
    }
    // the direct parent is handled via isInlineParent; ancestors go here
    return s
  }, [inlineNew])

  const loadTree = useCallback(async (path: string) => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`${BASE}/api/workspace/tree?path=${encodeURIComponent(path)}`)
      if (!res.ok) throw new Error(`${res.status}`)
      const data = await res.json()
      setTree(data.tree)
    } catch {
      setError("Failed to load files")
    } finally {
      setLoading(false)
    }
    // Fetch git status separately — silently ignore errors
    try {
      const gsRes = await fetch(`${BASE}/api/workspace/git-status?path=${encodeURIComponent(path)}`)
      if (gsRes.ok) {
        const gs = await gsRes.json()
        setGitStatus(gs)
      }
    } catch {
      // no git or not available — ignore
    }
  }, [])

  useEffect(() => {
    if (workspace) loadTree(workspace)
  }, [workspace, diffVersion, isRunning, loadTree])

  // Explicit refresh from other components
  useEffect(() => {
    function handle() { if (workspace) loadTree(workspace) }
    window.addEventListener("sharrowkin:refresh-explorer", handle)
    return () => window.removeEventListener("sharrowkin:refresh-explorer", handle)
  }, [workspace, loadTree])

  // New-item event from context menu → show inline input in tree
  useEffect(() => {
    function handle(e: Event) {
      const { parent, kind } = (e as CustomEvent<{ parent: string; kind: "file" | "folder" }>).detail
      setInlineNew({ parent, kind })
    }
    window.addEventListener("sharrowkin:new-item", handle)
    return () => window.removeEventListener("sharrowkin:new-item", handle)
  }, [])

  async function handleInlineConfirm(name: string) {
    if (!inlineNew || !workspace) { setInlineNew(null); return }
    try {
      const res = await fetch(`${BASE}/api/workspace/new-item`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ workspace, parent: inlineNew.parent, name, kind: inlineNew.kind }),
      })
      if (!res.ok) {
        const j = await res.json().catch(() => ({}))
        alert("Error: " + (j.detail ?? "Failed to create"))
      }
    } catch (e: any) {
      alert("Error: " + e.message)
    }
    setInlineNew(null)
    if (workspace) loadTree(workspace)
  }

  function handleInlineCancel() { setInlineNew(null) }

  async function pickFolder() {
    const path = await pickFolderApi()
    if (path) {
      setWorkspace(path)
      loadTree(path)
      openProject(path.split(/[\\\/]/).filter(Boolean).pop() ?? path)
    }
  }

  function openFile(path: string, _name: string) {
    setActiveFile(path)
    const absPath = workspace ? workspace.replace(/[\\\/]+$/, "") + "/" + path : path
    openTab(absPath)
  }

  const projName = workspace
    ? workspace.split(/[\\\/]/).filter(Boolean).pop() ?? workspace
    : "No folder"

  return (
    <aside className="card explorer">
      {/* Header */}
      <div className="ex-head" style={{ height: 40, paddingLeft: 14 }}>
        <span className="ex-proj-name" style={{ fontSize: 12, fontWeight: 550, color: "var(--t-800)", letterSpacing: "-.01em", flex: 1 }}>
          {projName}
        </span>
        <div className="ex-acts">
          <button className="ic" title="New File"
            onClick={() => setInlineNew({ parent: "", kind: "file" })}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <line x1="12" y1="11" x2="12" y2="17"/><line x1="9" y1="14" x2="15" y2="14"/>
            </svg>
          </button>
          <button className="ic" title="New Folder"
            onClick={() => setInlineNew({ parent: "", kind: "folder" })}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
              <line x1="12" y1="11" x2="12" y2="17"/><line x1="9" y1="14" x2="15" y2="14"/>
            </svg>
          </button>
          <button className="ic" title="Open folder" onClick={pickFolder}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
          <button className="ic" title="Refresh" onClick={() => workspace && loadTree(workspace)}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5A10 10 0 0 1 3.2 16.7"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Tree */}
      <div className="tree" style={{ overflowY: "auto", flex: 1 }}>
        {loading && (
          <div style={{ padding: "16px 18px", fontSize: 11.5, color: "var(--t-400)" }}>Loading…</div>
        )}
        {error && !loading && (
          <div style={{ padding: "16px 18px", fontSize: 11.5, color: "#ef4444" }}>{error}</div>
        )}
        {!workspace && !loading && (
          <div style={{
            padding: "20px 16px", fontSize: 12, color: "var(--t-400)",
            display: "flex", flexDirection: "column", gap: 10, alignItems: "center", textAlign: "center",
          }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" style={{ color: "var(--t-300)" }}>
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
            </svg>
            <span>No folder open</span>
            <button
              onClick={pickFolder}
              style={{
                padding: "6px 14px", borderRadius: 9, background: "var(--soft)",
                color: "var(--t-700)", fontSize: 12, fontWeight: 500,
                border: 0, cursor: "pointer", fontFamily: "inherit",
              }}
            >
              Open Folder
            </button>
          </div>
        )}

        {tree && !loading && (
          <div>
            {/* root-level inline input */}
            {inlineNew?.parent === "" && (
              <InlineTreeInput
                depth={0}
                kind={inlineNew.kind}
                onConfirm={handleInlineConfirm}
                onCancel={handleInlineCancel}
              />
            )}
            {tree.children?.map(child => (
              <TreeNode
                key={child.path}
                node={child}
                depth={0}
                openFile={openFile}
                activeFile={activeFile}
                inlineNew={inlineNew}
                forceOpenPaths={forceOpenPaths}
                onInlineConfirm={handleInlineConfirm}
                onInlineCancel={handleInlineCancel}
                gitStatus={gitStatus}
              />
            ))}
          </div>
        )}
      </div>
    </aside>
  )
}
