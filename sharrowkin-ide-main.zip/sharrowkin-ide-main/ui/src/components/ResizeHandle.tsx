import { useRef, useCallback } from "react"

interface Props {
  direction: "horizontal" | "vertical"
  onResize: (delta: number) => void
}

export function ResizeHandle({ direction, onResize }: Props) {
  const dragging = useRef(false)
  const last = useRef(0)

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault()
    dragging.current = true
    last.current = direction === "horizontal" ? e.clientX : e.clientY

    const onMove = (e: MouseEvent) => {
      if (!dragging.current) return
      const cur = direction === "horizontal" ? e.clientX : e.clientY
      onResize(cur - last.current)
      last.current = cur
    }

    const onUp = () => {
      dragging.current = false
      window.removeEventListener("mousemove", onMove)
      window.removeEventListener("mouseup", onUp)
    }

    window.addEventListener("mousemove", onMove)
    window.addEventListener("mouseup", onUp)
  }, [direction, onResize])

  return (
    <div
      onMouseDown={onMouseDown}
      style={{
        flexShrink: 0,
        background: "transparent",
        transition: "background .15s",
        cursor: direction === "horizontal" ? "col-resize" : "row-resize",
        ...(direction === "horizontal"
          ? { width: 8, alignSelf: "stretch", display: "flex", alignItems: "center", justifyContent: "center" }
          : { height: 8, alignSelf: "stretch", display: "flex", alignItems: "center", justifyContent: "center" }),
        zIndex: 10,
        userSelect: "none",
      }}
      className="resize-handle"
    >
      <div style={{
        borderRadius: 99,
        background: "var(--t-200)",
        transition: "background .15s, opacity .15s",
        ...(direction === "horizontal"
          ? { width: 3, height: 28 }
          : { height: 3, width: 28 }),
      }} />
    </div>
  )
}
