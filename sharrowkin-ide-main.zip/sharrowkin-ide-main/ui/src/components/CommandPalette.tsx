import { useState, useEffect, useRef, useCallback } from "react"
import { useIde } from "@/state/state"

const RECENT_KEY = "ide.recentFiles"
const MAX_RECENT = 10

function loadRecent(): string[] {
  try { return JSON.parse(localStorage.getItem(RECENT_KEY) ?? "[]") } catch { return [] }
}
function saveRecent(path: string) {
  const prev = loadRecent().filter(p => p !== path)
  localStorage.setItem(RECENT_KEY, JSON.stringify([path, ...prev].slice(0, MAX_RECENT)))
}

type ActionItem = { kind: "action"; id: string; label: string; hint?: string; run: () => void }
type FileItem   = { kind: "file";   path: string; label: string }
type CmdItem    = ActionItem | FileItem

export function CommandPalette() {
  const { openTabs, openFile, openSettings, newSession, toggleTheme } = useIde()
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState("")
  const [idx, setIdx] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)

  const close = useCallback(() => { setOpen(false); setQuery(""); setIdx(0) }, [])

  // Global keyboard listener
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "p")) {
        e.preventDefault()
        setOpen(o => !o)
        setQuery("")
        setIdx(0)
      }
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [])

  // Focus input when opened
  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 30)
  }, [open])

  // Build item list
  const actions: ActionItem[] = [
    { kind: "action", id: "new-session",  label: "New Session",   hint: "Chat", run: () => { newSession(); close() } },
    { kind: "action", id: "settings",     label: "Settings",      hint: "⌘,",   run: () => { openSettings(); close() } },
    { kind: "action", id: "toggle-theme", label: "Toggle Theme",  hint: "",     run: () => { toggleTheme(); close() } },
  ]

  const recentFiles = loadRecent()
  const allFilePaths = Array.from(new Set([...openTabs, ...recentFiles]))
  const fileItems: FileItem[] = allFilePaths.map(p => ({
    kind: "file",
    path: p,
    label: p.split(/[\\/]/).pop() ?? p,
  }))

  const q = query.toLowerCase()
  const filtered: CmdItem[] = [
    ...fileItems.filter(f => !q || f.label.toLowerCase().includes(q) || f.path.toLowerCase().includes(q)),
    ...actions.filter(a => !q || a.label.toLowerCase().includes(q)),
  ]

  // Clamp idx whenever list changes
  useEffect(() => { setIdx(i => Math.min(i, Math.max(0, filtered.length - 1))) }, [filtered.length])

  function select(item: CmdItem) {
    if (item.kind === "file") {
      saveRecent(item.path)
      openFile(item.path)
      close()
    } else {
      item.run()
    }
  }

  function onKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Escape") { e.preventDefault(); close(); return }
    if (e.key === "ArrowDown") { e.preventDefault(); setIdx(i => Math.min(i + 1, filtered.length - 1)); return }
    if (e.key === "ArrowUp")   { e.preventDefault(); setIdx(i => Math.max(i - 1, 0)); return }
    if (e.key === "Enter" && filtered[idx]) { e.preventDefault(); select(filtered[idx]); return }
  }

  if (!open) return null

  return (
    <div className="cmd-overlay" onClick={close}>
      <div className="cmd-modal" onClick={e => e.stopPropagation()}>
        {/* Input */}
        <div className="cmd-input-wrap">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: "var(--t-400)", flexShrink: 0 }}>
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            ref={inputRef}
            value={query}
            onChange={e => { setQuery(e.target.value); setIdx(0) }}
            onKeyDown={onKeyDown}
            placeholder="Search files, actions…"
          />
        </div>

        {/* Results */}
        <div className="cmd-results">
          {filtered.length === 0 && (
            <div style={{ padding: "12px 16px", fontSize: 12, color: "var(--t-400)" }}>No results</div>
          )}
          {filtered.map((item, i) => {
            const active = i === idx
            if (item.kind === "file") {
              const short = item.path.length > 60 ? "…" + item.path.slice(-58) : item.path
              return (
                <div
                  key={item.path}
                  className={`cmd-item${active ? " active" : ""}`}
                  onMouseEnter={() => setIdx(i)}
                  onClick={() => select(item)}
                >
                  <span className="cmd-item-icon">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                      <polyline points="14 2 14 8 20 8"/>
                    </svg>
                  </span>
                  <span className="cmd-item-label">{item.label}</span>
                  <span className="cmd-item-hint">{short}</span>
                </div>
              )
            } else {
              return (
                <div
                  key={item.id}
                  className={`cmd-item${active ? " active" : ""}`}
                  onMouseEnter={() => setIdx(i)}
                  onClick={() => select(item)}
                >
                  <span className="cmd-item-icon">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="9 10 4 15 9 20"/><path d="M20 4v7a4 4 0 0 1-4 4H4"/>
                    </svg>
                  </span>
                  <span className="cmd-item-label">{item.label}</span>
                  {item.hint && <span className="cmd-item-hint">{item.hint}</span>}
                </div>
              )
            }
          })}
        </div>
      </div>
    </div>
  )
}
