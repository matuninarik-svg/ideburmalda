import { useEffect, useRef, useState } from "react"
import { useIde } from "@/state/state"
import { BASE } from "@/services/api"

interface ContextMenuProps {
  x: number
  y: number
  visible: boolean
  targetType: "explorer" | "editor" | "general"
  targetPath?: string   // relative path from workspace root
  targetKind?: "file" | "folder"
  onClose: () => void
}

// ── path helpers ──────────────────────────────────────────────────────────────
function parentOf(path: string) {
  const parts = path.replace(/\\/g, "/").split("/")
  parts.pop()
  return parts.join("/")
}
function nameOf(path: string) {
  return path.replace(/\\/g, "/").split("/").pop() ?? path
}

// ── icon ──────────────────────────────────────────────────────────────────────
function Icon({ d }: { d: string }) {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="1.8"
      strokeLinecap="round" strokeLinejoin="round">
      <path d={d} />
    </svg>
  )
}

const IC = {
  newFile:   "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z",
  newFolder: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z",
  reveal:    "M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
  terminal:  "M4 17l6-6-6-6M12 19h8",
  cut:       "M6 2v10M6 22a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM18 22a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM18 2L6 12M18 2v10",
  copy:      "M8 8H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-2M16 2h-4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V6z",
  paste:     "M9 2h6a2 2 0 0 1 2 2v1H7V4a2 2 0 0 1 2-2zM7 5H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2",
  link:      "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",
  rename:    "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",
  trash:     "M3 6h18M19 6l-1 14H6L5 6M10 11v6M14 11v6M9 6V4h6v2",
  settings:  "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
}

// ── item ──────────────────────────────────────────────────────────────────────
function Item({
  icon, label, shortcut, danger, disabled, onClick,
}: {
  icon: React.ReactNode
  label: string
  shortcut?: string
  danger?: boolean
  disabled?: boolean
  onClick: () => void
}) {
  return (
    <button
      className={[
        "ctx-item",
        danger    ? "ctx-item-danger"    : "",
        disabled  ? "ctx-item-disabled"  : "",
      ].join(" ").trim()}
      disabled={disabled}
      onMouseDown={e => { e.preventDefault(); e.stopPropagation() }}
      onClick={e => { e.stopPropagation(); if (!disabled) onClick() }}
    >
      <span className="ctx-item-icon">{icon}</span>
      <span className="ctx-item-label">{label}</span>
      {shortcut && <span className="ctx-item-shortcut">{shortcut}</span>}
    </button>
  )
}

function Sep() { return <div className="ctx-divider" /> }

// ── inline name input ─────────────────────────────────────────────────────────
function NameInput({
  placeholder,
  initial,
  onConfirm,
  onCancel,
}: {
  placeholder: string
  initial: string
  onConfirm: (v: string) => void
  onCancel: () => void
}) {
  const [val, setVal] = useState(initial)
  const ref = useRef<HTMLInputElement>(null)
  const confirmed = useRef(false)

  useEffect(() => {
    setTimeout(() => { ref.current?.focus(); ref.current?.select() }, 30)
  }, [])

  function confirm() {
    if (confirmed.current) return
    const v = val.trim()
    if (!v) { onCancel(); return }
    confirmed.current = true
    onConfirm(v)
  }

  return (
    <input
      ref={ref}
      className="ctx-inline-input"
      value={val}
      placeholder={placeholder}
      onChange={e => setVal(e.target.value)}
      onKeyDown={e => {
        if (e.key === "Enter")  { e.preventDefault(); confirm() }
        if (e.key === "Escape") { e.preventDefault(); onCancel() }
      }}
      onBlur={confirm}
      onMouseDown={e => e.stopPropagation()}
      onClick={e => e.stopPropagation()}
    />
  )
}

// ── main ──────────────────────────────────────────────────────────────────────
// Clipboard lives outside component so it survives menu close/reopen
let _clipboard: { kind: "copy" | "cut"; path: string } | null = null

export function ContextMenu({
  x, y, visible, targetType, targetPath, targetKind, onClose,
}: ContextMenuProps) {
  const { workspace, openSettings } = useIde()
  const menuRef = useRef<HTMLDivElement>(null)
  const [renaming, setRenaming] = useState(false)

  // Reset rename state when menu closes/reopens
  useEffect(() => {
    if (visible) setRenaming(false)
  }, [visible])

  // Close on outside click
  useEffect(() => {
    if (!visible) return
    function handle(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose()
      }
    }
    // slight delay so the right-click that opened it doesn't immediately close it
    const t = setTimeout(() => document.addEventListener("mousedown", handle), 50)
    return () => { clearTimeout(t); document.removeEventListener("mousedown", handle) }
  }, [visible, onClose])

  if (!visible) return null

  // keep menu within viewport
  const menuW = 214
  const fx = x + menuW > window.innerWidth  ? window.innerWidth  - menuW - 8 : x
  const fy = y + 280   > window.innerHeight ? window.innerHeight - 280   - 8 : y

  // ── api helper ──────────────────────────────────────────────────────────────
  async function api(endpoint: string, body: object) {
    const res = await fetch(`${BASE}/api/workspace/${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
    if (!res.ok) {
      const j = await res.json().catch(() => ({}))
      throw new Error(j.detail ?? `HTTP ${res.status}`)
    }
    return res.json()
  }

  function refresh() {
    window.dispatchEvent(new CustomEvent("sharrowkin:refresh-explorer"))
  }

  function done() { onClose() }

  // parent for "new" items: if clicked on a folder → that folder, else its parent
  const parentDir = targetPath
    ? (targetKind === "folder" ? targetPath : parentOf(targetPath))
    : ""

  // dispatch event to Explorer to show inline input in the tree
  function startNewFile() {
    window.dispatchEvent(new CustomEvent("sharrowkin:new-item", { detail: { parent: parentDir, kind: "file" } }))
    onClose()
  }

  function startNewFolder() {
    window.dispatchEvent(new CustomEvent("sharrowkin:new-item", { detail: { parent: parentDir, kind: "folder" } }))
    onClose()
  }

  async function doRename(newName: string) {
    if (!targetPath) return
    try {
      await api("rename", { workspace, path: targetPath, new_name: newName })
      refresh()
    } catch (e: any) { alert("Rename: " + e.message) }
    done()
  }

  async function doDelete() {
    if (!targetPath) return
    if (!confirm(`Delete "${nameOf(targetPath)}"?`)) return
    try {
      await api("delete", { workspace, path: targetPath })
      refresh()
    } catch (e: any) { alert("Delete: " + e.message) }
    done()
  }

  async function doReveal() {
    done()
    if (!workspace) return
    await api("open-in-explorer", { workspace, path: targetPath ?? "" }).catch(() => {})
  }

  async function doTerminal() {
    done()
    if (!workspace) return
    await api("open-terminal", { workspace, path: targetPath ?? "" }).catch(() => {})
  }

  function doCopyPath() {
    if (!workspace || !targetPath) return
    const abs = workspace.replace(/[\\/]+$/, "") + "\\" + targetPath.replace(/\//g, "\\")
    navigator.clipboard.writeText(abs)
    done()
  }

  function doCopyRelPath() {
    if (!targetPath) return
    navigator.clipboard.writeText(targetPath.replace(/\//g, "\\"))
    done()
  }

  function doCopyText() {
    const sel = window.getSelection()?.toString()
    if (sel) navigator.clipboard.writeText(sel)
    done()
  }

  function doCut() {
    if (!targetPath) return
    _clipboard = { kind: "cut", path: targetPath }
    done()
  }

  function doCopy() {
    if (!targetPath) return
    _clipboard = { kind: "copy", path: targetPath }
    done()
  }

  const isExplorer   = targetType === "explorer"
  const isEditor     = targetType === "editor"
  const hasPath      = !!targetPath
  const hasSelection = !!window.getSelection()?.toString()
  const hasClip      = !!_clipboard

  // ── rename inline (still inside the popup) ──────────────────────────────────
  if (renaming) {
    return (
      <div ref={menuRef} className="ctx-menu" style={{ left: fx, top: fy, minWidth: menuW }}>
        <div className="ctx-inline-label">Rename "{nameOf(targetPath ?? "")}"</div>
        <div style={{ padding: "4px 6px 2px" }}>
          <NameInput
            placeholder={nameOf(targetPath ?? "")}
            initial={nameOf(targetPath ?? "")}
            onConfirm={doRename}
            onCancel={done}
          />
        </div>
        <div style={{ padding: "3px 10px 7px", fontSize: 10.5, color: "var(--t-400)" }}>
          Enter to confirm · Esc to cancel
        </div>
      </div>
    )
  }

  // ── main menu ───────────────────────────────────────────────────────────────
  return (
    <div
      ref={menuRef}
      className="ctx-menu"
      style={{ left: fx, top: fy, minWidth: menuW }}
    >
      {isExplorer && (
        <>
          <Item icon={<Icon d={IC.newFile}   />} label="New File..."   onClick={startNewFile} />
          <Item icon={<Icon d={IC.newFolder} />} label="New Folder..." onClick={startNewFolder} />
          <Sep />
          <Item icon={<Icon d={IC.reveal}   />} label="Reveal in Explorer" shortcut="Shift+Alt+R" onClick={doReveal} />
          <Item icon={<Icon d={IC.terminal} />} label="Open in Terminal"   onClick={doTerminal} />
          <Sep />
          <Item icon={<Icon d={IC.cut}  />} label="Cut"   shortcut="Ctrl+X" disabled={!hasPath} onClick={doCut} />
          <Item icon={<Icon d={IC.copy} />} label="Copy"  shortcut="Ctrl+C" disabled={!hasPath} onClick={doCopy} />
          <Item icon={<Icon d={IC.paste}/>} label="Paste" shortcut="Ctrl+V" disabled={!hasClip} onClick={() => done()} />
          {hasPath && (
            <>
              <Sep />
              <Item icon={<Icon d={IC.link} />} label="Copy Path"          shortcut="Shift+Alt+C" onClick={doCopyPath} />
              <Item icon={<Icon d={IC.link} />} label="Copy Relative Path"  onClick={doCopyRelPath} />
            </>
          )}
          {hasPath && (
            <>
              <Sep />
              <Item icon={<Icon d={IC.rename} />} label="Rename..." shortcut="F2"  onClick={() => setRenaming(true)} />
              <Item icon={<Icon d={IC.trash}  />} label="Delete"    shortcut="Del" danger onClick={doDelete} />
            </>
          )}
          <Sep />
        </>
      )}

      {!isExplorer && (hasSelection || isEditor) && (
        <>
          <Item icon={<Icon d={IC.copy} />} label="Copy" shortcut="Ctrl+C" onClick={doCopyText} />
          <Sep />
        </>
      )}

      {!isExplorer && !isEditor && workspace && (
        <>
          <Item icon={<Icon d={IC.reveal}   />} label="Reveal in Explorer" onClick={doReveal} />
          <Item icon={<Icon d={IC.terminal} />} label="Open in Terminal"   onClick={doTerminal} />
          <Sep />
        </>
      )}

      <Item icon={<Icon d={IC.settings} />} label="Settings" onClick={() => { done(); openSettings() }} />
    </div>
  )
}
