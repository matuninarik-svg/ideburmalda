import { useIde, type SavedSession } from "@/state/state"

function timeAgo(ts: number) {
  const d = (Date.now() - ts) / 1000
  if (d < 60) return "just now"
  if (d < 3600) return `${Math.floor(d / 60)}m ago`
  if (d < 86400) return `${Math.floor(d / 3600)}h ago`
  if (d < 86400 * 7) return `${Math.floor(d / 86400)}d ago`
  return new Date(ts).toLocaleDateString("en", { month: "short", day: "numeric" })
}

export function SessionHistory() {
  const { savedSessions, loadSession, newSession, closeHistory, workspace } = useIde()
  const proj = workspace?.split(/[\\/]/).filter(Boolean).pop() ?? "project"

  return (
    <div className="sh-root">
      <div className="sh-bar">
        <button className="ic sh-back" onClick={closeHistory}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <div className="sh-title-wrap">
          <span className="sh-title">History</span>
          <span className="sh-proj">{proj}</span>
        </div>
        <button className="sh-new-btn" onClick={newSession}>New session</button>
      </div>

      <div className="sh-body">
        {savedSessions.length === 0 ? (
          <div className="sh-empty">
            <p className="sh-empty-title">No sessions yet</p>
            <p className="sh-empty-sub">Sessions save automatically when you start a new one</p>
          </div>
        ) : (
          <div className="sh-list">
            {savedSessions.map((s, i) => (
              <SessionCard key={s.id} s={s} i={i} onLoad={() => loadSession(s)} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function SessionCard({ s, i, onLoad }: { s: SavedSession; i: number; onLoad: () => void }) {
  const userCount = s.turns.filter(t => t.kind === "user").length

  return (
    <button className="sh-card" style={{ animationDelay: `${i * 35}ms` }} onClick={onLoad}>
      <div className="sh-card-body">
        <span className="sh-card-preview">{s.preview || "Untitled session"}</span>
        <div className="sh-card-meta">
          <span>{timeAgo(s.createdAt)}</span>
          <span className="sh-dot"/>
          <span>{userCount} message{userCount !== 1 ? "s" : ""}</span>
        </div>
      </div>
      <svg className="sh-card-arrow" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <polyline points="9 18 15 12 9 6"/>
      </svg>
    </button>
  )
}
