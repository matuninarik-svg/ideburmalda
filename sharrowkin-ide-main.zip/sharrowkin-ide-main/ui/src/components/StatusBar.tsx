import { useIde } from "@/state/state"
import { extToLanguage } from "@/services/api"

const EXT_DISPLAY: Record<string, string> = {
  python:     "Python",
  javascript: "TypeScript · JS",
  json:       "JSON",
  markdown:   "Markdown",
  html:       "HTML",
  text:       "Plain Text",
}

function getExtension(path: string): string | null {
  const dot = path.lastIndexOf(".")
  return dot >= 0 ? path.slice(dot) : null
}

export function StatusBar({ onGitClick, gitActive, onGraphClick, graphActive }: {
  onGitClick?: () => void; gitActive?: boolean
  onGraphClick?: () => void; graphActive?: boolean
}) {
  const { workspace, activeTab, isRunning, toggleTheme, theme } = useIde()

  const projName = workspace?.split(/[\\/]/).filter(Boolean).pop() ?? null
  const ext = activeTab ? getExtension(activeTab) : null
  const langId = extToLanguage(ext)
  const langLabel = activeTab ? (EXT_DISPLAY[langId] ?? langId) : null
  const fileName = activeTab?.split(/[\\/]/).pop() ?? null

  return (
    <div className="status-bar">
      {/* Left */}
      <div
        className="status-item"
        title={workspace ?? ""}
        onClick={onGitClick}
        style={{ cursor: "pointer", background: gitActive ? "var(--hover)" : undefined }}
      >
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
          <path d="M18 9a9 9 0 0 1-9 9"/>
        </svg>
        main
        {projName && <span style={{ color: "var(--t-300)" }}>·</span>}
        {projName && <span>{projName}</span>}
      </div>

      {isRunning && (
        <>
          <div className="status-sep" />
          <div className="status-item" style={{ color: "var(--accent)" }}>
            <span className="dotpulse" style={{ width: 5, height: 5, background: "var(--accent)", borderRadius: "50%", display: "inline-block" }} />
            Agent running
          </div>
        </>
      )}

      {/* Right */}
      <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 2 }}>
        {fileName && (
          <>
            <div className="status-item" style={{ color: "var(--t-500)" }}>{fileName}</div>
            <div className="status-sep" />
          </>
        )}
        {langLabel && (
          <>
            <div className="status-item">{langLabel}</div>
            <div className="status-sep" />
          </>
        )}
        <div className="status-item">UTF-8</div>
        <div className="status-sep" />
        <div
          className="status-item"
          onClick={onGraphClick}
          style={{ cursor: "pointer", background: graphActive ? "var(--hover)" : undefined }}
          title="Project graph"
        >
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="5" cy="12" r="2"/><circle cx="19" cy="5" r="2"/><circle cx="19" cy="19" r="2"/>
            <line x1="7" y1="11" x2="17" y2="6"/><line x1="7" y1="13" x2="17" y2="18"/>
          </svg>
          Graph
        </div>
        <div className="status-sep" />
        <div className="status-item" onClick={toggleTheme} style={{ cursor: "pointer" }} title="Toggle theme">
          {theme === "dark"
            ? <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
            : <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
          }
        </div>
      </div>
    </div>
  )
}
