import { type ReactNode } from 'react'
import { useIde } from "@/state/state"
import { minimizeWindow, toggleMaximizeWindow, closeWindow } from "@/services/window"

// Shared window controls — identical across Welcome / Settings / workspace so the
// chrome reads as one app. Wired to the Tauri window API (no-ops in the browser).
export function WindowControls() {
  return (
    <div className="win">
      <button className="wbtn" title="Minimize" onClick={minimizeWindow}>
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><line x1="5" y1="12" x2="19" y2="12"/></svg>
      </button>
      <button className="wbtn" title="Maximize" onClick={toggleMaximizeWindow}>
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="4" y="4" width="16" height="16" rx="3"/></svg>
      </button>
      <button className="wbtn close" title="Close" onClick={closeWindow}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>
      </button>
    </div>
  )
}

// One titlebar shell used everywhere: a draggable bar with a `left` slot and the
// shared window controls on the right. Keeps a single source of truth for height,
// drag region, and button styling.
export function TitleBar({ left }: { left?: ReactNode }) {
  return (
    <div className="titlebar" data-tauri-drag-region>
      <div className="tb-left" data-tauri-drag-region>{left}</div>
      <WindowControls />
    </div>
  )
}

// Workspace variant: brand + project switch / settings.
export function WorkspaceTitleBar() {
  const { openSettings, closeProject, workspace, sidebarHidden, toggleSidebar, theme, toggleTheme } = useIde()
  const projName = workspace?.split(/[\\/]/).filter(Boolean).pop() ?? null

  return (
    <TitleBar
      left={
        <>
          <button
            className={`qbtn${sidebarHidden ? "" : " on"}`}
            title={sidebarHidden ? "Show sidebar" : "Hide sidebar"}
            onClick={toggleSidebar}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
              <rect x="3" y="4" width="18" height="16" rx="2"/><line x1="9" y1="4" x2="9" y2="20"/>
            </svg>
          </button>
          <span className="name">Sharrowkin</span>
          <div className="quick">
            {projName && (
              <button className="qbtn" title="Switch project" onClick={closeProject} style={{ gap: 5, fontSize: 11.5, fontWeight: 500, color: "var(--t-500)" }}>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
                {projName}
              </button>
            )}
            <button className="qbtn" title={theme === "dark" ? "Light theme" : "Dark theme"} onClick={toggleTheme}>
              {theme === "dark" ? (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                  <circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32l1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41m11.32-11.32l1.41-1.41"/>
                </svg>
              ) : (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                  <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
                </svg>
              )}
            </button>
            <button className="qbtn" title="Settings" onClick={openSettings}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
                <circle cx="12" cy="12" r="3"/><path d="M12 1v6m0 6v6M4.22 4.22l4.24 4.24m5.08 5.08l4.24 4.24M1 12h6m6 0h6m-17.78 7.78l4.24-4.24m5.08-5.08l4.24-4.24"/>
              </svg>
            </button>
          </div>
        </>
      }
    />
  )
}
