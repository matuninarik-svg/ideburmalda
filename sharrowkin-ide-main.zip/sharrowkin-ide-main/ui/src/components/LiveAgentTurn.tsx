import React, { useEffect, useRef, useState } from "react"
import { useIde, type AgentTurn } from "@/state/state"

// Smoothly reveals streamed text. Driven by requestAnimationFrame off refs, so
// it's decoupled from how fast content chunks arrive: it catches up when far
// behind and eases out when close. Always completes — when streaming ends it
// reveals the full text immediately rather than freezing mid-way.
function useTypewriter(full: string, active: boolean): string {
  const [, force] = useState(0)
  const shownLen = useRef(0)
  const targetRef = useRef(full)
  const rafRef = useRef<number | null>(null)
  targetRef.current = full

  useEffect(() => {
    // New turn / reset: content shrank below what we've shown.
    if (full.length < shownLen.current) shownLen.current = 0

    const cancel = () => {
      if (rafRef.current != null) {
        cancelAnimationFrame(rafRef.current)
        rafRef.current = null
      }
    }

    if (!active) {
      cancel()
      shownLen.current = full.length
      force((n) => n + 1)
      return
    }

    const step = () => {
      const target = targetRef.current.length
      if (shownLen.current >= target) {
        rafRef.current = null
        return
      }
      const gap = target - shownLen.current
      // Far behind → reveal in bigger bites; close → 1-2 chars for a natural feel.
      const advance = gap > 80 ? Math.ceil(gap / 5) : gap > 12 ? 3 : 1
      shownLen.current = Math.min(shownLen.current + advance, target)
      force((n) => n + 1)
      rafRef.current = requestAnimationFrame(step)
    }

    cancel()
    rafRef.current = requestAnimationFrame(step)
    return cancel
  }, [full, active])

  return active ? full.slice(0, shownLen.current) : full
}

// ── Markdown renderer ──────────────────────────────────────────────────────
function renderInline(text: string): React.ReactNode[] {
  // bold **x**, inline code `x`, italic *x*
  const parts: React.ReactNode[] = []
  const re = /(\*\*(.+?)\*\*|`([^`]+)`|\*([^*]+)\*)/g
  let last = 0, m: RegExpExecArray | null
  let key = 0
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index))
    if (m[2]) parts.push(<strong key={key++}>{m[2]}</strong>)
    else if (m[3]) parts.push(<code key={key++} className="prose">{m[3]}</code>)
    else if (m[4]) parts.push(<em key={key++}>{m[4]}</em>)
    last = re.lastIndex
  }
  if (last < text.length) parts.push(text.slice(last))
  return parts
}

function Markdown({ text }: { text: string }) {
  const lines = text.split("\n")
  const nodes: React.ReactNode[] = []
  let i = 0, key = 0

  while (i < lines.length) {
    const line = lines[i]

    // Code block ```
    if (line.trimStart().startsWith("```")) {
      const lang = line.replace(/^```/, "").trim()
      const codeLines: string[] = []
      i++
      while (i < lines.length && !lines[i].trimStart().startsWith("```")) {
        codeLines.push(lines[i])
        i++
      }
      nodes.push(
        <div key={key++} className="md-code-block">
          {lang && <span className="md-code-lang">{lang}</span>}
          <pre><code>{codeLines.join("\n")}</code></pre>
        </div>
      )
      i++
      continue
    }

    // H2 ##
    if (line.startsWith("## ")) {
      nodes.push(<h2 key={key++} className="md-h2">{renderInline(line.slice(3))}</h2>)
      i++; continue
    }
    // H3 ###
    if (line.startsWith("### ")) {
      nodes.push(<h3 key={key++} className="md-h3">{renderInline(line.slice(4))}</h3>)
      i++; continue
    }
    // H4 ####
    if (line.startsWith("#### ")) {
      nodes.push(<h4 key={key++} className="md-h4">{renderInline(line.slice(5))}</h4>)
      i++; continue
    }

    // Table | ... |
    if (line.startsWith("|")) {
      const rows: string[][] = []
      while (i < lines.length && lines[i].startsWith("|")) {
        if (!lines[i].match(/^\|[-| :]+\|$/)) {
          rows.push(lines[i].split("|").slice(1, -1).map(c => c.trim()))
        }
        i++
      }
      if (rows.length > 0) {
        nodes.push(
          <table key={key++} className="md-table">
            <thead><tr>{rows[0].map((c, j) => <th key={j}>{renderInline(c)}</th>)}</tr></thead>
            <tbody>{rows.slice(1).map((r, ri) => <tr key={ri}>{r.map((c, j) => <td key={j}>{renderInline(c)}</td>)}</tr>)}</tbody>
          </table>
        )
      }
      continue
    }

    // Bullet list - or *
    if (line.match(/^(\s*)([-*✅✓•]) /)) {
      const items: React.ReactNode[] = []
      while (i < lines.length && lines[i].match(/^(\s*)([-*✅✓•]) /)) {
        const content = lines[i].replace(/^(\s*)([-*✅✓•]) /, "")
        items.push(<li key={i}>{renderInline(content)}</li>)
        i++
      }
      nodes.push(<ul key={key++} className="md-ul">{items}</ul>)
      continue
    }

    // Numbered list
    if (line.match(/^\d+\. /)) {
      const items: React.ReactNode[] = []
      while (i < lines.length && lines[i].match(/^\d+\. /)) {
        const content = lines[i].replace(/^\d+\. /, "")
        items.push(<li key={i}>{renderInline(content)}</li>)
        i++
      }
      nodes.push(<ol key={key++} className="md-ol">{items}</ol>)
      continue
    }

    // Horizontal rule ---
    if (line.match(/^---+$/)) {
      nodes.push(<hr key={key++} className="md-hr" />)
      i++; continue
    }

    // Empty line → spacer
    if (line.trim() === "") {
      nodes.push(<div key={key++} className="md-gap" />)
      i++; continue
    }

    // Plain paragraph
    nodes.push(<p key={key++} className="md-p">{renderInline(line)}</p>)
    i++
  }

  return <div className="md-root">{nodes}</div>
}

// ── Turn renderer ──────────────────────────────────────────────────────────

// Per-tool glyph, matching the DemoThread design (file / search / edit / run / git).
function ToolIcon({ tool }: { tool: string }) {
  const s = { width: 12, height: 12, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.7 } as const
  if (tool === "search_files" || tool === "search_code" || tool === "search_workspace" || tool === "find_symbol") {
    return <svg {...s}><circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
  }
  if (tool === "write_file" || tool === "str_replace") {
    return <svg {...s}><path d="M12 20h9" /><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" /></svg>
  }
  if (tool === "run_tests" || tool === "run_command" || tool === "terminal" || tool === "verify") {
    return <svg {...s}><polyline points="4 17 10 11 4 5" /><line x1="12" y1="19" x2="20" y2="19" /></svg>
  }
  if (tool === "git" || tool === "git_diff") {
    return <svg {...s}><circle cx="18" cy="6" r="3" /><circle cx="6" cy="18" r="3" /><path d="M6 9v6M18 9a9 9 0 0 1-9 9" /></svg>
  }
  // default: file/read glyph
  return <svg {...s}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /></svg>
}

function MidThought({ text }: { text: string }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="mid-thought">
      <button className="mid-thought-header" onClick={() => setOpen(o => !o)}>
        <svg className="spin" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" style={{ flexShrink: 0, color: "var(--t-400)" }}>
          <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
        </svg>
        <span className="mid-thought-label">Thinking</span>
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"
          style={{ color: "var(--t-300)", transform: open ? "rotate(180deg)" : "none", transition: "transform .15s", flexShrink: 0 }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>
      {open && <div className="mid-thought-text">{text}</div>}
    </div>
  )
}

const EDIT_TOOLS = new Set(["write_file", "str_replace"])
const TERM_TOOLS = new Set(["run_command", "run_tests", "terminal", "verify"])

function StatusDot({ status }: { status: string }) {
  if (status === "running") return (
    <svg className="spin" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{ color: "var(--t-400)", flexShrink: 0 }}>
      <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
    </svg>
  )
  if (status === "error") return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{ color: "#dc2626", flexShrink: 0 }}>
      <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="13"/><line x1="12" y1="16.5" x2="12" y2="16.5"/>
    </svg>
  )
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.8" style={{ color: "#059669", flexShrink: 0 }}>
      <polyline points="20 6 9 17 4 12"/>
    </svg>
  )
}

function ToolRow({ tl, idx = 0 }: { tl: import("../state").ToolItem; idx?: number }) {
  const { openFile, setTermTab, setActiveLine } = useIde()
  const isEdit = EDIT_TOOLS.has(tl.tool)
  const isTerm = TERM_TOOLS.has(tl.tool)
  const isClickable = (isEdit && !!tl.target) || isTerm
  const [menu, setMenu] = useState<{ x: number; y: number } | null>(null)

  function handleClick(e: React.MouseEvent) {
    if (menu) return
    if (isEdit && tl.target) {
      // Extract first added line from args if present, fallback to line 1
      const line = (tl.args?.["line"] as number | undefined) ??
                   (tl.args?.["start_line"] as number | undefined) ??
                   1
      openFile(tl.target)
      setActiveLine(line)
    } else if (isTerm) {
      setTermTab("Terminal")
    }
  }

  function onContextMenu(e: React.MouseEvent) {
    e.preventDefault()
    setMenu({ x: e.clientX, y: e.clientY })
  }

  useEffect(() => {
    if (!menu) return
    const close = () => setMenu(null)
    window.addEventListener("click", close)
    return () => window.removeEventListener("click", close)
  }, [menu])

  return (
    <div className="tr-wrap" style={{ animationDelay: `${idx * 25}ms` }}>
      <div
        className={`tr${isClickable ? " tr-clickable" : ""}`}
        onClick={handleClick}
        onContextMenu={onContextMenu}
        title={isEdit && tl.target ? `Open ${tl.target}` : isTerm ? "Open Terminal" : undefined}
      >
        <StatusDot status={tl.status} />
        <span className="tr-label">{tl.label}</span>
        {tl.target && <span className="tr-target">{tl.target.split(/[/\\]/).pop()}</span>}
        {isClickable && (
          <svg
            width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2"
            style={{ color: "var(--t-300)", marginLeft: "auto", flexShrink: 0, transition: "color .15s" }}
            className="tr-goto-arrow"
          >
            {isEdit
              ? <><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></>
              : <><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></>
            }
          </svg>
        )}
      </div>

      {/* Right-click context popup */}
      {menu && (
        <div
          className="tr-ctx"
          style={{ position: "fixed", left: menu.x, top: menu.y }}
          onClick={e => e.stopPropagation()}
        >
          {tl.target && (
            <div className="tr-ctx-row">
              <span className="tr-ctx-key">File</span>
              <span className="tr-ctx-val">{tl.target}</span>
            </div>
          )}
          {tl.detail && (
            <div className="tr-ctx-row">
              <span className="tr-ctx-key">Result</span>
              <span className="tr-ctx-val">{tl.detail}</span>
            </div>
          )}
          {isEdit && tl.result && (
            <div className="tr-ctx-code">
              <pre>{tl.result.slice(0, 2000)}</pre>
            </div>
          )}
          {!tl.target && !tl.detail && !tl.result && (
            <div className="tr-ctx-row">
              <span className="tr-ctx-val" style={{ color: "var(--t-400)" }}>No details</span>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export function LiveAgentTurn({ turn }: { turn: AgentTurn }) {
  const streaming = turn.status === "running"
  const visibleContent = useTypewriter(turn.content, streaming)
  const [toolsOpen, setToolsOpen] = useState(true)

  // Auto-collapse when done
  useEffect(() => {
    if (turn.status === "done" && turn.tools.length > 0) {
      setToolsOpen(false)
    }
  }, [turn.status])

  return (
    <div className="msg-a">

      {/* Thinking */}
      {turn.thinking && (
        <div className="think-wrap">
          <div className="think-toggle open" style={{ cursor: "default" }}>
            <svg className="spin" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <path d="M21 12a9 9 0 1 1-6.219-8.56" />
            </svg>
            Thinking
          </div>
          <div className="think-body show">{turn.thinking}</div>
        </div>
      )}

      {/* Plan */}
      {turn.plan && turn.plan.length > 0 && (
        <div className="plan-block">
          <div className="plan-head">
            <span className="plan-title">Plan</span>
            <span className="plan-count">
              {turn.plan.filter(p => p.status === "done" || p.status === "completed").length} / {turn.plan.length}
            </span>
          </div>
          <div className="plan-list">
            {turn.plan.map((p, idx) => {
              const cls = p.status === "done" || p.status === "completed" ? "done"
                : p.status === "in_progress" || p.status === "running" || p.status === "active" ? "active"
                : "todo"
              return (
                <div className={`plan-item ${cls}`} key={p.id} style={{ animationDelay: `${idx * 40}ms` }}>
                  <span className="plan-dot" />
                  <span className="plan-text">{p.title}</span>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Working dropdown — all tool calls collapsed like Thinking */}
      {turn.tools.length > 0 && (
        <div className="think-wrap">
          <button className={`think-toggle${toolsOpen ? " open" : ""}`} onClick={() => setToolsOpen(o => !o)}>
            {streaming && turn.tools.some(t => t.status === "running") ? (
              <svg className="spin" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                <path d="M21 12a9 9 0 1 1-6.219-8.56" />
              </svg>
            ) : (
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            )}
            {streaming && turn.tools.some(t => t.status === "running")
              ? `Working · ${turn.tools.length} step${turn.tools.length !== 1 ? "s" : ""}`
              : `Done · ${turn.tools.length} step${turn.tools.length !== 1 ? "s" : ""}`}
            <svg className="tchev" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>
          {toolsOpen && (
            <div className="tools-list">
              {turn.tools.map((tl, idx) => (
                <React.Fragment key={tl.key}>
                  <ToolRow tl={tl} idx={idx} />
                  {(turn.midThoughts ?? [])
                    .filter(t => t.afterTool === idx + 1)
                    .map((t, ti) => (
                      <MidThought key={`mt-${idx}-${ti}`} text={t.text} />
                    ))}
                </React.Fragment>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Reasoning lines */}
      {turn.reasonings.map((r, i) => (
        <div className="reasoning" key={i}>{r}</div>
      ))}

      {/* Diffs */}
      {turn.diffs.map((d, i) => (
        <div className="diff" key={i}>
          <div className="diff-head">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
            </svg>
            {d.files?.[0] ?? "changes"}
          </div>
          <div className="diff-body">
            {d.diff.split("\n").map((ln, j) => {
              const cls = ln.startsWith("+") ? "add" : ln.startsWith("-") ? "del" : ln.startsWith("@@") ? "hunk" : "ctx"
              return <div className={`dl ${cls}`} key={j}><span className="dl-n" />{ln}</div>
            })}
          </div>
        </div>
      ))}

      {/* Content — rendered as markdown */}
      {visibleContent && (
        <div className="prose">
          <Markdown text={visibleContent} />
          {streaming && <span className="scursor" />}
        </div>
      )}

      {/* Error */}
      {turn.status === "error" && (
        <div className="prose" style={{ color: "#b91c1c" }}>{turn.error}</div>
      )}

      {/* Loading state */}
      {turn.status === "running" && !turn.thinking && !turn.content && turn.tools.length === 0 && (
        <div className="reasoning">Working<span className="scursor" /></div>
      )}
    </div>
  )
}

export function Transcript() {
  const { turns } = useIde()
  return (
    <>
      {turns.map(t =>
        t.kind === "user" ? (
          <div className="msg-u" key={t.id}><div className="bbl">{t.text}</div></div>
        ) : (
          <LiveAgentTurn turn={t.turn} key={t.id} />
        )
      )}
    </>
  )
}
