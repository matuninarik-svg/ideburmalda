import { useEffect, useRef, useState } from "react"
import { Terminal as XTerm } from "@xterm/xterm"
import { FitAddon } from "@xterm/addon-fit"
import { useIde } from "@/state/state"
import { WS_BASE } from "@/services/api"
import "@xterm/xterm/css/xterm.css"

const TABS = ["Terminal", "Output", "Problems"]

// xterm can't read CSS variables, so each app theme gets an explicit palette.
const XTERM_THEMES = {
  light: {
    background:      "#ffffff",
    foreground:      "#2e2e35",
    cursor:          "#2563eb",
    cursorAccent:    "#ffffff",
    selectionBackground: "rgba(37,99,235,0.18)",
    black:           "#44444c",
    red:             "#dc2626",
    green:           "#059669",
    yellow:          "#d97706",
    blue:            "#2563eb",
    magenta:         "#9333ea",
    cyan:            "#0891b2",
    white:           "#71717a",
    brightBlack:     "#a1a1aa",
    brightRed:       "#ef4444",
    brightGreen:     "#10b981",
    brightYellow:    "#f59e0b",
    brightBlue:      "#60a5fa",
    brightMagenta:   "#a855f7",
    brightCyan:      "#22d3ee",
    brightWhite:     "#1a1a1f",
  },
  dark: {
    background:      "#141417",
    foreground:      "#c9c9d1",
    cursor:          "#60a5fa",
    cursorAccent:    "#141417",
    selectionBackground: "rgba(96,165,250,0.25)",
    black:           "#3a3a42",
    red:             "#f87171",
    green:           "#4ade80",
    yellow:          "#fbbf24",
    blue:            "#60a5fa",
    magenta:         "#c084fc",
    cyan:            "#22d3ee",
    white:           "#c9c9d1",
    brightBlack:     "#6e6e78",
    brightRed:       "#fca5a5",
    brightGreen:     "#86efac",
    brightYellow:    "#fcd34d",
    brightBlue:      "#93c5fd",
    brightMagenta:   "#d8b4fe",
    brightCyan:      "#67e8f9",
    brightWhite:     "#f4f4f6",
  },
} as const

export function Terminal() {
  const { termTab, setTermTab, workspace, theme } = useIde()
  const wrapRef = useRef<HTMLDivElement>(null)
  const termRef = useRef<XTerm | null>(null)
  const fitRef = useRef<FitAddon | null>(null)
  const wsRef = useRef<WebSocket | null>(null)
  const roRef = useRef<ResizeObserver | null>(null)
  const workspaceRef = useRef<string | null>(workspace)
  workspaceRef.current = workspace
  const [status, setStatus] = useState<"connecting" | "connected" | "error" | "closed">("connecting")

  function boot() {
    const wrap = wrapRef.current
    if (!wrap) return

    // Destroy previous session if any
    wsRef.current?.close()
    termRef.current?.dispose()
    roRef.current?.disconnect()

    const term = new XTerm({
      cursorBlink: true,
      cursorStyle: "bar",
      fontSize: 12.5,
      fontFamily: '"JetBrains Mono", "Cascadia Code", "Fira Code", ui-monospace, monospace',
      lineHeight: 1.55,
      letterSpacing: 0.3,
      theme: XTERM_THEMES[theme],
      allowTransparency: false,
      scrollback: 3000,
      convertEol: true,
      allowProposedApi: true,
    })

    const fit = new FitAddon()
    term.loadAddon(fit)
    term.open(wrap)

    // Wait one frame so the DOM has real dimensions, then fit
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        try { fit.fit() } catch {}
      })
    })

    termRef.current = term
    fitRef.current = fit

    // Resize observer — refit on container size changes
    const ro = new ResizeObserver(() => {
      requestAnimationFrame(() => { try { fit.fit() } catch {} })
    })
    ro.observe(wrap)
    roRef.current = ro

    // WebSocket
    setStatus("connecting")
    const ws = new WebSocket(
      `${WS_BASE}/api/terminal/ws${workspaceRef.current ? `?workspace=${encodeURIComponent(workspaceRef.current)}` : ""}`,
    )
    wsRef.current = ws

    ws.onopen = () => {
      setStatus("connected")
      const dims = fit.proposeDimensions()
      if (dims) ws.send(JSON.stringify({ type: "resize", cols: dims.cols, rows: dims.rows }))
    }

    ws.onmessage = (e) => {
      term.write(typeof e.data === "string" ? e.data : new Uint8Array(e.data))
    }

    ws.onerror = () => setStatus("error")

    ws.onclose = () => {
      setStatus("closed")
      term.write("\r\n\x1b[2m── session ended ──\x1b[0m\r\n")
    }

    term.onData((data) => {
      if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "input", data }))
    })

    term.onResize(({ cols, rows }) => {
      if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: "resize", cols, rows }))
    })
  }

  // Boot on mount (when Terminal tab first shown)
  useEffect(() => {
    if (termTab !== "Terminal") return
    // Small delay to ensure wrapRef is in DOM
    const t = setTimeout(boot, 60)
    return () => {
      clearTimeout(t)
      wsRef.current?.close()
      termRef.current?.dispose()
      roRef.current?.disconnect()
      termRef.current = null
      wsRef.current = null
    }
  }, [])

  // Recolor the live terminal when the app theme changes (no session restart).
  useEffect(() => {
    if (termRef.current) termRef.current.options.theme = XTERM_THEMES[theme]
  }, [theme])

  const dotColor = status === "connected" ? "#10b981" : status === "error" ? "#ef4444" : status === "closed" ? "#a1a1aa" : "#f59e0b"
  const dotTitle = status === "connected" ? "Connected" : status === "error" ? "Connection error" : status === "closed" ? "Session closed" : "Connecting…"

  return (
    <section className="card terminal">
      {/* Header */}
      <div className="term-head">
        {TABS.map((t) => (
          <span key={t} className={`ttab${t === termTab ? " active" : ""}`} onClick={() => setTermTab(t)}>
            {t}
          </span>
        ))}
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
          {termTab === "Terminal" && (
            <>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: dotColor, display: "inline-block", flexShrink: 0 }} title={dotTitle} />
              <button className="ic" title="Restart session" onClick={boot}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>
                </svg>
              </button>
              <button className="ic" title="Clear" onClick={() => termRef.current?.clear()}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>
                </svg>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Terminal body */}
      {termTab === "Terminal" && (
        <div style={{ flex: 1, minHeight: 0, position: "relative", overflow: "hidden" }}>
          <div
            ref={wrapRef}
            style={{ position: "absolute", inset: "4px 4px 4px 6px" }}
          />
        </div>
      )}

      {termTab === "Output" && (
        <div className="term-body">
          <div className="tmuted">[vite] connected.</div>
          <div className="tmuted">[hmr] update /src/SharrowkinIde.tsx</div>
          <div>ready in <span className="tp">312ms</span></div>
        </div>
      )}

      {termTab === "Problems" && (
        <div className="term-body">
          <div className="tmuted">No problems detected.</div>
        </div>
      )}
    </section>
  )
}
