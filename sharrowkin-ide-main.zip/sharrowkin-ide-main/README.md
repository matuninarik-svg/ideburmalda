<div align="center">

# 🧠 Sharrowkin IDE

### The AI coding agent that actually remembers your project

*Local-first · Persistent Memory · Bring Your Own LLM · Zero-Cloud Code Privacy*

<p align="center">
  <img src="https://img.shields.io/badge/License-Apache_2.0-blue.svg?style=for-the-badge" alt="License: Apache 2.0" />
  <img src="https://img.shields.io/badge/Python-3.10+-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python 3.10+" />
  <img src="https://img.shields.io/badge/React-18.3-20232A?style=for-the-badge&logo=react&logoColor=61DAFB" alt="React 18.3" />
  <img src="https://img.shields.io/badge/Tauri-v2-FFC131?style=for-the-badge&logo=tauri&logoColor=white" alt="Tauri v2" />
</p>

[Key Features](#-key-features) · [Quick Start](#-quick-start) · [Onboarding & Personalization](#-onboarding--personalization) · [Architecture](#-architecture) · [Build & Compile](#-build--compile) · [Roadmap](#-roadmap) · [Contributing](#-contributing)

</div>

---

> **🚀 v0.1.0 First Release (Beta)**  
> Welcome to the initial release of Sharrowkin IDE! We are building a local-first AI development workspace that solves the biggest limitation of current AI tools: **context loss**. Sharrowkin remembers your decisions, style, and codebase structure forever.

---

## 🎯 What is Sharrowkin?

Most AI coding assistants forget everything the moment you close the tab or switch context. Sharrowkin is different. It is an **AI-native pair programming IDE** with a persistent 4-layer memory system that learns your style, retains context across restarts, and performs complex software engineering tasks locally.

Think of it as **Devin meets Aider**, but with a gorgeous, high-performance desktop interface built in **Tauri + React** and powered by a **FastAPI** agent backend.

---

## ✨ Key Features

### 🧠 Persistent 4-Layer Memory
Your context never resets. Sharrowkin utilizes four cooperative memory subsystems:
*   **DSM (Dynamic Segmented Memory)**: Hierarchical semantic search with an associative graph.
*   **RLD (Recursive Latent DNA)**: Automatically detects, stores, and reuse successful implementation patterns.
*   **MemoryField**: Hebbian-style neural concept reinforcement to map high-level architecture features.
*   **TraceMemory**: Execution history replay allowing self-adaptation and loop prevention.

### 🔄 5-Phase Disciplined Reasoning Loop
Instead of single-shot guesses, every instruction executes through a structured agent cycle:
1.  **Observe**: Scans workspace, analyzes files, parses dependencies.
2.  **Recall**: Queries memory systems for historical decisions and code snippets.
3.  **Reason**: Thinks step-by-step, builds a structured execution plan.
4.  **Stabilize**: Validates code changes, intercepts syntax/lint errors, heals itself.
5.  **Commit**: Safely writes files, executes commands, saves learnings.

### 💻 Autopilot Agent UI
A state-of-the-art developer dashboard showing:
*   **Interactive Chat Panel**: High-performance AI assistant chat.
*   **Live Token Typewriter**: Fast, beautiful fluid token streaming.
*   **Visual Step Planner**: Live checklist showing the agent's current objectives.
*   **Active Diffs**: View unified side-by-side modifications as they stream.
*   **Integrated Terminal**: Embedded `xterm.js` showing real-time command execution.

### 🎨 Point-and-Fix Live Preview
Launch your dev server directly inside the IDE preview browser. Select any visual element and tell the agent what to fix—no screenshots or manual copying required.

---

## 🚀 Quick Start

### Method 1: Desktop Application (Recommended)

1.  Navigate to the [Releases](https://github.com/narelabs/sharrowkin-ide/releases) page.
2.  Download the latest installer for your OS:
    *   **Windows**: `sharrowkin-ide_0.1.0_x64-setup.exe`
3.  Install, launch the application, and complete the Onboarding wizard to personalize your setup.

### Method 2: Run from Source

#### Prerequisites
*   **Python 3.10+**
*   **Node.js 18+**
*   **API Key** for Gemini, Claude, OpenAI, or OpenRouter

#### Installation

```bash
# Clone the repository
git clone https://github.com/narelabs/sharrowkin-ide.git
cd sharrowkin-ide

# Setup Python Virtual Environment & Install Dependencies
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt

# Setup Frontend & Tauri UI
cd ui
npm install
```

#### Run Development Servers
```bash
# Terminal 1: Launch FastAPI Agent Backend (from root)
python main.py

# Terminal 2: Launch Vite + Tauri Frontend (from ui folder)
npm run dev
```

---

## 👤 Onboarding & Personalization

Sharrowkin features a built-in step-by-step onboarding flow designed to customize the environment specifically to you:
1.  **Welcome Panel**: Quick feature overview.
2.  **Aesthetic Choice**: Seamless Dark & Light theme toggling with modern glassmorphism UI.
3.  **Developer Profile**: Set your **Name**, **Occupation/Role**, and **Current Context**. Sharrowkin automatically injects this profile into every prompt, tailoring its code style, explanations, and architecture decisions to your direct needs.
4.  **AI Provider Setup**: Choose your model (Gemini, Claude, GPT, or OpenRouter) and securely save your API key locally.

---

## 🏗️ Architecture

```
┌─────────────────────────┐               WebSocket               ┌──────────────────────────────┐
│  React + Tauri Desktop  │ <─────── Real-time events ──────────> │   FastAPI Python Backend     │
│  UI (Vite / localhost)  │ <─────── REST /api/workspace ───────> │   (Uvicorn on :8000)         │
└─────────────────────────┘                                       └──────────────┬───────────────┘
                                                                                 │
                                                                         ┌───────▼────────┐
                                                                         │   Agent Core   │
                                                                         │  5-Phase Loop  │
                                                                         └───────┬────────┘
                                                                                 │
                                                                         ┌───────▼────────┐
                                                                         │ Memory Engines │
                                                                         │ DSM·RLD·Field  │
                                                                         └───────┬────────┘
                                                                                 │
                                                                         ┌───────▼────────┐
                                                                         │   LLM Client   │ ───> Your Provider
                                                                         │ Gemini/Claude  │
                                                                         └────────────────┘
```

---

## 🛠️ Build & Compile

### 1. Compile the Python Backend
To pack the FastAPI server into a standalone executable:
```bash
pip install pyinstaller
pyinstaller --noconfirm --clean --name sharrowkin-backend --onefile main.py
```

### 2. Build the Tauri Application
To generate the production installer:
```bash
cd ui
npx tauri build
```
The compiled installer will be saved in `ui/src-tauri/target/release/bundle/`.

---

## 🗺️ Roadmap

### 🏁 v0.1.x (Current - Beta Release)
*   [x] Persistent 4-Layer Memory Systems
*   [x] Autopilot Chat UI & Live Diff Viewers
*   [x] Step-by-Step Developer Profile Onboarding
*   [x] Embed terminal tool controls
*   [x] Integrated Web browser preview & Point-and-Fix

### 🚧 v0.2.x (Upcoming)
*   [ ] Multi-file refactoring & dependency resolution
*   [ ] Custom tool plugins (MCP server marketplace)
*   [ ] Contextual team sharing (export memory/DNA snapshots)
*   [ ] Performance optimization for massive monorepos

---

## 🤝 Contributing

We love open-source contributions!
1.  Fork the project.
2.  Create your feature branch (`git checkout -b feature/AmazingFeature`).
3.  Commit your changes (`git commit -m 'Add some AmazingFeature'`).
4.  Push to the branch (`git push origin feature/AmazingFeature`).
5.  Open a Pull Request.

---

## 📄 License

Licensed under the Apache License, Version 2.0. See [LICENSE](LICENSE) for details.

---

<div align="center">

**Developed with ❤️ by [NARE Labs](https://github.com/narelabs)**

[⭐ Star us on GitHub](https://github.com/narelabs/sharrowkin) · [📢 Join the Discord](https://github.com/narelabs/sharrowkin)

</div>
