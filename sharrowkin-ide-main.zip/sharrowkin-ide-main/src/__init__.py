"""Sharrowkin IDE Agent - Source package."""
