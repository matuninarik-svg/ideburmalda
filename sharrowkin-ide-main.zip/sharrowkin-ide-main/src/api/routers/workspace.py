"""Workspace statistics API endpoints."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from pathlib import Path
from typing import Optional, List, Dict, Any
import os

router = APIRouter(prefix="/api/workspace", tags=["workspace"])


class WorkspaceStats(BaseModel):
    """Workspace statistics."""
    total_files: int
    total_lines: int
    total_size_bytes: int
    file_types: Dict[str, int]
    largest_files: List[Dict[str, Any]]
    python_files: int
    test_files: int
    config_files: int


class FileInfo(BaseModel):
    """File information."""
    path: str
    size_bytes: int
    lines: int
    extension: str


class TreeNode(BaseModel):
    """File tree node."""
    name: str
    path: str
    type: str  # "file" or "directory"
    children: Optional[List['TreeNode']] = None
    size: Optional[int] = None
    extension: Optional[str] = None

    class Config:
        # Allow recursive models
        arbitrary_types_allowed = True


# Update forward references for recursive model
TreeNode.model_rebuild()


@router.get("/graph")
async def get_workspace_graph(path: str):
    """Return a dependency graph of the workspace for visualization."""
    import subprocess, re
    from pathlib import Path as P

    workspace = P(path)
    if not workspace.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")

    nodes = []
    edges = []
    seen_paths = set()

    ext_colors = {
        ".py": "#3b82f6", ".ts": "#2563eb", ".tsx": "#6366f1",
        ".js": "#d97706", ".jsx": "#f59e0b", ".json": "#059669",
        ".md": "#9333ea", ".css": "#0891b2", ".html": "#ea580c",
    }
    ext_groups = {
        ".py": "python", ".ts": "typescript", ".tsx": "typescript",
        ".js": "javascript", ".jsx": "javascript", ".json": "config",
        ".md": "docs", ".css": "style", ".html": "html",
    }

    skip_dirs = {".git","__pycache__","node_modules",".venv","venv",
                 ".pytest_cache",".mypy_cache","dist","build",".next",
                 ".sharrowkin",".codegraph",".kiro","coverage"}

    # Collect files
    file_map: dict[str, str] = {}  # rel_path -> abs_path
    for root, dirs, files in os.walk(workspace):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext not in ext_colors:
                continue
            abs_path = os.path.join(root, f)
            try:
                rel = os.path.relpath(abs_path, workspace).replace("\\", "/")
            except ValueError:
                continue
            if len(rel) > 120:
                continue
            file_map[rel] = abs_path
            seen_paths.add(rel)

    # Limit to 120 most important files
    def importance(rel: str) -> int:
        score = 0
        if "main" in rel or "index" in rel or "app" in rel.lower(): score += 10
        if "test" in rel or "spec" in rel: score -= 3
        if rel.count("/") <= 1: score += 5
        return score

    sorted_files = sorted(file_map.keys(), key=importance, reverse=True)[:120]

    for rel in sorted_files:
        ext = os.path.splitext(rel)[1].lower()
        name = os.path.basename(rel)
        nodes.append({
            "id": rel, "label": name,
            "group": ext_groups.get(ext, "other"),
            "color": ext_colors.get(ext, "#a1a1aa"),
            "path": rel, "ext": ext,
        })

    # Parse imports to build edges
    present = set(sorted_files)
    for rel in sorted_files:
        abs_path = file_map[rel]
        ext = os.path.splitext(rel)[1].lower()
        try:
            content = open(abs_path, encoding="utf-8", errors="ignore").read()
        except Exception:
            continue

        base_dir = os.path.dirname(rel)

        if ext == ".py":
            for m in re.finditer(r'^from\s+(\.+[\w.]*)\s+import|^import\s+(\.+[\w.]*)', content, re.MULTILINE):
                raw = (m.group(1) or m.group(2) or "").strip()
                if not raw or not raw.startswith("."):
                    continue
                dots = len(raw) - len(raw.lstrip("."))
                parts = raw.lstrip(".").replace(".", "/")
                up = base_dir
                for _ in range(dots - 1):
                    up = os.path.dirname(up)
                candidate = (up + "/" + parts + ".py").lstrip("/")
                if candidate in present and candidate != rel:
                    edges.append({"source": rel, "target": candidate, "type": "import"})

        elif ext in (".ts", ".tsx", ".js", ".jsx"):
            for m in re.finditer(r'''(?:from|import)\s+['"]([./][^'"]+)['"]''', content):
                raw = m.group(1)
                for sfx in ("", ".ts", ".tsx", ".js", ".jsx", "/index.ts", "/index.tsx", "/index.js"):
                    if raw.startswith("."):
                        candidate = os.path.normpath(os.path.join(base_dir, raw + sfx)).replace("\\", "/")
                    else:
                        continue
                    if candidate in present and candidate != rel:
                        edges.append({"source": rel, "target": candidate, "type": "import"})
                        break

    # Deduplicate edges
    seen_edges = set()
    unique_edges = []
    for e in edges:
        key = (e["source"], e["target"])
        if key not in seen_edges:
            seen_edges.add(key)
            unique_edges.append(e)

    # Memory nodes from DSM
    memory_nodes = []
    try:
        dsm_path = workspace / ".sharrowkin" / "dsm_memory.json"
        if dsm_path.exists():
            import json as _json
            data = _json.loads(dsm_path.read_text(encoding="utf-8"))
            segments = data.get("segments", [])[:15]
            for seg in segments:
                mid = f"mem:{seg.get('id','?')}"
                memory_nodes.append({
                    "id": mid,
                    "label": seg.get("description", "Memory")[:40],
                    "group": "memory",
                    "color": "#8b5cf6",
                    "path": "",
                    "ext": "",
                })
    except Exception:
        pass

    return {
        "nodes": nodes + memory_nodes,
        "edges": unique_edges,
        "stats": {
            "files": len(nodes),
            "memory": len(memory_nodes),
            "connections": len(unique_edges),
        }
    }


@router.get("/pick-folder")
async def pick_folder():
    """Open native OS folder picker dialog, return selected path."""
    import asyncio
    import sys

    def _open_dialog() -> str | None:
        if sys.platform == "win32":
            try:
                import tkinter as tk
                from tkinter import filedialog
                root = tk.Tk()
                root.withdraw()
                root.attributes("-topmost", True)
                path = filedialog.askdirectory(title="Select project folder")
                root.destroy()
                return path or None
            except Exception:
                pass
        return None

    path = await asyncio.get_event_loop().run_in_executor(None, _open_dialog)
    if not path:
        raise HTTPException(status_code=204, detail="No folder selected")
    return {"path": str(Path(path).resolve())}


@router.get("/detect")
async def detect_workspace():
    """Auto-detect the current workspace directory.
    
    Checks in order:
    1. SHARROWKIN_WORKSPACE env var
    2. Current working directory (if it has .git or pyproject.toml or package.json)
    3. Parent of the running process
    """
    import sys

    # 1. Environment variable
    env_path = os.environ.get("SHARROWKIN_WORKSPACE")
    if env_path and Path(env_path).exists():
        return {"path": env_path, "source": "env"}

    # 2. Current working directory
    cwd = Path.cwd()
    project_markers = {'.git', 'pyproject.toml', 'package.json', 'Cargo.toml', 'go.mod'}
    if any((cwd / marker).exists() for marker in project_markers):
        return {"path": str(cwd), "source": "cwd"}

    # 3. Walk up from cwd to find a project root
    for parent in cwd.parents:
        if any((parent / marker).exists() for marker in project_markers):
            return {"path": str(parent), "source": "parent"}

    # 4. Fallback to cwd anyway
    return {"path": str(cwd), "source": "fallback"}


@router.get("/tree")
async def get_workspace_tree(path: str):
    """Get workspace file tree."""
    workspace_path = Path(path)
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")

    def build_tree(dir_path: Path, max_depth: int = 5, current_depth: int = 0) -> Dict[str, Any]:
        """Recursively build file tree as dict."""
        if current_depth >= max_depth:
            return None

        name = dir_path.name or str(dir_path)
        # Use relative path as id for uniqueness
        try:
            rel_path = str(dir_path.relative_to(workspace_path)).replace("\\", "/")
        except ValueError:
            rel_path = str(dir_path).replace("\\", "/")

        if dir_path.is_file():
            return {
                "id": rel_path or name,
                "name": name,
                "path": rel_path,
                "type": "file",
                "size": dir_path.stat().st_size,
                "extension": dir_path.suffix or None,
                "children": None
            }

        # Directory
        children = []
        try:
            entries = sorted(dir_path.iterdir())
            # Sort: folders first, then files, alphabetically within each group
            folders = sorted([e for e in entries if e.is_dir()], key=lambda x: x.name.lower())
            files = sorted([e for e in entries if e.is_file()], key=lambda x: x.name.lower())
            for item in folders + files:
                # Skip common ignore directories
                if item.name in {'.git', '__pycache__', 'node_modules', '.venv', 'venv',
                                '.pytest_cache', '.mypy_cache', 'dist', 'build', '.next',
                                '.sharrowkin', '.codegraph', '.kiro'}:
                    continue

                child = build_tree(item, max_depth, current_depth + 1)
                if child:
                    children.append(child)
        except PermissionError:
            pass

        return {
            "id": rel_path or name,
            "name": name,
            "path": rel_path,
            "type": "folder",
            "children": children if children else None,
            "size": None,
            "extension": None
        }

    tree = build_tree(workspace_path)
    return {"tree": tree}


@router.get("/stats", response_model=WorkspaceStats)
async def get_workspace_stats(workspace: Optional[str] = None):
    """Get workspace statistics."""
    if not workspace:
        workspace = "/tmp/sharrowkin-workspace/repos/sharrowkin-backend"
    
    workspace_path = Path(workspace)
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")
    
    total_files = 0
    total_lines = 0
    total_size = 0
    file_types = {}
    files_info = []
    python_files = 0
    test_files = 0
    config_files = 0
    
    # Scan workspace
    for root, dirs, files in os.walk(workspace_path):
        # Skip common ignore directories
        dirs[:] = [d for d in dirs if d not in {
            '.git', '__pycache__', 'node_modules', '.venv', 'venv',
            '.pytest_cache', '.mypy_cache', 'dist', 'build'
        }]
        
        for file in files:
            file_path = Path(root) / file
            try:
                size = file_path.stat().st_size
                ext = file_path.suffix or 'no_extension'
                
                # Count file types
                file_types[ext] = file_types.get(ext, 0) + 1
                
                # Count lines for text files
                lines = 0
                if ext in {'.py', '.js', '.ts', '.jsx', '.tsx', '.md', '.txt', '.yaml', '.yml', '.json', '.toml'}:
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            lines = sum(1 for _ in f)
                    except:
                        pass
                
                total_files += 1
                total_lines += lines
                total_size += size
                
                # Track Python files
                if ext == '.py':
                    python_files += 1
                    if 'test_' in file or '_test.py' in file:
                        test_files += 1
                
                # Track config files
                if file in {'pyproject.toml', 'package.json', 'tsconfig.json', 'setup.py', 'requirements.txt'}:
                    config_files += 1
                
                files_info.append({
                    'path': str(file_path.relative_to(workspace_path)),
                    'size': size,
                    'lines': lines,
                    'ext': ext
                })
            except Exception:
                continue
    
    # Get largest files
    largest_files = sorted(files_info, key=lambda x: x['size'], reverse=True)[:10]
    
    return WorkspaceStats(
        total_files=total_files,
        total_lines=total_lines,
        total_size_bytes=total_size,
        file_types=file_types,
        largest_files=largest_files,
        python_files=python_files,
        test_files=test_files,
        config_files=config_files
    )


# ─── File read endpoint ──────────────────────────────────────────────────────


@router.get("/file")
async def get_workspace_file(workspace: str, path: str):
    """Read a file's content from the workspace."""
    workspace_path = Path(workspace)
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")

    # Resolve relative path against workspace
    file_path = workspace_path / path
    # Security: ensure the resolved path is inside the workspace
    try:
        file_path = file_path.resolve()
        workspace_path.resolve()
        if not str(file_path).startswith(str(workspace_path.resolve())):
            raise HTTPException(status_code=403, detail="Path traversal not allowed")
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid path")

    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    if not file_path.is_file():
        raise HTTPException(status_code=400, detail="Path is not a file")

    # Read with size limit (5 MB)
    if file_path.stat().st_size > 5 * 1024 * 1024:
        return {"content": "[File too large to display (>5 MB)]", "path": path, "truncated": True}

    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read file: {e}")

    return {"content": content, "path": path, "lines": content.count("\n") + 1}


# ─── File write endpoint ─────────────────────────────────────────────────────


class FileWriteRequest(BaseModel):
    workspace: str
    path: str
    content: str


@router.put("/file")
async def write_workspace_file(req: FileWriteRequest):
    """Write content to a file in the workspace."""
    workspace_path = Path(req.workspace)
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")

    file_path = workspace_path / req.path
    try:
        file_path = file_path.resolve()
        if not str(file_path).startswith(str(workspace_path.resolve())):
            raise HTTPException(status_code=403, detail="Path traversal not allowed")
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid path")

    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(req.content, encoding="utf-8")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to write file: {e}")

    return {"success": True, "path": req.path}


# ─── Search endpoint ─────────────────────────────────────────────────────────


class SearchRequest(BaseModel):
    workspace: str
    query: str
    max_results: int = 30


@router.post("/search")
async def search_workspace(req: SearchRequest):
    """Search for text in workspace files."""
    workspace_path = Path(req.workspace)
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")

    query_lower = req.query.lower()
    results = []

    skip_dirs = {'.git', '__pycache__', 'node_modules', '.venv', 'venv',
                 '.pytest_cache', '.mypy_cache', 'dist', 'build', '.next',
                 '.sharrowkin', '.codegraph', '.kiro'}

    text_extensions = {'.py', '.js', '.ts', '.tsx', '.jsx', '.json', '.md',
                       '.txt', '.yaml', '.yml', '.toml', '.css', '.html',
                       '.rs', '.go', '.java', '.c', '.cpp', '.h', '.sh'}

    for root, dirs, files in os.walk(workspace_path):
        dirs[:] = [d for d in dirs if d not in skip_dirs]

        for file in files:
            if len(results) >= req.max_results:
                break

            file_path = Path(root) / file
            if file_path.suffix.lower() not in text_extensions:
                continue
            if file_path.stat().st_size > 1 * 1024 * 1024:
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
                for line_no, line in enumerate(content.splitlines(), 1):
                    if query_lower in line.lower():
                        rel_path = str(file_path.relative_to(workspace_path)).replace("\\", "/")
                        results.append({
                            "file": rel_path,
                            "line": line_no,
                            "match": line.strip()[:200],
                        })
                        if len(results) >= req.max_results:
                            break
            except Exception:
                continue

    return {"results": results, "total": len(results)}


@router.get("/file")
async def get_workspace_file(workspace: str, path: str):
    """Read a file from the workspace."""
    workspace_path = Path(workspace)
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")

    # Resolve the file path (relative or absolute)
    file_path = Path(path)
    if not file_path.is_absolute():
        file_path = workspace_path / path

    if not file_path.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {path}")

    if not file_path.is_file():
        raise HTTPException(status_code=400, detail="Path is not a file")

    # Security: ensure file is within workspace
    try:
        file_path.resolve().relative_to(workspace_path.resolve())
    except ValueError:
        raise HTTPException(status_code=403, detail="Access denied: file outside workspace")

    # Read file content
    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read file: {e}")

    return {
        "path": path,
        "content": content,
        "size": file_path.stat().st_size,
        "lines": content.count("\n") + 1,
    }


@router.put("/file")
async def save_workspace_file(body: dict):
    """Save content to a file in the workspace."""
    workspace = body.get("workspace", "")
    path = body.get("path", "")
    content = body.get("content", "")

    if not workspace or not path:
        raise HTTPException(status_code=400, detail="Missing workspace or path")

    workspace_path = Path(workspace)
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")

    file_path = Path(path)
    if not file_path.is_absolute():
        file_path = workspace_path / path

    # Security: ensure file is within workspace
    try:
        file_path.resolve().relative_to(workspace_path.resolve())
    except ValueError:
        raise HTTPException(status_code=403, detail="Access denied: file outside workspace")

    try:
        file_path.write_text(content, encoding="utf-8")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save file: {e}")

    return {"success": True, "path": path}


class SearchRequest(BaseModel):
    workspace: str
    query: str
    max_results: int = 30


@router.post("/search")
async def search_workspace(body: SearchRequest):
    """Search for text in workspace files."""
    workspace_path = Path(body.workspace)
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")

    results = []
    query_lower = body.query.lower()

    # Walk through files and search
    skip_dirs = {'.git', '__pycache__', 'node_modules', '.venv', 'venv',
                 '.pytest_cache', '.mypy_cache', 'dist', 'build', '.next',
                 '.sharrowkin', '.codegraph', '.kiro'}
    text_extensions = {'.py', '.js', '.ts', '.tsx', '.jsx', '.json', '.md',
                       '.txt', '.yaml', '.yml', '.toml', '.css', '.html',
                       '.rs', '.go', '.java', '.c', '.cpp', '.h'}

    for root, dirs, files in os.walk(workspace_path):
        dirs[:] = [d for d in dirs if d not in skip_dirs]

        for file in files:
            if len(results) >= body.max_results:
                break

            file_path = Path(root) / file
            if file_path.suffix.lower() not in text_extensions:
                continue

            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                for line_num, line in enumerate(content.splitlines(), 1):
                    if query_lower in line.lower():
                        rel_path = str(file_path.relative_to(workspace_path)).replace("\\", "/")
                        results.append({
                            "file": rel_path,
                            "line": line_num,
                            "match": line.strip()[:200],
                        })
                        if len(results) >= body.max_results:
                            break
            except Exception:
                continue

    return {"results": results, "total": len(results)}


class OpenExplorerRequest(BaseModel):
    workspace: str
    path: str


@router.post("/open-in-explorer")
async def open_in_explorer(body: OpenExplorerRequest):
    """Open the file or directory in the native OS file explorer."""
    import sys
    import subprocess
    workspace_path = Path(body.workspace)
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")
        
    full_path = workspace_path / body.path
    try:
        full_path = full_path.resolve()
        if not str(full_path).startswith(str(workspace_path.resolve())):
            raise HTTPException(status_code=403, detail="Path traversal not allowed")
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid path")
        
    if not full_path.exists():
        raise HTTPException(status_code=404, detail=f"Path not found: {body.path}")
        
    try:
        if sys.platform == "win32":
            if full_path.is_file():
                subprocess.Popen(f'explorer /select,"{full_path}"')
            else:
                subprocess.Popen(f'explorer "{full_path}"')
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R" if full_path.is_file() else str(full_path)])
        else: # Linux
            subprocess.Popen(["xdg-open", str(full_path.parent if full_path.is_file() else full_path)])
        return {"success": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to open explorer: {e}")



# --- File / folder CRUD ------------------------------------------------------

class NewItemRequest(BaseModel):
    workspace: str
    parent: str   # relative path of parent dir (empty = workspace root)
    name: str
    kind: str     # "file" | "folder"


@router.post("/new-item")
async def new_item(body: NewItemRequest):
    """Create a new file or folder inside the workspace."""
    workspace_path = Path(body.workspace).resolve()
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")
    ws_str = str(workspace_path) + os.sep
    parent_path = (workspace_path / body.parent).resolve() if body.parent else workspace_path
    if not (str(parent_path) + os.sep).startswith(ws_str):
        raise HTTPException(status_code=403, detail="Path traversal not allowed")
    target = parent_path / body.name
    if target.exists():
        raise HTTPException(status_code=409, detail="Already exists")
    try:
        if body.kind == "folder":
            target.mkdir(parents=True, exist_ok=False)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("", encoding="utf-8")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    rel = str(target.relative_to(workspace_path)).replace("\\", "/")
    return {"success": True, "path": rel}


class RenameRequest(BaseModel):
    workspace: str
    path: str
    new_name: str


@router.post("/rename")
async def rename_item(body: RenameRequest):
    """Rename a file or folder inside the workspace."""
    workspace_path = Path(body.workspace).resolve()
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")
    ws_str = str(workspace_path) + os.sep
    full_path = (workspace_path / body.path).resolve()
    if not (str(full_path) + os.sep).startswith(ws_str) and str(full_path) != str(workspace_path):
        raise HTTPException(status_code=403, detail="Path traversal not allowed")
    if not full_path.exists():
        raise HTTPException(status_code=404, detail="Item not found")
    new_path = full_path.parent / body.new_name
    if new_path.exists():
        raise HTTPException(status_code=409, detail="Target name already exists")
    try:
        full_path.rename(new_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    rel = str(new_path.relative_to(workspace_path)).replace("\\", "/")
    return {"success": True, "path": rel}


class DeleteRequest(BaseModel):
    workspace: str
    path: str


@router.post("/delete")
async def delete_item(body: DeleteRequest):
    """Delete a file or folder inside the workspace."""
    import shutil
    workspace_path = Path(body.workspace).resolve()
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")
    full_path = (workspace_path / body.path).resolve()
    if not str(full_path).startswith(str(workspace_path)):
        raise HTTPException(status_code=403, detail="Path traversal not allowed")
    if not full_path.exists():
        raise HTTPException(status_code=404, detail="Item not found")
    try:
        if full_path.is_dir():
            shutil.rmtree(full_path)
        else:
            full_path.unlink()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"success": True}


class OpenTerminalRequest(BaseModel):
    workspace: str
    path: str


@router.post("/open-terminal")
async def open_terminal(body: OpenTerminalRequest):
    """Open a native OS terminal at the given path."""
    import sys
    import subprocess
    workspace_path = Path(body.workspace).resolve()
    if not workspace_path.exists():
        raise HTTPException(status_code=404, detail="Workspace not found")
    full_path = (workspace_path / body.path).resolve() if body.path else workspace_path
    if not str(full_path).startswith(str(workspace_path)):
        raise HTTPException(status_code=403, detail="Path traversal not allowed")
    target_dir = full_path if full_path.is_dir() else full_path.parent
    try:
        if sys.platform == "win32":
            subprocess.Popen(f'start cmd /K "cd /d "{target_dir}""', shell=True)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-a", "Terminal", str(target_dir)])
        else:
            subprocess.Popen(["x-terminal-emulator", "--working-directory", str(target_dir)])
        return {"success": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to open terminal: {e}")


class GitGenerateRequest(BaseModel):
    path: str


@router.post("/git-generate-message")
async def git_generate_message(req: GitGenerateRequest):
    """Use LLM to generate a commit message from staged/unstaged diff."""
    import subprocess, asyncio, os
    try:
        diff = subprocess.run(
            ["git", "diff", "HEAD"],
            cwd=req.path, capture_output=True, text=True, timeout=10
        ).stdout
        if not diff.strip():
            diff = subprocess.run(
                ["git", "diff"],
                cwd=req.path, capture_output=True, text=True, timeout=10
            ).stdout
        if not diff.strip():
            return {"message": "chore: update files"}

        diff_short = diff[:6000]  # keep it short for LLM

        sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
        from core.llm.client import GeminiClient
        client = GeminiClient()
        if not client.configured:
            return {"message": "chore: update files"}

        prompt = (
            "Generate a concise git commit message for this diff.\n"
            "Rules: imperative mood, max 72 chars, no period at end, be specific.\n"
            "Output ONLY the commit message, nothing else.\n\n"
            f"```diff\n{diff_short}\n```"
        )
        message = await client.generate_text(prompt, "You are a git commit message generator. Be concise and precise.")
        message = message.strip().strip('"').strip("'").split("\n")[0][:72]
        return {"message": message}
    except Exception as e:
        return {"message": "chore: update files"}


@router.get("/git-status")
async def get_git_status(path: str):
    """Return git status (modified/added/deleted file lists) for the workspace."""
    import subprocess
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=path, capture_output=True, text=True, timeout=5
        )
        modified, added, deleted, untracked = [], [], [], []
        for line in result.stdout.splitlines():
            if len(line) < 4:
                continue
            xy, fpath = line[:2], line[3:]
            fpath = fpath.split(" -> ")[-1].strip()
            x, y = xy[0], xy[1]
            if x == '?' and y == '?':
                untracked.append(fpath)
            elif x == 'D' or y == 'D':
                deleted.append(fpath)
            elif x in ('A', 'C') or y == 'A':
                added.append(fpath)
            else:
                modified.append(fpath)
        return {"modified": modified, "added": added, "deleted": deleted, "untracked": untracked}
    except Exception:
        return {"modified": [], "added": [], "deleted": [], "untracked": []}


@router.get("/git-info")
async def get_git_info(path: str):
    """Return current branch and recent commits."""
    import subprocess
    def run(cmd):
        return subprocess.run(cmd, cwd=path, capture_output=True, text=True, timeout=5)
    try:
        branch = run(["git", "rev-parse", "--abbrev-ref", "HEAD"]).stdout.strip() or "main"
        log = run(["git", "log", "--oneline", "-10"]).stdout.strip()
        commits = []
        for line in log.splitlines():
            parts = line.split(" ", 1)
            if len(parts) == 2:
                commits.append({"hash": parts[0], "message": parts[1]})
        remote = run(["git", "remote", "get-url", "origin"]).stdout.strip()
        # check if ahead/behind
        ahead_behind = run(["git", "rev-list", "--left-right", "--count", f"HEAD...origin/{branch}"]).stdout.strip()
        ahead, behind = 0, 0
        if ahead_behind:
            parts = ahead_behind.split()
            if len(parts) == 2:
                ahead, behind = int(parts[0]), int(parts[1])
        return {"branch": branch, "commits": commits, "remote": remote, "ahead": ahead, "behind": behind}
    except Exception as e:
        return {"branch": "main", "commits": [], "remote": "", "ahead": 0, "behind": 0}


class GitCommitRequest(BaseModel):
    path: str
    message: str
    stage_all: bool = True


@router.post("/git-commit")
async def git_commit(req: GitCommitRequest):
    """Stage all changes and commit."""
    import subprocess
    try:
        if req.stage_all:
            subprocess.run(["git", "add", "-A"], cwd=req.path, capture_output=True, timeout=10)
        result = subprocess.run(
            ["git", "commit", "-m", req.message],
            cwd=req.path, capture_output=True, text=True, timeout=15
        )
        if result.returncode != 0:
            raise HTTPException(status_code=400, detail=result.stderr or result.stdout)
        return {"ok": True, "output": result.stdout.strip()}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


class GitPushRequest(BaseModel):
    path: str
    branch: str = "main"


@router.post("/git-push")
async def git_push(req: GitPushRequest):
    """Push to origin."""
    import subprocess
    try:
        result = subprocess.run(
            ["git", "push", "origin", req.branch],
            cwd=req.path, capture_output=True, text=True, timeout=30
        )
        if result.returncode != 0:
            raise HTTPException(status_code=400, detail=result.stderr or result.stdout)
        return {"ok": True, "output": result.stdout.strip() or result.stderr.strip()}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
