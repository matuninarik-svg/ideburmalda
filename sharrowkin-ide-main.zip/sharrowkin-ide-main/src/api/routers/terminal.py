"""Terminal WebSocket router — real PTY via pywinpty on Windows."""

from __future__ import annotations

import asyncio
import os

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter(prefix="/api/terminal", tags=["terminal"])


def _get_shell() -> str:
    for shell in ["pwsh.exe", "powershell.exe", "cmd.exe"]:
        for d in os.environ.get("PATH", "").split(os.pathsep):
            if os.path.isfile(os.path.join(d, shell)):
                return shell
    return "cmd.exe"


@router.websocket("/ws")
async def terminal_ws(websocket: WebSocket):
    await websocket.accept()

    try:
        import winpty  # type: ignore
    except ImportError:
        await websocket.send_text("\r\n[terminal] pywinpty not available\r\n")
        await websocket.close()
        return

    shell = _get_shell()

    # Pick the shell's starting directory: the workspace the IDE passes wins,
    # then a valid WORKSPACE_PATH, else the backend cwd. A bogus path (e.g. the
    # ".env" placeholder) must never reach winpty.spawn — it fails the spawn and
    # drops the socket with no output.
    candidates = [
        websocket.query_params.get("workspace"),
        os.environ.get("WORKSPACE_PATH"),
        os.getcwd(),
    ]
    workspace = next((c for c in candidates if c and os.path.isdir(c)), os.getcwd())

    try:
        pty = winpty.PTY(120, 30)
        pty.spawn(shell, cwd=workspace)
    except Exception as e:
        await websocket.send_text(f"\r\n[terminal] failed to start shell: {e}\r\n")
        await websocket.close()
        return

    loop = asyncio.get_event_loop()
    stop = asyncio.Event()

    async def read_pty():
        while not stop.is_set():
            try:
                data = await loop.run_in_executor(None, lambda: pty.read(blocking=False))
                if data:
                    await websocket.send_text(data)
                else:
                    await asyncio.sleep(0.02)
            except Exception:
                break
        stop.set()

    read_task = asyncio.create_task(read_pty())

    try:
        while not stop.is_set():
            try:
                msg = await asyncio.wait_for(websocket.receive_json(), timeout=0.1)
            except asyncio.TimeoutError:
                continue
            except WebSocketDisconnect:
                break

            kind = msg.get("type")
            if kind == "input":
                data: str = msg.get("data", "")
                await loop.run_in_executor(None, lambda d=data: pty.write(d))
            elif kind == "resize":
                cols = int(msg.get("cols", 120))
                rows = int(msg.get("rows", 30))
                try:
                    pty.set_size(cols, rows)
                except Exception:
                    pass
    finally:
        stop.set()
        read_task.cancel()
        try:
            pty.cancel_io()
        except Exception:
            pass
